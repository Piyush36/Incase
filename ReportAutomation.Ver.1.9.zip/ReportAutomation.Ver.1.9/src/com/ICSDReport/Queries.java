package com.ICSDReport;

public class Queries {
	static String EUR_Query="select ccy_code,asof_date,exchange_rate,multi_div_ind " +
			"from fx_rate noholdlock " +
			"where asof_date < getdate() " +
			"group by ccy_code " +
			"having asof_date=max(asof_date) ";
	
	static String CSK_Query="select " +
		    "d.tra_isin as 'ISIN Number', " +
		    "d.d_issue_name as 'Issue Name', " +
		    "d.d_tra_principle_ccy as 'Principal Currency', " +
		    "(case " +
		        "when d.d_tranche_status = 'LI' then 'Live' " +
		        "when d.d_tranche_status = 'DD' then 'Defaulted' " +
		        "when d.d_tranche_status = 'PR' then 'Pending Redeemed' " +
		        "when d.d_tranche_status =  'SV' then 'Step Verified' " +
		    "end) as 'Status', " +
		    "d.d_global_notes_location as 'Global Note Location', " +
		    "(case  " +
		        "when d.tra_registered = 'Y' then 'Registered  (Y)' " +
		        "when d.tra_registered = 'N' then 'Bearer  (N)'  "+
		    "end) as 'Register Type', " +
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) as 'Clearstream Holding', " +
		    "(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)) as 'Euroclear Holding', " +
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) +(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)), " +
		    "0, " +
		    "0, " +
		    "dpl.prog_no as 'Prog. No.', " +
		    "cc.cs_cue_no as 'CID No.' " +
		"from " +
		    "depo_tranche_level d noholdlock, " +
		    "tranche_clearer_holding tch1 noholdlock, " +
		    "tranche_clearer_holding tch2 noholdlock, " +
		    "depo_issue_level di noholdlock, " +
		    "depo_issr_level issr noholdlock, " +
		    "depo_customer_codes cc noholdlock, " +
		    "depo_programme_level dpl noholdlock, " +
		    "v_tranche vt noholdlock " +
		"where  " +
		    "d.d_tranche_status in ('LI', 'DD', 'PR', 'SV') " +
		    "and d.d_ipa_flag in ('S', 'B', 'D') " +
		    "and tch1.tranche_id =* d.tra_identifier " +
		    "and tch1.contact_id ='782969415818120' " +
		    "and tch2.tranche_id =* d.tra_identifier " +
		    "and tch2.contact_id  = '782969687257310' " +
		    "and d_tra_active_ind = 'Y' " +
		    "and di.issu_identifier = d.issu_identifier " +
		    "and dpl.prog_identifier = di.prog_identifier " +
		    "and dpl.prog_identifier = issr.prog_identifier " +
		    "and issr.issr_identifier = di.issr_identifier " +
		    "and di.issu_identifier = d.issu_identifier " +
		    "and cc.cs_cust_no = ISNULL(issr.cust_no,dpl.cust_no) " +
		    "and vt.branch_code ='CD' " +
		    "and vt.note_type='Y' " +
		    "and (select party_name from contact CON noholdlock, gdoasis_appointments APP noholdlock where APP.tranche_id = vt.tranche_id and CON.contact_id = APP.csk_code) = 'The Bank of New York Mellon' " +
		    "and vt.isin = d.tra_isin " +
		"ORDER BY d.tra_identifier ";
	
	
	static String CMAR_CSK_Query="select " +
		    "d.tra_isin as 'ISIN Number', " +
		    "d.d_issue_name as 'Issue Name', " +
		    "d.d_tra_principle_ccy as 'Principal Currency', " +
		    "(case " +
		        "when d.d_tranche_status = 'LI' then 'Live' " +
		        "when d.d_tranche_status = 'DD' then 'Defaulted' " +
		        "when d.d_tranche_status = 'PR' then 'Pending Redeemed' " +
		        "when d.d_tranche_status =  'SV' then 'Step Verified' " +
		    "end) as 'Status', " +
		    "d.d_global_notes_location as 'Global Note Location', " +
		    "(case  " +
		        "when d.tra_registered = 'Y' then 'Registered  (Y)' " +
		        "when d.tra_registered = 'N' then 'Bearer  (N)'  "+
		    "end) as 'Register Type', " +
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) as 'Clearstream Holding', " +
		    "(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)) as 'Euroclear Holding', " +
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) +(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)), " +
		    "0, " +
		    "0, " +
		    "dpl.prog_no as 'Prog. No.', " +
		    "cc.cs_cue_no as 'CID No.' " +
		"from " +
		    "depo_tranche_level d noholdlock, " +
		    "tranche_clearer_holding tch1 noholdlock, " +
		    "tranche_clearer_holding tch2 noholdlock, " +
		    "depo_issue_level di noholdlock, " +
		    "depo_issr_level issr noholdlock, " +
		    "depo_customer_codes cc noholdlock, " +
		    "depo_programme_level dpl noholdlock, " +
		    "v_tranche vt noholdlock " +
		"where  " +
		    "d.d_tranche_status in ('LI', 'DD', 'PR', 'SV') " +
		    "and d.d_ipa_flag in ('S', 'B', 'D') " +
		    "and tch1.tranche_id =* d.tra_identifier " +
		    "and tch1.contact_id ='782969415818120' " +
		    "and tch2.tranche_id =* d.tra_identifier " +
		    "and tch2.contact_id  = '782969687257310' " +
		    "and d_tra_active_ind = 'Y' " +
		    "and di.issu_identifier = d.issu_identifier " +
		    "and dpl.prog_identifier = di.prog_identifier " +
		    "and dpl.prog_identifier = issr.prog_identifier " +
		    "and issr.issr_identifier = di.issr_identifier " +
		    "and di.issu_identifier = d.issu_identifier " +
		    "and cc.cs_cust_no = ISNULL(issr.cust_no,dpl.cust_no) " +
		    "and vt.branch_code ='CD' " +
		    "and vt.note_type='Y' " +
		    "and (select party_name from contact CON noholdlock, gdoasis_appointments APP noholdlock where APP.tranche_id = vt.tranche_id and CON.contact_id = APP.csk_code) = 'The Bank of New York Mellon' " +
		    "and vt.isin = d.tra_isin " +
		    "and    (vt.oasis_issue_type_code not in ('TC') and vt.bare_depo_flag not in ('D')) " +
		"ORDER BY d.tra_identifier ";
	
	
	
	
	
	static String CD_Query="select "+
		    "d.tra_isin as 'ISIN Number', "+
		    "d.d_issue_name as 'Issue Name', "+
		    "d.d_tra_principle_ccy as 'Principal Currency', "+
		    "(case  "+
		        "when d.d_tranche_status = 'LI' then 'Live'  "+
		        "when d.d_tranche_status = 'DD' then 'Defaulted'  "+
		        "when d.d_tranche_status = 'PR' then 'Pending Redeemed'  "+
		        "when d.d_tranche_status =  'SV' then 'Step Verified'  "+
		    "end) as 'Status', "+
		    "d.d_global_notes_location as 'Global Note Location', "+
		    "(case  "+
		        "when d.tra_registered = 'Y' then 'Registered  (Y)'  "+
		        "when d.tra_registered = 'N' then 'Bearer  (N)'  "+
		    "end) as 'Register Type', "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) as 'Clearstream Holding',  "+
		    "(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)) as 'Euroclear Holding',  "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) + (isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)), "+
		    "0, "+
		    "0, "+
		    "dpl.prog_no as 'Prog. No.', "+
		    "cc.cs_cue_no as 'CID No.' "+
		"from  "+ 
		    "depo_tranche_level d noholdlock, "+
		    "tranche_clearer_holding tch1 noholdlock,  "+
		    "tranche_clearer_holding tch2 noholdlock, "+
		    "depo_issue_level di noholdlock, "+
		    "depo_issr_level issr noholdlock, "+
		    "depo_customer_codes cc noholdlock, "+
		    "depo_programme_level dpl noholdlock, "+
		    "v_tranche vt noholdlock "+
		"where  "+
		    "d.d_tranche_status in ('LI', 'DD', 'PR', 'SV') "+
		    "and d.d_ipa_flag in ('S', 'B', 'D') "+
		    "and tch1.tranche_id =* d.tra_identifier "+
		    "and tch1.contact_id ='782969415818120' "+
		    "and tch2.tranche_id =* d.tra_identifier "+
		    "and tch2.contact_id  = '782969687257310' "+
		    "and d_tra_active_ind = 'Y'  "+
		    "and di.issu_identifier = d.issu_identifier "+
		    "and dpl.prog_identifier = di.prog_identifier "+
		    "and dpl.prog_identifier = issr.prog_identifier  "+
		    "and issr.issr_identifier = di.issr_identifier  "+
		    "and di.issu_identifier = d.issu_identifier "+
		    "and vt.branch_code ='CD' "+
		    "and cc.cs_cust_no = ISNULL(issr.cust_no,dpl.cust_no) "+
		    "and vt.note_type='N' "+
		    "and vt.isin = d.tra_isin "+
		"ORDER BY d.tra_identifier ";
	
	
	static String CMAR_CD_Query="select "+
		    "d.tra_isin as 'ISIN Number', "+
		    "d.d_issue_name as 'Issue Name', "+
		    "d.d_tra_principle_ccy as 'Principal Currency', "+
		    "(case  "+
		        "when d.d_tranche_status = 'LI' then 'Live'  "+
		        "when d.d_tranche_status = 'DD' then 'Defaulted'  "+
		        "when d.d_tranche_status = 'PR' then 'Pending Redeemed'  "+
		        "when d.d_tranche_status =  'SV' then 'Step Verified'  "+
		    "end) as 'Status', "+
		    "d.d_global_notes_location as 'Global Note Location', "+
		    "(case  "+
		        "when d.tra_registered = 'Y' then 'Registered  (Y)'  "+
		        "when d.tra_registered = 'N' then 'Bearer  (N)'  "+
		    "end) as 'Register Type', "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) as 'Clearstream Holding',  "+
		    "(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)) as 'Euroclear Holding',  "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) + (isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)), "+
		    "0, "+
		    "0, "+
		    "dpl.prog_no as 'Prog. No.', "+
		    "cc.cs_cue_no as 'CID No.' "+
		"from  "+ 
		    "depo_tranche_level d noholdlock, "+
		    "tranche_clearer_holding tch1 noholdlock,  "+
		    "tranche_clearer_holding tch2 noholdlock, "+
		    "depo_issue_level di noholdlock, "+
		    "depo_issr_level issr noholdlock, "+
		    "depo_customer_codes cc noholdlock, "+
		    "depo_programme_level dpl noholdlock, "+
		    "v_tranche vt noholdlock "+
		"where  "+
		    "d.d_tranche_status in ('LI', 'DD', 'PR', 'SV') "+
		    "and d.d_ipa_flag in ('S', 'B', 'D') "+
		    "and tch1.tranche_id =* d.tra_identifier "+
		    "and tch1.contact_id ='782969415818120' "+
		    "and tch2.tranche_id =* d.tra_identifier "+
		    "and tch2.contact_id  = '782969687257310' "+
		    "and d_tra_active_ind = 'Y'  "+
		    "and di.issu_identifier = d.issu_identifier "+
		    "and dpl.prog_identifier = di.prog_identifier "+
		    "and dpl.prog_identifier = issr.prog_identifier  "+
		    "and issr.issr_identifier = di.issr_identifier  "+
		    "and di.issu_identifier = d.issu_identifier "+
		    "and vt.branch_code ='CD' "+
		    "and cc.cs_cust_no = ISNULL(issr.cust_no,dpl.cust_no) "+
		    "and vt.note_type='N' "+
		    "and vt.isin = d.tra_isin "+
		    "and    (vt.oasis_issue_type_code not in ('TC') and vt.bare_depo_flag not in ('D')) " +
		"ORDER BY d.tra_identifier ";
	
	
	
	
	static String CSP_EXP="select "+
		    "d.tra_isin as 'ISIN Number', "+
		    "d.d_issue_name as 'Issue Name', "+
		    "d.d_tra_principle_ccy as 'Principal Currency', "+
		    "(case  "+
		        "when d.d_tranche_status = 'LI' then 'Live'  "+
		        "when d.d_tranche_status = 'DD' then 'Defaulted'  "+
		        "when d.d_tranche_status = 'PR' then 'Pending Redeemed'  "+
		        "when d.d_tranche_status =  'SV' then 'Step Verified'  "+
		    "end) as 'Status', "+
		    "d.d_global_notes_location as 'Global Note Location', "+
		    "(case  "+
		        "when d.tra_registered = 'Y' then 'Registered  (Y)'  "+
		        "when d.tra_registered = 'N' then 'Bearer  (N)'  "+
		    "end) as 'Register Type', "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) as 'Clearstream Holding',  "+
		    "(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)) as 'Euroclear Holding',  "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) + (isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)), "+
		    "0, "+
		    "0, "+
		    "dpl.prog_no as 'Prog. No.', "+
		    "cc.cs_cue_no as 'CID No.' "+
		"from  "+
		    "depo_tranche_level d noholdlock, "+
		    "tranche_clearer_holding tch1 noholdlock,  "+
		    "tranche_clearer_holding tch2 noholdlock, "+
		    "depo_issue_level di noholdlock, "+
		    "depo_issr_level issr noholdlock, "+
		    "depo_customer_codes cc noholdlock, "+
		    "depo_programme_level dpl noholdlock, "+
		    "v_tranche vt noholdlock "+
		"where  "+
		    "d.d_tranche_status in ('LI', 'DD', 'PR', 'SV') "+
		    "and d.d_ipa_flag in ('S', 'B', 'D') "+
		    "and tch1.tranche_id =* d.tra_identifier "+
		    "and tch1.contact_id ='782969415818120'  "+
		    "and tch2.tranche_id =* d.tra_identifier "+
		    "and tch2.contact_id  = '782969687257310' "+
		    "and d_tra_active_ind = 'Y'  "+
		    "and di.issu_identifier = d.issu_identifier "+
		    "and dpl.prog_identifier = di.prog_identifier "+
		    "and dpl.prog_identifier = issr.prog_identifier  "+
		    "and issr.issr_identifier = di.issr_identifier  "+
		    "and di.issu_identifier = d.issu_identifier  "+
		    "and cc.cs_cust_no = ISNULL(issr.cust_no,dpl.cust_no) "+
		    "and vt.branch_code ='CD' "+
		    "and vt.note_type='Y' "+
		    "and (select party_name from contact CON noholdlock ,gdoasis_appointments APP noholdlock where APP.tranche_id = vt.tranche_id and CON.contact_id = APP.csp_code) = 'The Bank of New York Mellon' "+
		    "and vt.isin = d.tra_isin "+
		"ORDER BY d.tra_identifier ";
	
	static String CMAR_CSP_EXP="select "+
		    "d.tra_isin as 'ISIN Number', "+
		    "d.d_issue_name as 'Issue Name', "+
		    "d.d_tra_principle_ccy as 'Principal Currency', "+
		    "(case  "+
		        "when d.d_tranche_status = 'LI' then 'Live'  "+
		        "when d.d_tranche_status = 'DD' then 'Defaulted'  "+
		        "when d.d_tranche_status = 'PR' then 'Pending Redeemed'  "+
		        "when d.d_tranche_status =  'SV' then 'Step Verified'  "+
		    "end) as 'Status', "+
		    "d.d_global_notes_location as 'Global Note Location', "+
		    "(case  "+
		        "when d.tra_registered = 'Y' then 'Registered  (Y)'  "+
		        "when d.tra_registered = 'N' then 'Bearer  (N)'  "+
		    "end) as 'Register Type', "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) as 'Clearstream Holding',  "+
		    "(isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)) as 'Euroclear Holding',  "+
		    "(isNull(tch1.holding_amt, 0) + isNull(tch1.temp_balance, 0)) + (isNull(tch2.holding_amt, 0) + isNull(tch2.temp_balance, 0)), "+
		    "0, "+
		    "0, "+
		    "dpl.prog_no as 'Prog. No.', "+
		    "cc.cs_cue_no as 'CID No.' "+
		"from  "+
		    "depo_tranche_level d noholdlock, "+
		    "tranche_clearer_holding tch1 noholdlock,  "+
		    "tranche_clearer_holding tch2 noholdlock, "+
		    "depo_issue_level di noholdlock, "+
		    "depo_issr_level issr noholdlock, "+
		    "depo_customer_codes cc noholdlock, "+
		    "depo_programme_level dpl noholdlock, "+
		    "v_tranche vt noholdlock "+
		"where  "+
		    "d.d_tranche_status in ('LI', 'DD', 'PR', 'SV') "+
		    "and d.d_ipa_flag in ('S', 'B', 'D') "+
		    "and tch1.tranche_id =* d.tra_identifier "+
		    "and tch1.contact_id ='782969415818120'  "+
		    "and tch2.tranche_id =* d.tra_identifier "+
		    "and tch2.contact_id  = '782969687257310' "+
		    "and d_tra_active_ind = 'Y'  "+
		    "and di.issu_identifier = d.issu_identifier "+
		    "and dpl.prog_identifier = di.prog_identifier "+
		    "and dpl.prog_identifier = issr.prog_identifier  "+
		    "and issr.issr_identifier = di.issr_identifier  "+
		    "and di.issu_identifier = d.issu_identifier  "+
		    "and cc.cs_cust_no = ISNULL(issr.cust_no,dpl.cust_no) "+
		    "and vt.branch_code ='CD' "+
		    "and vt.note_type='Y' "+
		    "and (select party_name from contact CON noholdlock ,gdoasis_appointments APP noholdlock where APP.tranche_id = vt.tranche_id and CON.contact_id = APP.csp_code) = 'The Bank of New York Mellon' "+
		    "and vt.isin = d.tra_isin "+
		    "and    (vt.oasis_issue_type_code not in ('TC') and vt.bare_depo_flag not in ('D')) " +
		"ORDER BY d.tra_identifier ";
	
		static String GBP_Query="select exchange_rate " +
				"from fx_rate noholdlock " +
				"where asof_date < getdate() AND ccy_code='GBP' " +
				
				"group by ccy_code " +
				"having asof_date=max(asof_date) ";

}
