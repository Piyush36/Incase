package com.ICSDReport;

import java.util.*;


public class HeaderValues {
	
	
	static  String[][] deadccynames= new String[16][2];
	{deadccynames[0][0]="ATS";
	 deadccynames[1][0]="BEF";
	 deadccynames[2][0]="CYP";
	  deadccynames[3][0]="DEM";
	deadccynames[4][0]="ESP";
	deadccynames[5][0]="FIM";
	deadccynames[6][0]="FRF";
	deadccynames[7][0]="GRD";
	deadccynames[8][0]="IEP";
	deadccynames[9][0]="ITL";
	deadccynames[10][0]="LUF";
	
	deadccynames[11][0]="MTL";
	deadccynames[12][0]="NLG";
	deadccynames[13][0]="PTE";
	deadccynames[14][0]="SKK";
	deadccynames[15][0]="XEU";
	
	deadccynames[0][1]="EUR";
	deadccynames[1][1]="EUR";
	deadccynames[2][1]="EUR";
	deadccynames[3][1]="EUR";
	deadccynames[4][1]="EUR";
	deadccynames[5][1]="EUR";
	deadccynames[6][1]="EUR";
	deadccynames[7][1]="EUR";
	deadccynames[8][1]="EUR";
	deadccynames[9][1]="EUR";
	deadccynames[10][1]="EUR";
	
	deadccynames[11][1]="EUR";
	deadccynames[12][1]="EUR";
	deadccynames[13][1]="EUR";
	deadccynames[14][1]="EUR";
	deadccynames[15][1]="EUR";
	
	
	}
		
	
	static  double[] convertible_rate= new double[16];
	{			
		convertible_rate[0]=13.7603;
		convertible_rate[1]=40.3399;
		convertible_rate[2]=0.585274;
		convertible_rate[3]=1.95583;
		
		convertible_rate[4]=166.386;
		convertible_rate[5]=5.94573;
		convertible_rate[6]=6.55957;
		convertible_rate[7]=340.75;
		convertible_rate[8]=0.787564;
		convertible_rate[9]=1936.27;
		convertible_rate[10]=40.3399;
		convertible_rate[11]=0.4293;
		convertible_rate[12]=2.20371;
		convertible_rate[13]=200.482;
		convertible_rate[14]=30.126;
		convertible_rate[15]=1;	
	}
	
	static  String[] end_date= new String[]{"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Dec 31 2007 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Dec 31 2007 00:00",
		"Sep 21 1999 00:00",
		"Sep 21 1999 00:00",
		"Jan 01 2009 00:00",
		"Sep 21 1999 00:00"
};

	public Map<Integer, String> createICSDHeader(){
		Map <Integer, String> ICSDMAP = new HashMap<Integer, String>();
		ICSDMAP.put(1,"ISIN Number");
		ICSDMAP.put(2,"Issue Name");
		ICSDMAP.put(3,"Principal Currency");
		ICSDMAP.put(4,"Status");
		ICSDMAP.put(5,"Global Note Location");
		ICSDMAP.put(6,"Register Type");
		ICSDMAP.put(7,"Clearstream Holding");
		ICSDMAP.put(8,"Euroclear Holding");
		ICSDMAP.put(9,"Total Holding");
		ICSDMAP.put(10,"Conversion Rate");
		
		ICSDMAP.put(11,"Total Holding in GBP");
		ICSDMAP.put(12,"Prog. No.");
		ICSDMAP.put(13,"CID No.");
		
		
		return ICSDMAP;
	}
	public Map<Integer, String> createGBPSheetHeader()
	{
		Map <Integer, String> GBPSheetMap = new HashMap<Integer, String>();
		
		GBPSheetMap.put(1,"ccy_code");
		GBPSheetMap.put(2,"asof_date");
		GBPSheetMap.put(3,"exchange_rate");
		GBPSheetMap.put(4,"multi_div_ind");
		GBPSheetMap.put(5,"FOR GBP");
		
		return GBPSheetMap;
	}
	
	public Map<Integer, String> createDeadCCYHeader()
	{
		Map <Integer, String> deadccymap = new HashMap<Integer, String>();
		
		deadccymap.put(1,"dead_ccy_code");
		deadccymap.put(2,"convertible_to");
		deadccymap.put(3,"convertible_rate");
		deadccymap.put(4,"end_date");
		deadccymap.put(5,"EUR to GBP");
		
		return deadccymap;
	}
	
	
}
	
