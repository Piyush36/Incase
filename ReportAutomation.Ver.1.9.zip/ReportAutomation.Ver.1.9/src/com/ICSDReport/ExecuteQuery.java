package com.ICSDReport;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ExecuteQuery {
	
	public ResultSet executeQuery(Statement smt,String Query) throws SQLException
	{
		  System.out.println("Started Executing Query"+Query);
		     //Executing Query
		
		 ResultSet r;
		     r=smt.executeQuery(Query);
			 	
			 	//System.out.println("Query Executed");
			 	
			 	return r;
		
		
	}
	
	
	

}
