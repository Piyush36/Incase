package com.ICSDReport;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;

public class Functions{
	public Double CD_BearerCount=0.0;
	public Double CSP_BearerCount=0.0;
	public Double CSK_BearerCount=0.0;
	public Double CD_BearerTotal=0.0;
	public Double CSP_BearerTotal=0.0;
	public Double CSK_BearerTotal=0.0;
	public Double CD_RegisteredCount=0.0;
	public Double CSP_RegisteredCount=0.0;
	public Double CSK_RegisteredCount=0.0;
	public Double CD_RegisteredTotal=0.0;
	public Double CSK_RegisteredTotal=0.0;
	public Double CSP_RegisteredTotal=0.0;
	
	public double CountBearers(XSSFSheet sheet, XSSFSheet sheet2, XSSFSheet sheet3, FormulaEvaluator formulaEval){
		
		//System.out.println("Entered into CountBearers");
		for(int i=1;i<sheet2.getPhysicalNumberOfRows();i++)
		{			
			if((sheet2.getRow(i).getCell(5).getStringCellValue().compareTo("Bearer  (N)"))==0)
				
			{
				++CD_BearerCount;
				CD_BearerTotal=CD_BearerTotal+formulaEval.evaluate(sheet2.getRow(i).getCell(10)).getNumberValue();
				
				//System.out.println("Matched Bearer in Sheet2..Bearer Total:"+CD_BearerTotal);
				
			}
			
		}
		for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
		{			
			if((sheet.getRow(i).getCell(5).getStringCellValue().compareTo("Bearer  (N)"))==0)
				
			{
				++CSP_BearerCount;
				CSP_BearerTotal=CSP_BearerTotal+formulaEval.evaluate(sheet.getRow(i).getCell(10)).getNumberValue();
				//System.out.println("Matched Bearer in sheet..Bearer Total:"+CSP_BearerTotal);
				
			}
			
		}
		for(int i=1;i<sheet3.getPhysicalNumberOfRows();i++)
		{			
			if((sheet3.getRow(i).getCell(5).getStringCellValue().compareTo("Bearer  (N)"))==0)
				
			{
				CSK_BearerCount=CSK_BearerCount+1;
				CSK_BearerTotal=CSK_BearerTotal+formulaEval.evaluate(sheet3.getRow(i).getCell(10)).getNumberValue();
				//System.out.println("Matched Bearer in sheet3 Bearer Total:"+CSK_BearerTotal);
				
			}
			
		}
		
		return CD_BearerCount+CSK_BearerCount+CSP_BearerCount;
	}
	
	public double CountRegisters(XSSFSheet sheet, XSSFSheet sheet2, XSSFSheet sheet3, FormulaEvaluator formulaEval){
		//Double RegisteredCount=0.0;
		//System.out.println("Entered into CountBearers");
		for(int i=1;i<sheet2.getPhysicalNumberOfRows();i++)
		{			
			if((sheet2.getRow(i).getCell(5).getStringCellValue().compareTo("Registered  (Y)"))==0)
				
			{
				++CD_RegisteredCount;
				CD_RegisteredTotal=CD_RegisteredTotal+formulaEval.evaluate(sheet2.getRow(i).getCell(10)).getNumberValue();
				
				//System.out.println("Matched Bearer in Sheet2..Registered Total:"+CD_RegisteredTotal);
				
			}
			
		}
		for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
		{			
			if((sheet.getRow(i).getCell(5).getStringCellValue().compareTo("Registered  (Y)"))==0)
				
			{
				++CSP_RegisteredCount;
				CSP_RegisteredTotal=CSP_RegisteredTotal+formulaEval.evaluate(sheet.getRow(i).getCell(10)).getNumberValue();
				//System.out.println("Matched Registered in sheet..Registered Total:"+CSP_RegisteredTotal);
				
			}
			
		}
		for(int i=1;i<sheet3.getPhysicalNumberOfRows();i++)
		{			
			if((sheet3.getRow(i).getCell(5).getStringCellValue().compareTo("Registered  (Y)"))==0)
				
			{
				CSK_RegisteredCount=CSK_RegisteredCount+1;
				CSK_RegisteredTotal=CSK_RegisteredTotal+formulaEval.evaluate(sheet3.getRow(i).getCell(10)).getNumberValue();
				//System.out.println("Matched Registered in sheet3 Registered Total:"+CSK_RegisteredTotal);
				
			}
			
		}
		
		return CD_RegisteredCount+CSK_RegisteredCount+CSP_RegisteredCount;
	}
	
	
	
	
	
	
	
	
}
