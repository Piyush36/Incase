
package com.ICSDReport;
import healthcheckautomation.GetConnection;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFRow;

import reportautomation.ReportMovementUtil;
import reportautomation.SendingMailUtility;



public class CreateReportICSD extends Functions{
	
	public static void main(String args[])
	{
		CreateReportICSD ob= new CreateReportICSD();
	ob.ICSDReport();
	//ob1.ICSDReport();

	}

	String reportDay = getDateString();
	//Functions f=new Functions();
	static String ICSD;
	
	static String date;
	XSSFRow row=null;
	HeaderValues hValues = new HeaderValues();
	Map<Integer, String> hMap = new HashMap<Integer, String>();
	Map<Integer, String> GBPMAP = new HashMap<Integer, String>();
	 String JDBC_DRIVER = "com.sybase.jdbc3.jdbc.SybDriver";
	 
	String JDBC_STRING = "jdbc:sybase:Tds:xsd0pa27:3025/sdoasgdo";
    //String username = "XBBL5TN", password = "Hello111";
    Connection conn = null;
    ResultSet rs = null;
    ResultSet GBP_result=null;
    		
    Statement stmt = null;
    XSSFWorkbook wb = new XSSFWorkbook(); 
    XSSFWorkbook CMAR = new XSSFWorkbook(); 
    XSSFSheet sheet2 = wb.createSheet("CD");
    XSSFSheet CMAR_sheet2= CMAR.createSheet("CD");
	 XSSFSheet sheet = wb.createSheet("CSP");
	 
	 XSSFSheet sheet3 = wb.createSheet("CSK");
	 XSSFSheet CMAR_sheet3 = CMAR.createSheet("CSK");
	 XSSFSheet sheet4 = wb.createSheet("GBP_Sheet");
	 XSSFSheet CMAR_sheet4 = CMAR.createSheet("GBP_Sheet");
	 XSSFSheet Summary = wb.createSheet("Summary");
	 XSSFSheet CMAR_Summary = CMAR.createSheet("Summary");
	 FormulaEvaluator formulaEval = wb.getCreationHelper().createFormulaEvaluator();
	 FormulaEvaluator CMAR_formulaEval = CMAR.getCreationHelper().createFormulaEvaluator();
	 Functions F= new Functions();
	 
    public void ICSDReport()
    {
    	
    	try{
    	Class.forName(JDBC_DRIVER);
    	//conn = DriverManager.getConnection(JDBC_STRING, username, password);
    	conn = GetConnection.getConnection();
	 	stmt = (Statement) conn.createStatement ();
			 	System.out.println("Connection");
			 	String[] Querylist= new String[5];
			 	Querylist[3]=Queries.EUR_Query;
			 	Querylist[2]=Queries.CSK_Query;
			 	Querylist[0]=Queries.CSP_EXP;
			 	Querylist[1]=Queries.CD_Query;
				Querylist[4]=Queries.GBP_Query;
	sheet.setZoom(105, 100);
	sheet2.setZoom(105, 100);
	sheet3.setZoom(105, 100);
	sheet4.setZoom(105, 100);
	Summary.setZoom(105, 100);
	// FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();

					// suppose your formula is in B3	
				 //Creating and setting Header CellStyle
				 XSSFCellStyle cellStyle = wb.createCellStyle();
				 XSSFCellStyle cellStyle2 = wb.createCellStyle();
				 XSSFCellStyle onezero=wb.createCellStyle();
				 //onezero.setDataFormat(wb.getCreationHelper().createDataFormat().getFormat("#.000"));
				 cellStyle.setFillForegroundColor(HSSFColor.LIGHT_ORANGE.index);
			     cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    
			     cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			     cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			     cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			     cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			     cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			  //   font.setBoldweight(HSSFFont.COLOR_NORMAL);
			    // font.setBold(true);
			     
			     cellStyle2.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			     cellStyle2.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			     cellStyle2.setBorderRight(HSSFCellStyle.BORDER_THIN);
			     cellStyle2.setBorderTop(HSSFCellStyle.BORDER_THIN);
			   
			     onezero.setDataFormat((short) 2);
			    
			    
			     //Creating Fonts
			     Font HeaderFont= wb.createFont();
			     Font DataFont =wb.createFont();
			     HeaderFont.setFontName("Calibri");
			     DataFont.setFontName("Tahoma");
			     HeaderFont.setFontHeightInPoints((short) (11));
			     DataFont.setFontHeightInPoints((short) 10);
			     	HeaderFont.setBoldweight(HSSFFont.COLOR_NORMAL);
			    
			     cellStyle.setFont(HeaderFont);
			     cellStyle2.setFont(DataFont);			     
			  
			        int key = 1;
					int icell = 0;
			     hMap = hValues.createICSDHeader();
			     GBPMAP = hValues.createGBPSheetHeader();
			     XSSFRow rowhead = sheet.createRow((short) 0);
			     XSSFRow rowhead2 = sheet2.createRow((short) 0);
			     XSSFRow rowhead3 = sheet3.createRow((short) 0);
			     XSSFRow rowhead4 = sheet4.createRow((short) 0);
			     Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
			     Iterator<Entry<Integer, String>> itr2 = GBPMAP.entrySet().iterator();
					while(itr.hasNext())
					{
						Entry<Integer, String> entry = itr.next();
						XSSFCell cell=rowhead.createCell(icell);
						XSSFCell cell2=rowhead2.createCell(icell);
						XSSFCell cell3=rowhead3.createCell(icell++);
						
						cell.setCellValue(hMap.get(key));
						cell.setCellStyle(cellStyle);
						cell2.setCellValue(hMap.get(key));
						cell2.setCellStyle(cellStyle);
						cell3.setCellValue(hMap.get(key++));
						cell3.setCellStyle(cellStyle);						
					}
					int icell2=0;
					key=1;
					while(itr2.hasNext())
					{
						Entry<Integer, String> entry = itr2.next();
						XSSFCell cell=rowhead4.createCell(icell2++);
						cell.setCellValue(GBPMAP.get(key++));
						//cell.setCellStyle(cellStyle);
									
					}
					int querylistitr=0;
				 ExecuteQuery eq= new ExecuteQuery();
				 GBP_result=eq.executeQuery(stmt, Querylist[4]);	
				 
					Double GBP_value=(double) 1;
					while(GBP_result.next())
					{
						GBP_value=GBP_result.getDouble(1);
					}
					rs=eq.executeQuery(stmt, Querylist[3]);                  
					System.out.println("GBP Value="+GBP_value);
					System.out.println("");
					//TODO BREAKPOINT
				      prepReport(sheet4,GBP_value,onezero);
				rs=eq.executeQuery(stmt, Querylist[querylistitr++]);
				prepReport(sheet, cellStyle2,onezero,sheet4);
				
				rs=eq.executeQuery(stmt, Querylist[querylistitr++]);
				prepReport(sheet2, cellStyle2,onezero,sheet4);
				rs=eq.executeQuery(stmt, Querylist[querylistitr++]);
				prepReport(sheet3, cellStyle2,onezero,sheet4);	
				System.out.println("prepareSummarySheetforICSD()");
				  prepareSummarySheetforICSD();
				wb.setSheetHidden(3,1);
			/*	while (GBP_result.next()) {
					//Print one row          
					for(int i = 1 ; i <= 1; i++){

					      System.out.print(GBP_result.getDouble(i) + " "); //Print one element of a row

					}

					  System.out.println();//Move to the next line to print the next row.           

					    }*/
				
				
				 
				//GBP_calc(sheet4);
				

				 File directory = new File("C:/Data/Report Automation/Reports/DailyReports/Morning/ICSD & CMAR");
					if(!directory.exists())
					{
						if(directory.mkdirs())
							System.out.println("C:/Data/Report Automation/Reports/DailyReports/Morning/ICSD & CMAR is created");
						else
							System.out.println("Failed to create directory!");
					}
					else
						System.out.println("directory already exist");
					
					File destDirectory = new File("//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ICSD Daily Holdings Report/");
					String ICSDSrcPath = directory.toString() +"/ICSD Daily Holdings Report_GBP "+reportDay+".xls";
					String ICSDDestPath = destDirectory.toString() +"/ICSD Daily Holdings Report_GBP "+reportDay+".xls";
					FileOutputStream fileOut = new FileOutputStream(ICSDSrcPath);
					wb.write(fileOut);
					//fileOut.close();
					System.out.println("ICSD Report prepared successfully for today");
//					wb = new XSSFWorkbook(new FileInputStream(directory.toString() +"/ICSD Daily Holdings Report_GBP "+reportDay+".xls"));
//					int index= wb.getSheetIndex(sheet);
//					wb.removeSheetAt(index);
//				
//					System.out.println("Here1");
//					XSSFCellStyle CMAR_BRStyle=wb.createCellStyle();
//					CMAR_BRStyle.setDataFormat((short)3);
//					CMAR_BRStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//					CMAR_BRStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//					CMAR_BRStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
//					CMAR_BRStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
//					XSSFDataFormat CMAR_Summary_Currency = wb.createDataFormat();
//					XSSFCellStyle CMAR_SummaryDataStyle= wb.createCellStyle();
//					CMAR_SummaryDataStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//					CMAR_SummaryDataStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//					CMAR_SummaryDataStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
//					CMAR_SummaryDataStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
//					CMAR_SummaryDataStyle.setDataFormat(CMAR_Summary_Currency.getFormat("�#,##0.00;-�#,##0.0000"));
//					XSSFRow CMAR_Row=Summary.getRow(2);
//					XSSFCell CMAR_Cell=CMAR_Row.getCell(1);
//					CMAR_Cell.setCellValue("                  �00000.0000");
//					CMAR_Row=Summary.getRow(6);
//					CMAR_Cell=CMAR_Row.getCell(0);
//					Summary.getRow(6).removeCell(CMAR_Cell);
//					CMAR_Cell=CMAR_Row.getCell(1);
//					Summary.getRow(6).removeCell(CMAR_Cell);
//					CMAR_Row=Summary.getRow(12);
//					CMAR_Cell =CMAR_Row.getCell(1);
//					CMAR_Cell.setCellValue("");
//					CMAR_Cell.setCellValue(F.CD_BearerCount+F.CSK_BearerCount);
//					CMAR_Cell.setCellStyle(CMAR_BRStyle);
//					CMAR_Cell=CMAR_Row.getCell(2);
//					CMAR_Cell.setCellValue("");
//					CMAR_Cell.setCellValue(F.CD_BearerTotal+F.CSK_BearerTotal);
//					CMAR_Row=Summary.getRow(13);
//					CMAR_Cell=CMAR_Row.getCell(1);
//					CMAR_Cell.setCellValue(F.CD_RegisteredCount+F.CSK_RegisteredCount);
//					CMAR_Cell.setCellStyle(CMAR_BRStyle);
//					System.out.println("Here");
//					CMAR_Cell=CMAR_Row.getCell(2);
//					CMAR_Cell.setCellValue("");
//					CMAR_Cell.setCellValue(F.CD_RegisteredTotal+F.CSK_RegisteredTotal);
//					String CMAR_reportSrcPath=directory.toString() +"/CMAR Daily Holdings Report_GBP "+reportDay+".xls";
//					String CMAR_reportDestPath=destDirectory.toString() +"/CMAR Daily Holdings Report_GBP "+reportDay+".xls";
//					FileOutputStream fileOut1 = new FileOutputStream(CMAR_reportSrcPath);
//					
//					
//						
//						
//						wb.write(fileOut1);
//						fileOut.close();
//						fileOut1.close();
//						System.out.println("CMAR Report prepared Successfully for today");
//						ReportMovementUtil.copyFiles(CMAR_reportSrcPath, CMAR_reportDestPath);
//						//System.out.println("CMAR Report moved Successfully for today");
						ReportMovementUtil.copyFiles(ICSDSrcPath, ICSDDestPath);
//						System.out.println("ICSD and CMAR Report moved Successfully for today");
//						//Sending Mail through Generic mail sending method
//					    String[] strToList = {"Damien.Kefford@bnymellon.com", "Anna.Field@BNYMellon.com", "Wayne.Lewis@bnymellon.com", "garry.rendell@bnymellon.com"};  //ditdatareconciliation@bnymellon.com
//					    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
//					    String strEmailSubject = "ICSD & CMAR Daily Holdings Report - " + reportDay;
//					    String strEmailBody = "Hi,<br><br> \n " +
//								"Please find the ICSD and CMAR Daily Holdings Report for today " +
//								"<a href='file:" + destDirectory + "'> here.</a> <br>\n";
//					    new SendingMailUtility().sendMail(strEmailSubject, strEmailBody, strToList, strCCList);
//						//new SendingMailForICSD().sendMail();		//Old method for sending mail
    }catch (SQLException sqlEx) {
        sqlEx.printStackTrace ();
    } catch (ClassNotFoundException e1) {
        e1.printStackTrace ();
    }
        catch (Exception e) {
            e.printStackTrace ();
    } finally {
        try {
            if (rs!= null) rs.close();
            if (stmt!= null)stmt.close();
            if (conn!= null) conn.close ();
        } catch (SQLException e) {
            e.printStackTrace ();
        }
    	
    }
    	}
    
   public void prepReport(XSSFSheet sheet5, XSSFCellStyle cellStyle2,XSSFCellStyle onezero, XSSFSheet sheet42) throws SQLException
   {
	   ResultSetMetaData rsmd = rs.getMetaData();
		int columnsNumber = rsmd.getColumnCount();
	     System.out.println(columnsNumber);
	     int rows_in_GBPSheet=sheet42.getPhysicalNumberOfRows();
	     double Cur_GBP_Value=1;
	     
	   //Entering data into DATAROWS
	      int rowid=0;
	     int columnitr=2;
	     String Cur_Name;
	    
	    while(rs.next())
			{
	    	 row = sheet5.createRow(++rowid);
	    	 
	    	 for(int i=0;i<columnsNumber;i++)
	    	 { XSSFCell cell = row.createCell(i);
	    	
	    
	    	 
	    	 if(i==6||i==7||i==8||i==9||i==10)
	    	 { 
	  //test
	    		 if(i==10)
	    		 {
	    			 String strFormula= "PRODUCT(I"+columnitr+":J"+columnitr+")";
	    			 cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
	    			 cell.setCellFormula(strFormula);
	    			 cell.setCellStyle(cellStyle2);
	    			 columnitr++;
	    			 //System.out.println("Product OF I AND J..I:"+i);
	    			 //System.out.println("Cell Value Set:"+cell.getNumericCellValue());
	    		 }
	    	 
	    		 else if(i==9){
	    			  // for(int l=1;l<rows_in_GBPSheet-1;l++)
	    			  // {	
	    			 
	    				   XSSFRow GBP_row;
	    				   Cur_Name=row.getCell(2).getStringCellValue();
	    				   if(Cur_Name.equals("PLZ"))
	    				   {
	    					   Cur_Name="PLN";
	    				   }
	    				   //System.out.println("Currency Name:"+Cur_Name);
	    				   //System.out.println("Rows in GBP_Sheet"+rows_in_GBPSheet);
	    				  for(int GBP_itr=2;i<=rows_in_GBPSheet+4;GBP_itr++)
	    				  {   GBP_row=sheet42.getRow(GBP_itr-1);
	    				  //System.out.println("Currency Name Fetched from first sheet"+Cur_Name+"Cur_Name from GBP sheet"+GBP_row.getCell(0).getStringCellValue());
	    					  if((Cur_Name.compareTo(GBP_row.getCell(0).getStringCellValue().toString()))==0)
	    					  {    XSSFCell F_cell = GBP_row.getCell(4);
	    						  //CellReference cellReference = new CellReference(F_cell);
	    					  CellValue c=formulaEval.evaluate(F_cell);
	    						 Cur_GBP_Value=c.getNumberValue();
	    						//  System.out.println("Currency Name Fetched from first sheet"+Cur_Name+"Cur_Name from GBP sheet"+GBP_row.getCell(0).getStringCellValue());
	    						  //System.out.println("Matched:"+Cur_GBP_Value);
	    						  break;
	    					  }
	    				//  } 
	    			   }
	    				  row.getCell(9).setCellValue(Cur_GBP_Value);
	    				  row.getCell(9).setCellStyle(cellStyle2);

	    		 }
	    		 else{
	    		 cell.setCellValue(rs.getDouble(i+1));
	    		 cell.setCellStyle(cellStyle2);
	    		 //System.out.println("Format Applied");
	    		 }
	    		 
	    	 }else{
	    		 cell.setCellValue(rs.getString(i+1));
	    	  cell.setCellStyle(cellStyle2);
	    	 }
	    	 	//System.out.println("Data entered in cell"+i);
	    	 }
	    	 
	    	 //System.out.println("Data Entered in row ");
	   
			}   
	    for(int k=0;k<13;k++)
	    {
	    sheet5.autoSizeColumn(k);
	    }
   }
	    public void prepReport(XSSFSheet sheet42, Double gBP_value,XSSFCellStyle onezero) throws SQLException
	    {		
	    	System.out.println("In the prep Report Function");
	 	   ResultSetMetaData rsmd = rs.getMetaData();
	 		int columnsNumber = rsmd.getColumnCount();
	 	     //System.out.println(columnsNumber);
	 	   //Entering data into DATAROWS
	 	      int rowid=0;
	 	      int f_itr=2;
	 	    //  String multi_div_ind="D";
	 	    while(rs.next())
	 			{
	 	    	 row = sheet42.createRow(++rowid);
	 	    	XSSFCell GBP_Cell=row.createCell(9); 
	 	    	GBP_Cell.setCellValue(gBP_value);
	 	    	//System.out.println("GBP entered");
	 	    	 for(int i=0;i<columnsNumber+1;i++)
	 	    	 { XSSFCell cell = row.createCell(i);
	 	    	String strFormula;
	 	    	if(i==4)
	 	    	{	
	 	    		 //String strFormula="IF(D"+f_itr+"="+multi_div_ind+","+"1/(C"+f_itr+"*J"+f_itr+"),C"+f_itr+"/J"+f_itr+")";
	 	    		
	 	    		//CellReference cellReference = new CellReference("D"+rowid);
	 	    		
					XSSFCell GBP_calc = row.getCell(3);
					
					String value=GBP_calc.getStringCellValue();
					//System.out.println(value);
					if(value.equals("D"))
					{
						 strFormula="1/(C"+f_itr+"*J"+f_itr+")"; 
					}
					else
					{
						 strFormula="C"+f_itr+"/J"+f_itr; 
					}

	    			
	 	    		cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
	    			 cell.setCellFormula(strFormula);	
	    			 f_itr++;
	    			
	 	    	}
	 	    	else if(i==2)
	 	    	{
	 	    		cell.setCellValue(rs.getDouble(i+1));
	 	    		cell.setCellStyle(onezero);
	 	    		//System.out.println("style applied on column 2:"+cell.getCellStyle());
	 	    	}
	 	    	else{
	 	    	 cell.setCellValue(rs.getString(i+1));
	 	    	}
	 	    	 	//System.out.println("Data entered in cell"+i);
	 	    	 	
	 	    	 }
	 	    	 
	 	    	 
	 	    	 //System.out.println("Data Entered in row ");
	 	    	 
	 	    	 
	 	   
	 			}   
	 	    
	 	    
	 	  createdeadandremainingrows(sheet42,rowid);
	 	    for(int k=0;k<13;k++)
	 	    {
	 	    sheet42.autoSizeColumn(k);
	 	    }
   }

		private void prepareSummarySheetforICSD() {
			System.out.println("Prepare Summary Sheet Called");
			
			int CD_rowid=1;
			int CSP_rowid=1;
			
			int CSK_rowid=1;
			int Summary_rowid=0 ;
			//HSSFRow CD_total=sheet2.getRow(Summary_rowid);
			XSSFCellStyle SummaryHeaderStyle=wb.createCellStyle();
			XSSFDataFormat Summary_Currency = wb.createDataFormat();
			SummaryHeaderStyle.setFillForegroundColor(HSSFColor.LIGHT_ORANGE.index);
			SummaryHeaderStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		    
			SummaryHeaderStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			SummaryHeaderStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			SummaryHeaderStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			SummaryHeaderStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			SummaryHeaderStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			 XSSFCellStyle SummaryDataStyle=wb.createCellStyle();
			
		    XSSFCellStyle BR=wb.createCellStyle();
		   
		    BR.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    BR.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    BR.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    BR.setBorderTop(HSSFCellStyle.BORDER_THIN);
			//SummaryDataStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			SummaryDataStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			SummaryDataStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			SummaryDataStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			SummaryDataStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			SummaryDataStyle.setDataFormat(Summary_Currency.getFormat("�#,##0.00;-�#,##0.0000"));
			 Font SummaryFont =wb.createFont();
			 SummaryFont.setFontName("Calibri");
		     SummaryFont.setFontHeightInPoints((short) 11);
		     SummaryFont.setBoldweight(HSSFFont.COLOR_NORMAL);
		     SummaryHeaderStyle.setFont(SummaryFont);
		    
			XSSFRow CD_row=sheet2.getRow(CD_rowid);
			XSSFRow CSP_row=sheet.getRow(CSP_rowid);	
			XSSFRow CSK_row=sheet3.getRow(CSK_rowid);
			XSSFRow Summary_row=Summary.createRow(Summary_rowid++);
			XSSFCell Summary_Cell=Summary_row.createCell(1);
			Summary_Cell.setCellStyle(SummaryDataStyle);
			Summary_Cell.setCellValue("GDOasis");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("GDOasis Common Depository Valuation");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			
			Double Total_CD=0.000;
			//HSSFRow CD_Rows=sheet2.getRow(1);
			XSSFCell CD_Cell;
			CellValue C;
			
			//System.out.println("CD Cell Value: "+C.getNumberValue());
			
			System.out.println("Total Rows in CD:"+sheet2.getPhysicalNumberOfRows());
			for(int i=1;i<sheet2.getPhysicalNumberOfRows();i++)
			{   
				//System.out.println("Row No. " + i);
				CD_row=sheet2.getRow(CD_rowid++);
				CD_Cell=CD_row.getCell(10);
				 C=formulaEval.evaluate(CD_Cell);
				Total_CD=Total_CD+C.getNumberValue();
				//System.out.println("Total CD:"+Total_CD);
				//System.out.println("Here");
				
				
				
			}
			//System.out.println("OUT OF LOOP");
			Summary_Cell.setCellValue(Total_CD);
			Summary_Cell.setCellStyle(SummaryDataStyle);
			//System.out.println("VALUE SET");
			Summary_Cell.setCellStyle(SummaryDataStyle);
			
			//2nd Row
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("GDOasis Common Service Provider Valuation");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			double Total_CSP=0.0;
			XSSFCell CSP_Cell=CSP_row.getCell(10);
			CellValue CSP=formulaEval.evaluate(CSP_Cell);
			
			//System.out.println("CSP Cell Value: "+CSP.getNumberValue());
			
			System.out.println("Total Rows in CSP:"+sheet.getPhysicalNumberOfRows());
			for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
			{   
				//System.out.println("Row No. " + i);
				CSP_row=sheet.getRow(CSP_rowid++);
				CSP_Cell=CSP_row.getCell(10);
				 CSP=formulaEval.evaluate(CSP_Cell);
				Total_CSP=Total_CSP+CSP.getNumberValue();
				//System.out.println("Total CSPD:"+Total_CSP);
			}
			//System.out.println("OUT OF LOOP");
			Summary_Cell.setCellValue(Total_CSP);
			Summary_Cell.setCellStyle(SummaryDataStyle);
			//System.out.println("VALUE SET");
			Summary_Cell.setCellStyle(SummaryDataStyle);
			
		
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("GDOasis Common Safekeeper Provider Valuation");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			double Total_CSK=0.0;
			XSSFCell CSK_Cell=CSK_row.getCell(10);
			CellValue CSK=formulaEval.evaluate(CSK_Cell);
			
			//System.out.println("CSK Cell Value: "+CSK.getNumberValue());
			
			System.out.println("Total Rows in CSK:"+sheet3.getPhysicalNumberOfRows());
			for(int i=1;i<sheet3.getPhysicalNumberOfRows();i++)
			{   
				//System.out.println("Row No. " + i);
				CSK_row=sheet3.getRow(CSK_rowid++);
				CSK_Cell=CSK_row.getCell(10);
				 CSK=formulaEval.evaluate(CSK_Cell);
				Total_CSK=Total_CSK+CSK.getNumberValue();
				//System.out.println("Total CSK:"+Total_CSK);
			}
			//System.out.println("OUT OF LOOP");
			Summary_Cell.setCellValue(Total_CSK);
			Summary_Cell.setCellStyle(SummaryDataStyle);
			//System.out.println("VALUE SET");
			Summary_Cell.setCellStyle(SummaryDataStyle);
			
			Summary_rowid=Summary_rowid+2;
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("Asset Servicing Valuation (GBP)");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			Summary_Cell.setCellValue(Summary.getRow(1).getCell(1).getNumericCellValue()+Summary.getRow(2).getCell(1).getNumericCellValue());
			Summary_Cell.setCellStyle(SummaryDataStyle);
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("Safekeeping Valuation (GBP)");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			Summary_Cell.setCellValue(Summary.getRow(1).getCell(1).getNumericCellValue()+Summary.getRow(3).getCell(1).getNumericCellValue());
			Summary_Cell.setCellStyle(SummaryDataStyle);
			
			Summary_rowid=Summary_rowid+3;
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(1);
			Summary_Cell.setCellValue("# Lines Stock");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(2);
			Summary_Cell.setCellValue("Asset Value");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("Bearer");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			
			
			Summary_Cell.setCellValue(F.CountBearers(sheet,sheet2,sheet3,formulaEval));
			Summary_Cell.setCellStyle(BR);
			Summary_Cell=Summary_row.createCell(2);
			Summary_Cell.setCellValue(F.CD_BearerTotal+F.CSP_BearerTotal+F.CSK_BearerTotal);
			Summary_Cell.setCellStyle(SummaryDataStyle);
			Summary_row=Summary.createRow(Summary_rowid++);
			Summary_Cell=Summary_row.createCell(0);
			Summary_Cell.setCellValue("Registered");
			Summary_Cell.setCellStyle(SummaryHeaderStyle);
			Summary_Cell=Summary_row.createCell(1);
			Summary_Cell.setCellValue(F.CountRegisters(sheet, sheet2, sheet3, formulaEval));
			Summary_Cell.setCellStyle(BR);
			Summary_Cell=Summary_row.createCell(2);
			Summary_Cell.setCellValue(F.CD_RegisteredTotal+F.CSK_RegisteredTotal+F.CSP_RegisteredTotal);
			Summary_Cell.setCellStyle(SummaryDataStyle);
			for(int k=0;k<13;k++)
	 	    { 
	 	    Summary.autoSizeColumn(k);
	 	    }
		}

		

		private void createdeadandremainingrows(XSSFSheet sheet42, int rowid) {
			 System.out.println("Called Function createdeadcurr");
		
			  rowid=rowid++;
		    	XSSFRow row=sheet42.createRow(rowid++);
		    	 
		    	 XSSFCell two_curr=row.createCell(0);
		    	 two_curr.setCellValue("USD");
		    	 row.createCell(4).setCellFormula("1/J2");
		    	 row=sheet42.createRow(rowid++);
		    	 
		    	 row.createCell(0).setCellValue("SHS");
		    	 row.createCell(4).setCellFormula("1/J2");
		    	 
		    	 int n=1;
		    	 int j=1;
		    	 for(int i=0;i<16;i++)
		    	 { row=sheet42.createRow(rowid++);
		    		 for( j=0;j<2;j++)
		    		 {  
		    			
		    			 row.createCell(j).setCellValue(HeaderValues.deadccynames[i][j]);
		    			
		    		 }
		    		 n=j;
		    		 row.createCell(2).setCellValue(HeaderValues.convertible_rate[i]);
		    		 row.createCell(3).setCellValue(HeaderValues.end_date[i]);
		    		 double GBP_for_deadccy=finddeadccyconversion();
		    		 String strFormula="1/C"+rowid+"*"+GBP_for_deadccy;
	    		/*	 cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
	    			 cell.setCellFormula(strFormula);
	    			 cell.setCellStyle(cellStyle2);  */
		    		 XSSFCell GBPCell_for_deadccy=row.createCell(4);
		    		 GBPCell_for_deadccy.setCellFormula(strFormula);
		    		// GBPCell_for_deadccy.setCellValue(GBP_for_deadccy);
		    	 }
		}
	   /* public void GBP_calc(HSSFSheet sheet) throws SQLException
	    {
	    	ResultSetMetaData rsmd = GBP_result.getMetaData();
	 		int columnsNumber = rsmd.getColumnCount();
	 	     System.out.println(columnsNumber);
	 	   //Entering data into DATAROWS
	 	      int rowid=0;
	 	      
	 	    while(GBP_result.next())
	 			{
	 	    	 row = sheet.createRow(++rowid);
	 	    	 
	 	    	 for(int i=0;i<columnsNumber;i++)
	 	    	 { HSSFCell cell = row.createCell(9);
	 	    	
	 	    	
	 	    	 cell.setCellValue(GBP_result.getDouble(i+1));
	 	    	
	 	    	 	System.out.println("Data entered in cell"+i);
	 	    	 }
	 	    	 
	 	    	 System.out.println("Data Entered in row ");
	 	   
	 			}   
	 	    for(int k=0;k<13;k++)
	 	    {
	 	    sheet.autoSizeColumn(k);
	 	    }
	    }
    */

		private double finddeadccyconversion() {
	
		 
			// TODO Auto-generated method stub*/
			//System.out.println("find dead ccy conversion");
		//	int row_itr=0;
			double GBP_for_deadccy=0;
			for(int i = 2;i<174;i++)
			{ XSSFRow find_EUR=sheet4.getRow(i);
				
				XSSFCell find_Cell=find_EUR.getCell(0);
				if(find_Cell.getStringCellValue().equals("EUR"))
				{//System.out.println("Comparing:"+find_Cell.getStringCellValue());
				//System.out.println("Mil gayi");
				//System.out.println("Type:"+find_Cell.getCellType());
				find_Cell=find_EUR.getCell(4);
				 CellValue c=formulaEval.evaluate(find_Cell);
				
				GBP_for_deadccy= c.getNumberValue();
				//System.out.println(GBP_for_deadccy);
				//System.out.println("GBP_for EUR:"+GBP_for_deadccy);
				return GBP_for_deadccy;
			
				}
				
			}
			
			return 0;
			
		}
		private String getDateString() 
		{
			String strDate = null;

			DateFormat dateFormat = new SimpleDateFormat("dd_MMM_yyyy");
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());

			return strDate;
		}
	}
