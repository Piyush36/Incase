package nettingautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailForNettings 
{


	public static void main(String[] args) 
	{
		new SendingMailForNettings().sendMail("");
	}
	public void sendMail(String strNettingMsg)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		Multipart multipart;
		String emailBody;
		String emailSubject;
		String from;
		String emailPort;
		String emailHost;
		String reportDay;
		String strLocationLink;
		try
		{
			reportDay = getTodayDate();
			emailPort = "25";//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

			String[] toEmails = {"ctsd.gdoasis@bnymellon.com"};  															//ditdatareconciliation@bnymellon.com
			//String[] ccEmails = {"ctsd.gdoasis@bnymellon.com"};								//ctsd.gdoasis@bnymellon.com
			//String[] toEmails = {"ditdatareconciliation@bnymellon.com"};
			//String[] ccEmails = {"ctsd.gdoasis@bnymellon.com"};	
			from = "ctsd.gdoasis@bnymellon.com";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();

			multipart = new MimeMultipart();

			emailSubject = "Nettings Status - " + reportDay;

			//if(reportDay != null && reportDay.equals("Monday"))

			emailBody = "Hello All,<br> \n " +
			"<br>\n" +
			"<br>\n" +
			strNettingMsg +
			"\n<br><br>" +
			"\n<br><br>" +
			"<br>Regards," +
			"<br>Abhishek Kumar" +
			"<br>Application Service Delivery" +
			"<br>iNautix Technologies India - A BNY Mellon Company" +
			"<br>Client Technology Solutions : Corporate Trust Technology" +
			"<br>Tel : +1 646 782 3387 ";

			emailMessage.setSubject(emailSubject);
			//emailMessage.setText(emailBody, "text/html");
			//emailMessage.setContent(emailBody, "text/html");
			
			//messageBodyPart.setText(emailBody, "UTF-8", "html");
			messageBodyPart.setText(emailBody);
			messageBodyPart.setContent(emailBody, "text/html");
			multipart.addBodyPart(messageBodyPart);
			emailMessage.setContent(multipart);

			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			/*for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}*/

			Transport.send(emailMessage);

			System.out.println("Email sent successfully for Nettings.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}

	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}

}
