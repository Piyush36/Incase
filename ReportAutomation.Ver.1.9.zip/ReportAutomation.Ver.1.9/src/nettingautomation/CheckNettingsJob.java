package nettingautomation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import reportautomation.GetConnection;
import reportautomation.HeaderValues;
import reportautomation.SendingMailUtility;

public class CheckNettingsJob extends Thread
{
	private static boolean isLastWorkingDay = false;
	volatile Boolean isNettingProcessed = false;
	
	public static void main(String[] args) 
	{
		new CheckNettingsJob().main();
	}
	
	public void main(){
		CheckNettingsJob checkNettings = new CheckNettingsJob();
		checkNettings.setName("Nettings Thread");
		checkNettings.start();
	}
	
	public void run(){
		try{
			while(true){
				checkNettings();
				
				if(!isNettingProcessed){
					Thread.sleep(300000);
					//Thread.sleep(60000);
					//checkNettings();
				}
				else if(isNettingProcessed)
					Thread.currentThread().interrupt();
				
				if(Thread.currentThread().isInterrupted()){
					System.out.println("Thread has been Interrupted Since Nettings is Arrived");
					break;
				}
			}
		}
		catch(InterruptedException exp){
			exp.printStackTrace();
		}
		catch(Exception exp){
			exp.printStackTrace();
		}
	}

	public void checkNettings()
	{
		Connection connection = null;
		
		Statement stmt = null;
		ResultSet resultSet = null;
		
		String strDate = getDate();
		Boolean isNettingArrived = false;
		Boolean mt535_BatchFlag = false;
		Boolean mt535_BatchFlagClearStream = false;
		Boolean mt535_BatchFlagEuroClear = false;
		
		Boolean mt535_Batch_cdFlag1 = false;
		Boolean mt535_Batch_cdFlag2 = false;
		Boolean mt535_Batch_cdFlag3 = false;
		Boolean mt535_Batch_cdFlag4 = false;
		Boolean mt535_Batch_cdFlag5 = false;
		Boolean mt535_Batch_cdFlag6 = false;
		Boolean mt535_Batch_cdFlag = false;
		int nettingCounter = 0;
		String strNettingMsg = null;
		String emailSub = null;
		
		try
		{
			// Check the nettings has arrived       --  Check - 1
			connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(NettingsQuery.strQuery1);
			while(resultSet.next())
			{
				nettingCounter++;
			}
			if(nettingCounter == 4)
			{
				isNettingArrived = true;
			}
			
			System.out.println("Nettings has Arrived - " + isNettingArrived);
			
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
				if(resultSet != null)
					resultSet.close();
				
				if(stmt != null)
					stmt.close();
			}
			catch(SQLException exp)
			{
				exp.printStackTrace();
			}
		}
		
		try
		{
			// Check the correct flag is set as S in swift_mt535_batch       --- Check - 2
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(NettingsQuery.strQuery2);
			
			// if this is the normal day of the month
			if(!isLastWorkingDay)
			{
				while(resultSet.next())
				{
					String strContactId = resultSet.getString(1);
					String strBranchCode = resultSet.getString(2);
					String strProcessFlag = resultSet.getString(3);
					Date lastEditDate = resultSet.getDate(4);
					if((strContactId != null && strContactId.equals("782969415818120")) && (strBranchCode != null && strBranchCode.equals("CD")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_BatchFlag = true;
							}
						}
					}
					
				}			
			}
			// else this is the last working day of the month
			else
			{
				while(resultSet.next())
				{
					String strContactId = resultSet.getString(1);
					String strBranchCode = resultSet.getString(2);
					String strProcessFlag = resultSet.getString(3);
					Date lastEditDate = resultSet.getDate(4);
					if((strContactId != null && strContactId.equals("782969415818120")) && (strBranchCode != null && strBranchCode.equals("CD")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_BatchFlagClearStream = true;
							}
						}
					}
					
					else if((strContactId != null && strContactId.equals("782969687257310")) && (strBranchCode != null && strBranchCode.equals("CD")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_BatchFlagEuroClear = true;
							}
						}
					}
				}	
				
				if(mt535_BatchFlagClearStream && mt535_BatchFlagEuroClear)
				{
					mt535_BatchFlag = true;
				}
			}
			
			System.out.println("Flag S is set in swift_mt535_batch - " + mt535_BatchFlag);
			
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
				if(resultSet != null)
					resultSet.close();
				
				if(stmt != null)
					stmt.close();
			}
			catch(SQLException exp)
			{
				exp.printStackTrace();
			}
		}
		
		// 
		try
		{
			// Check the correct flag is set as S in swift_mt535_batch    ---  Check - 3
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(NettingsQuery.strQuery3);
			
			// if this is the normal day of the month
			if(!isLastWorkingDay)
			{
				while(resultSet.next())
				{
					String strContactId = resultSet.getString(1);
					String strBranchCode = resultSet.getString(2);
					String strProcessFlag = resultSet.getString(3);
					Date lastEditDate = resultSet.getDate(4);
					String strSourceType = resultSet.getString(5);
					
					// For ClearStream and SourceType is CSP
					if((strContactId != null && strContactId.equals("782969415818120")) && (strSourceType != null && strSourceType.equals("CSP")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag1 = true;
							}
						}
					}
					
					// For ClearStream and SourceType is CSP_OTHER
					else if((strContactId != null && strContactId.equals("782969415818120")) && (strSourceType != null && strSourceType.equals("CSP_OTHER")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag2 = true;
							}
						}
					}
					
					// For EuroClear and SourceType is CSP
					else if((strContactId != null && strContactId.equals("782969687257310")) && (strSourceType != null && strSourceType.equals("CSP")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag3 = true;
							}
						}
					}
					
					// For EuroClear and SourceType is CSP_OTHER
					else if((strContactId != null && strContactId.equals("782969687257310")) && (strSourceType != null && strSourceType.equals("CSP_OTHER")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag4 = true;
							}
						}
					}
					
				}
				
				if(mt535_Batch_cdFlag1 && mt535_Batch_cdFlag2 && mt535_Batch_cdFlag3 && mt535_Batch_cdFlag4)
				{
					mt535_Batch_cdFlag = true;
				}
			}
			
			// else this is the last working day of the month
			else
			{

				while(resultSet.next())
				{
					String strContactId = resultSet.getString(1);
					String strBranchCode = resultSet.getString(2);
					String strProcessFlag = resultSet.getString(3);
					Date lastEditDate = resultSet.getDate(4);
					String strSourceType = resultSet.getString(5);
					
					// For ClearStream and SourceType is CSP
					if((strContactId != null && strContactId.equals("782969415818120")) && (strSourceType != null && strSourceType.equals("CSP")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag1 = true;
							}
						}
					}
					
					// For ClearStream and SourceType is CSP_OTHER
					else if((strContactId != null && strContactId.equals("782969415818120")) && (strSourceType != null && strSourceType.equals("CSP_OTHER")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag2 = true;
							}
						}
					}
					
					// For ClearStream and SourceType is INVENTORY
					else if((strContactId != null && strContactId.equals("782969415818120")) && (strSourceType != null && strSourceType.equals("INVENTORY")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag3 = true;
							}
						}
					}
					
					// For EuroClear and SourceType is CSP
					else if((strContactId != null && strContactId.equals("782969687257310")) && (strSourceType != null && strSourceType.equals("CSP")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag4 = true;
							}
						}
					}
					
					// For EuroClear and SourceType is CSP_OTHER
					else if((strContactId != null && strContactId.equals("782969687257310")) && (strSourceType != null && strSourceType.equals("CSP_OTHER")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag5 = true;
							}
						}
					}
					
					// For EuroClear and SourceType is INVENTORY
					else if((strContactId != null && strContactId.equals("782969687257310")) && (strSourceType != null && strSourceType.equals("INVENTORY")))
					{
						String strLastEditDate = lastEditDate.toString();
						if(strLastEditDate != null && strLastEditDate.equals(strDate))
						{
							if(strProcessFlag != null && strProcessFlag.equals("S"))
							{
								mt535_Batch_cdFlag6 = true;
							}
						}
					}
					
				}
				
				if(mt535_Batch_cdFlag1 && mt535_Batch_cdFlag2 && mt535_Batch_cdFlag3 && mt535_Batch_cdFlag4 && mt535_Batch_cdFlag5 && mt535_Batch_cdFlag6)
				{
					mt535_Batch_cdFlag = true;
				}
			
			}
			
			System.out.println("Flag S is set in swift_mt535_batch_cd - " + mt535_Batch_cdFlag);
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
				if(resultSet != null)
					resultSet.close();
				
				if(stmt != null)
					stmt.close();
			}
			catch(SQLException exp)
			{
				exp.printStackTrace();
			}
		}
		
		// nettings has arrived and correct flag S is set for swift_mt535_batch and for swift_mt535_batch_cd
		if(isNettingArrived && mt535_BatchFlag && mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has arrived <br> Correct flag S is set for swift_mt535_batch and for swift_mt535_batch_cd.";
			emailSub = "Nettings Arrived for Today- " + strDate;
		}
		// nettings has not arrived and correct flag S is not set for swift_mt535_batch and for swift_mt535_batch_cd
		else if(!isNettingArrived && !mt535_BatchFlag && !mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has not arrived <br> Flag S is not set for both swift_mt535_batch and for swift_mt535_batch_cd.";
			emailSub = "Nettings Not Arrived also S flag not set for both swift_mt535_batch and swift_mt535_batch_cd - " + strDate;
		}
		// nettings has not arrived but correct flag S is set for swift_mt535_batch but correct flag S is not set for swift_mt535_batch_cd
		else if(!isNettingArrived && mt535_BatchFlag && !mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has not arrived <br> Flag S is not set for swift_mt535_batch_cd <br> Correct flag S is set for swift_mt535_batch";
			emailSub = "Nettings Not Arrived also S flag not set for swift_mt535_batch_cd - " + strDate;
		}
		// nettings has not arrived but correct flag S is not set for swift_mt535_batch but correct flag S is set for swift_mt535_batch_cd
		else if(!isNettingArrived && !mt535_BatchFlag && mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has not arrived <br> Flag S is not set for swift_mt535_batch <br> Correct flag S is set for swift_mt535_batch_cd.";
			emailSub = "Nettings Not Arrived also S flag not set for swift_mt535_batch - " + strDate;
		}
		// nettings has not arrived but correct flag S is set for swift_mt535_batch and for swift_mt535_batch_cd
		else if(!isNettingArrived && mt535_BatchFlag && mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has not arrived <br> Correct flag S is set for swift_mt535_batch and for swift_mt535_batch_cd.";
			emailSub = "Nettings Not Arrived - " + strDate;
		}
		// nettings has arrived but correct flag S is not set for swift_mt535_batch and for swift_mt535_batch_cd
		else if(isNettingArrived && !mt535_BatchFlag && !mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has arrived <br> Flag S is not set for both swift_mt535_batch and swift_mt535_batch_cd.";
			emailSub = "S flag not set for both swift_mt535 tables but Nettings Arrived - " + strDate;
		}
		// nettings has arrived but correct flag S is not set for swift_mt535_batch but correct flag S is set for swift_mt535_batch_cd
		else if(isNettingArrived && !mt535_BatchFlag && mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has arrived but correct flag S is not set for swift_mt535_batch but correct flag S is set for swift_mt535_batch_cd.";
			emailSub = "S flag not set for swift_mt535_batch table but Nettings Arrived - " + strDate;
		}
		// nettings has arrived and correct flag S is set for swift_mt535_batch but correct flag S is not set for swift_mt535_batch_cd
		else if(isNettingArrived && mt535_BatchFlag && !mt535_Batch_cdFlag)
		{
			strNettingMsg = "Nettings has arrived and correct flag S is set for swift_mt535_batch but correct flag S is not set for swift_mt535_batch_cd.";
			emailSub = "S flag not set for swift_mt535_batch_cd table but Nettings Arrived - " + strDate;
		}
		
		//Sending Mail through Generic mail sending method
	    String[] strToList = {"ctsd.gdoasis@bnymellon.com"};  //ditdatareconciliation@bnymellon.com
	    String[] strCCList = {};//{"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
	    //String strEmailSubject = "All Issues Report - ";
	    String strEmailBody = "Hi All,<br><br><br>" + strNettingMsg;
	    new SendingMailUtility().sendMail(emailSub, strEmailBody, strToList, strCCList);
		// Sending Message for nettings
		//new SendingMailForNettings().sendMail(strNettingMsg);
		
		if(isNettingArrived && mt535_BatchFlag && mt535_Batch_cdFlag)
			isNettingProcessed = true;
	}
	
	// This method is used to check the last working day
	private String getDate()
	{
		String strDate = null;
		String strTodayDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");   					//2016-03-31
		Calendar cal = Calendar.getInstance();
		Calendar calToday = Calendar.getInstance();
		
		cal.add(Calendar.DATE, 0);
		calToday.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());
		strTodayDate = dateFormat1.format(calToday.getTime());
		System.out.println("Day of the Report is " + strDate);
		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));
		String strMonth = list.get(1);
		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(strMonth);
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		//System.out.println("Date is : " + intDate);
		System.out.println("Day is : " + dayValue);
		//System.out.println("Month is : " + strMonth);
		//System.out.println("Year is : " + intYear);

		//strMonthOf = strMonth;


		//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
		//cal = Calendar.getInstance();
		
		// If months are of 31 days
		if(strMonth != null && (strMonth.equals("January") || strMonth.equals("March") || strMonth.equals("May") || strMonth.equals("July") || 
				strMonth.equals("August") || strMonth.equals("October") || strMonth.equals("December")))
		{
			if(intDate.equals(29) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(30) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(31))
			{
				isLastWorkingDay = true;
			}
		}

		// if months are of 30 days
		else if(strMonth != null && (strMonth.equals("April") || strMonth.equals("June") ||
				strMonth.equals("September") || strMonth.equals("November")))
		{
			if(intDate.equals(28) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(29) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(30))
			{
				isLastWorkingDay = true;
			}
		}

		// for February
		else if(strMonth != null && (strMonth.equals("February")))
		{
			// Leap Year (29)
			if(intYear != null && ((intYear % 400 == 0) || (intYear % 4 == 0)) && (intYear % 100 != 0))
			{
				if(intDate.equals(27) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(28) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(29))
				{
					isLastWorkingDay = true;
				}
			}
			else
			{
				if(intDate.equals(26) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(27) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(28))
				{
					isLastWorkingDay = true;
				}
			}
		}
		
		System.out.println("Last Working Day - " + isLastWorkingDay);
		System.out.println(strTodayDate);
		return strTodayDate;
	}
}