package nettingautomation;

public class NettingsQuery 
{
	static String strQuery1 = "select * from swift_mt536_in noholdlock where datediff( dd, row_insert_date, getdate()) = 0 " +
									"and (continue_ind = 'LAST' or continue_ind = 'ONLY') " +
										"and ( sender_address like '%CEDELULL%' or sender_address like '%MGTCBE%')";
	
	static String strQuery2 = "select contact_id, branch_code, process_flag, last_edit_date from swift_mt535_batch";
	
	static String strQuery3 = "select contact_id, branch_code, process_flag, last_edit_date, source_type from swift_mt535_batch_cd";
}
