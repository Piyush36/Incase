package nettingautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import reportautomation.HeaderValues;

public class LastWorkingDayUtility {
	private boolean isLastWorkingDay = false;
	
	public static void main(String[] args) {
		LastWorkingDayUtility last = new LastWorkingDayUtility();
		String date = last.getDate();
		System.out.println(date + " is last working day : " + last.isLastWorkingDay);
	}
	private String getDate()
	{
		String strDate = null;
		String strTodayDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");   					//2016-03-31
		Calendar cal = Calendar.getInstance();
		Calendar calToday = Calendar.getInstance();
		
		cal.add(Calendar.DATE, 0);
		calToday.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());
		strTodayDate = dateFormat1.format(calToday.getTime());
		System.out.println("Day of the Report is " + strDate);
		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));
		String strMonth = list.get(1);
		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(strMonth);
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		//System.out.println("Date is : " + intDate);
		System.out.println("Day is : " + dayValue);
		//System.out.println("Month is : " + strMonth);
		//System.out.println("Year is : " + intYear);

		//strMonthOf = strMonth;


		//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
		//cal = Calendar.getInstance();
		
		// If months are of 31 days
		if(strMonth != null && (strMonth.equals("January") || strMonth.equals("March") || strMonth.equals("May") || strMonth.equals("July") || 
				strMonth.equals("August") || strMonth.equals("October") || strMonth.equals("December")))
		{
			if(intDate.equals(29) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(30) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(31))
			{
				isLastWorkingDay = true;
			}
		}

		// if months are of 30 days
		else if(strMonth != null && (strMonth.equals("April") || strMonth.equals("June") ||
				strMonth.equals("September") || strMonth.equals("November")))
		{
			if(intDate.equals(28) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(29) && dayValue.equals("Friday"))
			{
				isLastWorkingDay = true;
			}
			else if(intDate.equals(30))
			{
				isLastWorkingDay = true;
			}
		}

		// for February
		else if(strMonth != null && (strMonth.equals("February")))
		{
			// Leap Year (29)
			if(intYear != null && ((intYear % 400 == 0) || (intYear % 4 == 0)) && (intYear % 100 != 0))
			{
				if(intDate.equals(27) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(28) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(29))
				{
					isLastWorkingDay = true;
				}
			}
			else
			{
				if(intDate.equals(26) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(27) && dayValue.equals("Friday"))
				{
					isLastWorkingDay = true;
				}
				else if(intDate.equals(28))
				{
					isLastWorkingDay = true;
				}
			}
		}
		
		System.out.println("Last Working Day - " + isLastWorkingDay);
		System.out.println(strTodayDate);
		return strTodayDate;
	}
}
