package healthcheckautomation;

public class TestUnix {
	public void testSendCommand()
	{
		System.out.println("sendCommand");

		/**
		 * YOU MUST CHANGE THE FOLLOWING
		 * FILE_NAME: A FILE IN THE DIRECTORY
		 * USER: LOGIN USER NAME
		 * PASSWORD: PASSWORD FOR THAT USER
		 * HOST: IP ADDRESS OF THE SSH SERVER
		 **/
		//String command = "ls FILE_NAME";
		String command = "pwd";
		String userName = "xbblvww";
		String password = "ABH1onl1";
		String connectionIP = "160.254.99.13";
		SSHManager instance = new SSHManager(userName, password, connectionIP, "");

		System.out.println("Username "+userName);
		System.out.println("Password "+password);
		String errorMessage = instance.connect();

		if(errorMessage != null)
			System.out.println(errorMessage);
		else
			System.out.println("Connect Successfully");
		//String expResult = "FILE_NAME\n";
		// call sendCommand for each command and the output 
		//(without prompts) is returned
		String result = instance.sendCommand(command);
		System.out.println(result);
		// close only after all commands are sent
		instance.close();
		//assertEquals(expResult, result);
	}
	public static void main(String[] args) 
	{

		TestUnix t = new TestUnix();
		t.testSendCommand();
	}

}
