package healthcheckautomation;

import java.io.IOException;
import java.io.InputStream;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class SShconnectionTest 
{
	JSch jsch = new JSch();
	Session session;
	Channel channel;

	public Session openSession() throws Exception 
	{

		if (null == session) 
		{
			session = jsch.getSession("xbblxdt", "160.254.99.13", 22);

			session.setPassword("noida500");
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect(10 * 1000);
			System.out.println("Connection Established");

		}
		return session;
	}

	public Channel openChannel(Session session) throws Exception 
	{

		if (null == channel) 
		{
			channel = session.openChannel("exec");
			System.out.println("Channel is open to execute the commands");
		}

		return channel;
	}

	public String getSession(String command1) throws Exception 
	{

		try 
		{

			session = openSession();
			channel = openChannel(session);

			//Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command1);
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);

			InputStream in = channel.getInputStream();
			channel.connect();

			 byte[] tmp = new byte[1024];
            String readText = "";
            while (true) {
                while (in.available() > 0) {
                    int i = in.read(tmp, 0, 1024);
                    if (i < 0)
                        break;
                    readText = new String(tmp, 0, i);

                    System.out.print(readText);
                }
                if (channel.isClosed()) {
                    System.out.println("exit-status: "
                            + channel.getExitStatus());
                    break;
                }
                try {
                    Thread.sleep(1000);
                } catch (Exception ee) {
                }
            }
			channel.disconnect();
			// session.disconnect();
			System.out.println("DONE");

		} 
		catch (Throwable t) 
		{
			System.out.println(t);
		}
		return null;

	}
	public String sendCommand(String command) throws Exception
	{
		session = openSession();
		channel = openChannel(session);
		StringBuilder outputBuffer = new StringBuilder();

		try
		{
			//Channel channel = sesConnection.openChannel("exec");
			channel =(Channel) session.openChannel("exec");
			((ChannelExec)channel).setCommand(command);

			InputStream commandOutput = (InputStream) ((com.jcraft.jsch.Channel) channel).getInputStream();


			//((com.jcraft.jsch.Channel) channel).connect();

			int readByte = commandOutput.read();

			while(readByte != 0xffffffff)
			{
				outputBuffer.append((char)readByte);
				readByte = commandOutput.read();
			}

			((com.jcraft.jsch.Channel) channel).disconnect();
		}
		catch(IOException ioX)
		{
			//logWarning(ioX.getMessage());
			return null;
		}
		catch(JSchException jschX)
		{
			//logWarning(jschX.getMessage());
			return null;
		}
		session.disconnect();
		return outputBuffer.toString();
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try 
		{
			SShconnectionTest sshcon = new SShconnectionTest();
			String command1 = "pwd";
			String session = sshcon.getSession(command1);
			String session1 = sshcon.getSession("cd");
			/* String command = "export SRL_FILE=/home/20140224/myfile.txt;";
            sshcon.getSession(command);
            sshcon.getSession("env | grep SRL;");
            sshcon.getSession("pwd");*/
			System.out.println(session);
			System.out.println(session1);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}

	}

}