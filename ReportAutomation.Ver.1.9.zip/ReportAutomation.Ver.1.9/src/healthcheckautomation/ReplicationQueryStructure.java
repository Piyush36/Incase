package healthcheckautomation;

import java.util.Map;
import java.util.LinkedHashMap;

public class ReplicationQueryStructure 
{
	public Map<String, String> createReplicationQueryMap()
	{
		Map<String, String> replicationQueryMap = new LinkedHashMap<String, String>();
		replicationQueryMap.put("1", QueryConstant.replicationQuery1);
		replicationQueryMap.put("2", QueryConstant.replicationQuery2);
		replicationQueryMap.put("3", QueryConstant.replicationQuery3);
		replicationQueryMap.put("4", QueryConstant.replicationQuery4);
		replicationQueryMap.put("5", QueryConstant.replicationQuery5);
		replicationQueryMap.put("6", QueryConstant.replicationQuery6);
		replicationQueryMap.put("7", QueryConstant.replicationQuery7);
		replicationQueryMap.put("8", QueryConstant.replicationQuery8);
		replicationQueryMap.put("9", QueryConstant.replicationQuery9);
		replicationQueryMap.put("10", QueryConstant.replicationQuery10);
		replicationQueryMap.put("11", QueryConstant.replicationQuery11);
		replicationQueryMap.put("12", QueryConstant.replicationQuery12);
		replicationQueryMap.put("13", QueryConstant.replicationQuery13);
		replicationQueryMap.put("14", QueryConstant.replicationQuery14);
		replicationQueryMap.put("15", QueryConstant.replicationQuery15);
		replicationQueryMap.put("16", QueryConstant.replicationQuery16);
		replicationQueryMap.put("17", QueryConstant.replicationQuery17);
		replicationQueryMap.put("18", QueryConstant.replicationQuery18);
		replicationQueryMap.put("19", QueryConstant.replicationQuery19);
		replicationQueryMap.put("20", QueryConstant.replicationQuery20);
		replicationQueryMap.put("21", QueryConstant.replicationQuery21);
		replicationQueryMap.put("22", QueryConstant.replicationQuery22);
		replicationQueryMap.put("23", QueryConstant.replicationQuery23);
		replicationQueryMap.put("24", QueryConstant.replicationQuery24);
		replicationQueryMap.put("25", QueryConstant.replicationQuery25);
		replicationQueryMap.put("26", QueryConstant.replicationQuery26);
		replicationQueryMap.put("27", QueryConstant.replicationQuery27);
		replicationQueryMap.put("28", QueryConstant.replicationQuery28);
		replicationQueryMap.put("29", QueryConstant.replicationQuery29);
		replicationQueryMap.put("30", QueryConstant.replicationQuery30);
		replicationQueryMap.put("31", QueryConstant.replicationQuery31);
		replicationQueryMap.put("32", QueryConstant.replicationQuery32);
		replicationQueryMap.put("33", QueryConstant.replicationQuery33);
		replicationQueryMap.put("34", QueryConstant.replicationQuery34);
		replicationQueryMap.put("35", QueryConstant.replicationQuery35);
		replicationQueryMap.put("36", QueryConstant.replicationQuery36);
		replicationQueryMap.put("37", QueryConstant.replicationQuery37);
		replicationQueryMap.put("38", QueryConstant.replicationQuery38);
		replicationQueryMap.put("39", QueryConstant.replicationQuery39);
		replicationQueryMap.put("40", QueryConstant.replicationQuery40);
		replicationQueryMap.put("41", QueryConstant.replicationQuery41);
		replicationQueryMap.put("41", QueryConstant.replicationQuery42);
		return replicationQueryMap;
		
	}
}
