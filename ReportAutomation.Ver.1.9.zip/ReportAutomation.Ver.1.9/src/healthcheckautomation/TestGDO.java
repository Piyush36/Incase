package healthcheckautomation;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;


public class TestGDO {

	public void testSendCommand(String uName,String pword,String connIP,String wls_gdo)
	{
		String userName = uName;
		String password = pword;
		String connectionIP = connIP;
		String commandwls = "";




		//String yesterday = "OASIS_AFRA_"+strDate;

		// System.out.println("sendCommand");
		System.out.println("WLS Status check");
		if(wls_gdo.equals("wls_gdo_01"))
		{

			//commandwls = " wls status>CheckWLSGDO.txt wls_gdo_01";
			commandwls = " wls status wls_gdo_01";
		}
		else
		{
			//commandwls = " wls status>>CheckWLSGDO.txt wls_gdo_02";
			commandwls = " wls status wls_gdo_01";
		}


		System.out.println("CheckGDO 1 start");
		//String command = "ls -ltr>checkGDO1.txt /apps/gdoasis/prd/logs";
		String command = "ls -ltr /apps/gdoasis/prd/logs";





		String command1 = " [ -f /apps/gdoasis/prd/logs/gdoasis.log ] && echo "+"gdoasis.log File is there" +"|| echo "+"gdoasis.log File is Not there";

		System.out.println("Check 2 start");
		//String command2 = "ls -ltr>checkGDO2.txt /prod/gdo/weblogic/config/wld_gdo/logs/";
		String command2 = "ls -ltr /prod/gdo/weblogic/config/wld_gdo/logs/";
		String command3 = " [ -f /prod/gdo/weblogic/config/wld_gdo/logs/"+wls_gdo+".nohuplog ] && echo "+"nohuplog File is there" +"|| echo "+"nohuplog File is Not there";    
		//String command4 = "ls -ltr>checkGDO3.txt /prod/gdo/weblogic/config/wld_gdo/servers/wls_gdo_01/logs/";	     
		String command4 = "ls -ltr /prod/gdo/weblogic/config/wld_gdo/servers/wls_gdo_01/logs/";
		String command5 = "[ -f /prod/gdo/weblogic/config/wld_gdo/servers/"+wls_gdo+"/logs/access.log ] && echo "+"Access.log File is there" +"|| echo "+"Access.log File is Not there";

		System.out.println("Check 3 start"); 
		/*String command6 = "df -k>checkGDO4.txt /apps/gdoasis";   	     
	     String command7 = "df -k>>checkGDO4.txt /prod/gdo";
	     String command8 = "df -k>>checkGDO4.txt /prod";
	     String command9 = "df -k>>checkGDO4.txt /tmp";*/

		String command6 = "df -k /apps/gdoasis";   	     
		String command7 = "df -k /prod/gdo";
		String command8 = "df -k /prod";
		String command9 = "df -k /tmp";





		java.util.Properties config = new java.util.Properties(); 
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try {
			session = jsch.getSession(userName, connectionIP, 22);

			session.setPassword(password);
			session.setConfig(config);
			session.setConfig("PreferredAuthentications", 
			"publickey,keyboard-interactive,password");
			session.connect();
			System.out.println("Connected");

			session.disconnect();
		} catch (JSchException e) {

			e.printStackTrace();
		}

		SSHManager instance = new SSHManager(userName, password, connectionIP, "");
		String errorMessage = instance.connect();

		if(errorMessage != null)
		{
			System.out.println(errorMessage);

		}


		String resultwls = instance.sendCommand(commandwls);

		System.out.println("resultwls :"+ resultwls);

		String result = instance.sendCommand(command);

		System.out.println("result :"+ result);

		String result1 = instance.sendCommand(command1);


		System.out.println("result1 :"+ result1);

		String result2 = instance.sendCommand(command2);


		System.out.println("result2 :"+ result2);


		String result3 = instance.sendCommand(command3);

		System.out.println("result3 :"+ result3);

		String result4 = instance.sendCommand(command4);

		System.out.println("result4 :"+ result4);

		String result5 = instance.sendCommand(command5);

		System.out.println("result5 :"+ result5);

		String result6 = instance.sendCommand(command6);

		System.out.println("result6 :"+ result6);

		String result7 = instance.sendCommand(command7);

		System.out.println("result7 :"+ result7);

		String result8 = instance.sendCommand(command8);

		System.out.println("result8 :"+ result8);

		String result9 = instance.sendCommand(command9);

		System.out.println("result9 :"+ result9);



		// close only after all commands are sent
		instance.close();
		//assertEquals(expResult, result);
	}


	public void testA27(String uName,String pword,String connIP,String strDate)
	{
		String userName = uName;
		String password = pword;
		String connectionIP = connIP;
		String yesterday = "OASIS_AFRA_"+strDate;

		System.out.println("XSD00A27");
		//String commandA27 = "ls -ltr >checkA27.txt /apps/gdoasis/prd/ndmout";
		String commandA27 = "ls -ltr /apps/gdoasis/prd/ndmout";

		String commandA27_1 = " [ -d /apps/gdoasis/prd/ndmout/intransit ] && echo "+"intransit directory is there" +"|| echo "+"intransit directory is Not there";
		/*String commandA27_2 = "ls -ltr >checkA27_1.txt /apps/gdoasis/prd/ndmout";
	     String commandA27_3 = "ls -ltr >checkA27_2.txt /apps/gdoasis/prd/logs";

	     String commandA27_4 = "df -k>checkGDO4_3.txt /apps/gdoasis";   	     
	     String commandA27_5 = "df -k>>checkGDO4_3.txt /prod/gdo";
	     String commandA27_6 = "df -k>>checkGDO4_3.txt /prod";
	     String commandA27_7 = "df -k>>checkGDO_3.txt /tmp";

	     String commandA27_8 = "ls -ltr /apps/gdoasis/prd/ndmout/archive*"+yesterday+"*|wc -l>checkGDO_Afra_xml.txt";
		 */
		String commandA27_2 = "ls -ltr /apps/gdoasis/prd/ndmout";
		String commandA27_3 = "ls -ltr /apps/gdoasis/prd/logs";

		String commandA27_4 = "df -k /apps/gdoasis";   	     
		String commandA27_5 = "df -k /prod/gdo";
		String commandA27_6 = "df -k /prod";
		String commandA27_7 = "df -k /tmp";

		String commandA27_8 = "ls -ltr /apps/gdoasis/prd/ndmout/archive/*"+yesterday+"*|wc -l";

		java.util.Properties config = new java.util.Properties(); 
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try {
			session = jsch.getSession(userName, connectionIP, 22);

			session.setPassword(password);
			session.setConfig(config);
			session.setConfig("PreferredAuthentications", 
			"publickey,keyboard-interactive,password");
			session.connect();
			System.out.println("Connected");


			session.disconnect();
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SSHManager instance = new SSHManager(userName, password, connectionIP, "");
		String errorMessage = instance.connect();

		if(errorMessage != null)
		{
			System.out.println(errorMessage);
			//fail();
		}


		String resultA27 = instance.sendCommand(commandA27);

		System.out.println("resultA27 :"+ resultA27);

		String resultA27_1 = instance.sendCommand(commandA27_1);

		System.out.println("resultA27_1 :"+ resultA27_1);

		String resultA27_2 = instance.sendCommand(commandA27_2);

		System.out.println("resultA27_2 :"+ resultA27_2);

		String resultA27_3 = instance.sendCommand(commandA27_3);

		System.out.println("resultA27_3 :"+ resultA27_3);

		String resultA27_4 = instance.sendCommand(commandA27_4);

		System.out.println("resultA27_4 :"+ resultA27_4);

		String resultA27_5 = instance.sendCommand(commandA27_5);

		System.out.println("resultA27_5 :"+ resultA27_5);

		String resultA27_6 = instance.sendCommand(commandA27_6);

		System.out.println("resultA27_6 :"+ resultA27_6);

		String resultA27_7 = instance.sendCommand(commandA27_7);

		System.out.println("resultA27_7 :"+ resultA27_7);

		String resultA27_8 = instance.sendCommand(commandA27_8);

		System.out.println("resultA27_8 :"+ resultA27_8);



		// close only after all commands are sent
		instance.close();
		//assertEquals(expResult, result);
	}

	public String readpassword()
	{
		return readpassword();

	}

	public static void main(String args[]) throws IOException{
		TestGDO t=new TestGDO();

		String wls_gdo_01="wls_gdo_01";
		String wls_gdo_02="wls_gdo_02";



		String strDate = null;


		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");


		Calendar calendar = Calendar.getInstance();
		int day = calendar.get(Calendar.DAY_OF_WEEK);

		System.out.println("Day is :"+day);

		Calendar cal = Calendar.getInstance();

		if(day==2)
		{
			cal.add(Calendar.DATE, -3);
		}
		else 
		{
			cal.add(Calendar.DATE, -1);
		}


		strDate = dateFormat.format(cal.getTime());
		String yesterday = "OASIS_AFRA_"+strDate;

		System.out.println("Yesterday's date :"+strDate);

		System.out.println("modified date :"+yesterday);

		System.out.println("Enter username : ");
		Scanner n = new Scanner(System.in);
		String username=n.next();
		System.out.println("Username :"+username);

		System.out.println("Enter Password : ");
		Scanner n1 = new Scanner(System.in);
		String password =n1.next();

		//System.out.println("password :"+password);



		/*//System.out.println("Enter Password :");
		    char[] passString = console.readPassword("Enter Password :");
		    String password = new String(passString );
		    Arrays.fill(password,' ');*/
		/*System.out.println("Enter : ");
		ConsoleReader console1 = new ConsoleReader();
		String password = console1.readLine(new Character('*'));*/



		//t.testSendCommand(username,password,"160.254.55.43",wls_gdo_01);
		t.testSendCommand(username,password,"160.254.55.50",wls_gdo_02);

		t.testA27(username,password, "160.254.55.57",strDate);

	}


}
