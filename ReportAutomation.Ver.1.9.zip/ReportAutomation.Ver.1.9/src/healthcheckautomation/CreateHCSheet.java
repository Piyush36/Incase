package healthcheckautomation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import reportautomation.HeaderValues;

public class CreateHCSheet 
{
	public static void main(String[] args) 
	{
	//	new CreateHCSheet().createHCSheet();
	}
	public void createHCSheet(Map<String, String> dbQueryMap, Map<String, String> unixResultMap)
	{
		FileInputStream file = null;
		FileOutputStream fileOut = null;
		XSSFSheet sheet1 = null;
		XSSFSheet sheet2 = null;
		XSSFRow row = null;
		//int rowCount = 13;
		int cellCount = 4;
		int cellCountPre = 3;
		int failedCheck = 0;
		int threshold;
		try
		{
			file = new FileInputStream(new File("C:/Data/HC Automation/GDO Morning Health Check Report - EMEA  APAC - Temp.xlsx"));
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			String reportDay = getDateString();
		
			
			//For Highlighting Failed Cell
			XSSFCellStyle style = workbook.createCellStyle();
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			style.setFillForegroundColor(HSSFColor.RED.index);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			style.setWrapText(true);
			style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
			//style.setFillForegroundColor(XSSFColor.YELLOW_25_PERCENT.index);
			
			//For Highlighting Manual check cell
			XSSFCellStyle style1 = workbook.createCellStyle();
			style1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			style1.setFillForegroundColor(HSSFColor.YELLOW.index);
			style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style1.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			style1.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
			style1.setWrapText(true);
			
			sheet1 = workbook.getSheetAt(0);
		    row = sheet1.getRow(3);
		    XSSFCell cell = row.getCell(6);
		    cell.removeCellComment();
		    cell.setCellValue(reportDay);
		    
		    sheet2 = workbook.getSheetAt(1);
		    XSSFRow row1 = sheet2.getRow(4);
		    XSSFCell cell1 = row1.getCell(0);
		    cell1.removeCellComment();
		    cell1.setCellValue(reportDay);
		    
		    int rowcount = 16;
		    // Replication
		    String strReplication = dbQueryMap.get("Replication");
		    if(strReplication != null && !strReplication.equals("Replication Successfull"))
		    {
		    	XSSFRow row2 = sheet2.getRow(rowcount);
			    XSSFCell cell2 = row2.getCell(cellCountPre);
			    XSSFCell celldesc2 = row2.getCell(cellCount);
			    celldesc2.setCellValue("Please check output in console, if any mismatch please raise a P1 INC and involve Darren also");
			    cell2.removeCellComment();
			    cell2.setCellValue("Fail");
			    cell2.setCellStyle(style);
			    failedCheck++;
		    }
		    
		    // Alert Processing
		    String strAlertsProcessing = dbQueryMap.get("AlertsProcessing");
		    XSSFRow row3 = sheet2.getRow(++rowcount);
		    XSSFCell cell3 = row3.getCell(cellCount);
		    cell3.removeCellComment();
		    cell3.setCellValue(strAlertsProcessing);
		    threshold=Integer.parseInt(strAlertsProcessing);
		    if(threshold>7000){
		    	cell3.setCellStyle(style1);
		    	cell3.setCellValue(strAlertsProcessing+"\n Please compare last 3 days data and validate the same in table");
		    }
		    
		    //Outgoing Swift
		    String strOutgoingSwifts = dbQueryMap.get("OutgoingSwifts");
		    Integer iOutgoingSwifts = Integer.parseInt(strOutgoingSwifts);
		    if(iOutgoingSwifts > 0)
		    {
		    	XSSFRow row4 = sheet2.getRow(++rowcount);
			    XSSFCell cell4 = row4.getCell(cellCount);
			    cell4.removeCellComment();
			    cell4.setCellStyle(style);
			    cell4.setCellValue(strOutgoingSwifts + "\n Run below query after 5 min and if count is zero pass it \n select count(*) from outgoing_swift_log where processed_flg = 'N'");
			    XSSFCell cell5 = row4.getCell(cellCountPre);
			    cell5.removeCellComment();
			    cell5.setCellValue("Fail");
			    cell5.setCellStyle(style);
			    failedCheck++;
		    }
		    else
		    {
		    	XSSFRow row4 = sheet2.getRow(++rowcount);
			    XSSFCell cell4 = row4.getCell(cellCount);
			    cell4.removeCellComment();
			    cell4.setCellValue(strOutgoingSwifts);
		    }
		    
		    //Last Outgoing Swift
		    String strLastOutgoingSwift = dbQueryMap.get("lastOutgoingSwift");
		    XSSFRow row5 = sheet2.getRow(++rowcount);
		    XSSFCell cell6 = row5.getCell(cellCount);
		    cell6.removeCellComment();
		    cell6.setCellValue(strLastOutgoingSwift);
		    
		    //Incoming Swift
		    String strUnprocessedIncomingSwift = dbQueryMap.get("unprocessedIncomingSwift");
		    Integer iUnprocessedIncomingSwift = Integer.parseInt(strUnprocessedIncomingSwift);
		    
		    XSSFRow row6 = sheet2.getRow(++rowcount);
		    XSSFCell cell7 = row6.getCell(cellCount);
		    cell7.removeCellComment();
		    cell7.setCellValue("MT565 - " + strUnprocessedIncomingSwift);
		    if(iUnprocessedIncomingSwift > 0)
		    {   
			    XSSFCell cell8 = row6.getCell(cellCountPre);
			    cell7.setCellValue("MT565 - " + strUnprocessedIncomingSwift+"\n Please contact MIDYS support team to fetch the details \n Send the same info to business");
			    cell7.setCellStyle(style);
			    cell8.removeCellComment();
			    cell8.setCellStyle(style);
			    cell8.setCellValue("Fail");
			    failedCheck++;
		    }
		    
		    //Last Incoming Swift   
		    String strLastIncomingSwift = dbQueryMap.get("lastIncomingSwift");
		    XSSFRow row7 = sheet2.getRow(++rowcount);
		    XSSFCell cell9 = row7.getCell(cellCount);
		    cell9.removeCellComment();
		    cell9.setCellValue(strLastIncomingSwift);
		    
		    //Payment Instruction
		    String strPaymentInstruction = dbQueryMap.get("paymentInstruction");
		    Integer iPaymentInstruction = Integer.parseInt(strPaymentInstruction);
		    
		    XSSFRow row8 = sheet2.getRow(++rowcount);
		    XSSFCell cell10 = row8.getCell(cellCount);
		    cell10.removeCellComment();
		    cell10.setCellValue(strPaymentInstruction);
		    if(iPaymentInstruction > 2)
		    {   
			    XSSFCell cell11 = row8.getCell(cellCountPre);
			    cell11.removeCellComment();
			    cell11.setCellValue("Fail");
			    cell11.setCellStyle(style);
			    failedCheck++;
		    }
		    
		    //Last Payment Instruction
		    String strLastPaymentInstruction = dbQueryMap.get("lastPaymentInstruction");
		    XSSFRow row9 = sheet2.getRow(++rowcount);
		    XSSFCell cell12 = row9.getCell(cellCount);
		    cell12.removeCellComment();
		    cell12.setCellValue(strLastPaymentInstruction);
		    
		    //Duplicate ISIN
		    String strDuplicateISIN = dbQueryMap.get("duplicateISIN");
		    if(strDuplicateISIN != null)
		    {
		    	XSSFRow row10 = sheet2.getRow(++rowcount);
			    XSSFCell cell13 = row10.getCell(cellCount);
			    cell13.removeCellComment();
			    cell13.setCellValue(strDuplicateISIN+"/n Please send an email to Graeme and Damien along with ISIN details");
			    cell13.setCellStyle(style);
			    
			    XSSFCell cell14 = row10.getCell(cellCountPre);
			    cell14.removeCellComment();
			    cell14.setCellValue("Fail");
			    cell14.setCellStyle(style);
			    failedCheck++;
		    }
		    else
		    {
		    	++rowcount;
		    }
		    
		    //Amortization
		    String strAmortization = dbQueryMap.get("amortization");
		    Integer iAmortization = Integer.parseInt(strAmortization);
		    
		    XSSFRow row11 = sheet2.getRow(++rowcount);
		    XSSFCell cell15 = row11.getCell(cellCount);
		    cell15.removeCellComment();
		    cell15.setCellValue(strAmortization);
		    if(iAmortization > 2)
		    {   
			    XSSFCell cell16 = row11.getCell(cellCountPre);
			    cell16.removeCellComment();
			    cell16.setCellValue("Fail");
			    cell16.setCellStyle(style);
			    failedCheck++;
		    }
		    
		    //Unprocessed MT536 
		    String strUnprocessedMT536 = dbQueryMap.get("unprocessedMT536");
		    if(strUnprocessedMT536 != null && strUnprocessedMT536.equals("Fail"))
		    {
		    	XSSFRow row12 = sheet2.getRow(++rowcount);
			    XSSFCell cell17 = row12.getCell(cellCount);
			    cell17.removeCellComment();
			    cell17.setCellValue("Check in database for MT536 messages which are not processed");
			    cell17.setCellStyle(style);
			    
			    XSSFCell cell18 = row12.getCell(cellCountPre);
			    cell18.removeCellComment();
			    cell18.setCellValue(strUnprocessedMT536);
			    cell18.setCellStyle(style);
			    failedCheck++;
		    }
		    else
		    {
		    	++rowcount;
		    }
		    
		    //Incoming Swift
		    String strIncomingSwift = dbQueryMap.get("incomingSwift");
		    XSSFRow row13 = sheet2.getRow(++rowcount);
		    XSSFCell cell19 = row13.getCell(cellCount);
		    cell19.removeCellComment();
		    cell19.setCellValue(strIncomingSwift);
		    
		    //Outgoing Swift
		    String strOutgoingSwift = dbQueryMap.get("outgoingSwift");
		    XSSFRow row14 = sheet2.getRow(++rowcount);
		    XSSFCell cell20 = row14.getCell(cellCount);
		    cell20.removeCellComment();
		    cell20.setCellValue(strOutgoingSwift);
		    
		    //Invalid Currencies
		    String strInvalidCurrencies = dbQueryMap.get("invalidCurrencies");
		    if(strInvalidCurrencies != null && strInvalidCurrencies.equals("Fail"))
		    {
		    	XSSFRow row15 = sheet2.getRow(++rowcount);
		    	XSSFCell cell21 = row15.getCell(cellCount);
		    	cell21.removeCellComment();
		    	cell21.setCellValue("Check Database for Invalid Currencies and inform the business accordingly");
		    	cell21.setCellStyle(style);
		    	
		    	XSSFCell cell22 = row15.getCell(cellCountPre);
		    	cell22.removeCellComment();
		    	cell22.setCellValue("Fail");
			    failedCheck++;
		    }
		    else
		    {
		    	++rowcount;
		    }
		    
		    //Common Code
		    String strCommonCode = dbQueryMap.get("commonCode");
		    if(strCommonCode != null && strCommonCode.equals("Fail"))
		    {
		    	XSSFRow row16 = sheet2.getRow(++rowcount);
			    XSSFCell cell23 = row16.getCell(cellCount);
			    cell23.removeCellComment();
			    cell23.setCellValue("Check Database for Common code and inform the business accordingly");
			    cell23.setCellStyle(style);
			    
			    XSSFCell cell24 = row16.getCell(cellCountPre);
			    cell24.removeCellComment();
			    cell24.setCellValue("Fail");
			    failedCheck++;
		    }
		    else
		    {
		    	++rowcount;
		    }
		    
		    //ISS Alert
		    /*String strISSAlert = dbQueryMap.get("issAlert");
		    XSSFRow row17 = sheet2.getRow(++rowcount);
		    XSSFCell cell25 = row17.getCell(cellCount);
		    cell25.removeCellComment();
		    cell25.setCellValue(strISSAlert);*/
		    
		    //Production DB Free Space
		    String strDBFreeSpace = dbQueryMap.get("DBFreeSpace");
		    XSSFRow row17 = sheet2.getRow(++rowcount);
		    XSSFCell cell25 = row17.getCell(cellCount);
		    cell25.removeCellComment();
		    cell25.setCellValue(strDBFreeSpace);
		    
		    //% Production DB Free Space
		    String strDBFreeSpaceInPercent = dbQueryMap.get("DBFreeSpaceInPercent");
		    XSSFRow row18 = sheet2.getRow(++rowcount);
		    XSSFCell cell26 = row18.getCell(cellCount);
		    cell26.removeCellComment();
		    cell26.setCellValue(strDBFreeSpaceInPercent);
		    System.out.println(strDBFreeSpaceInPercent);
		   ++rowcount;
		   ++rowcount;
		    
		    // From Here UNIX result will be copied into HC sheet
		    
		    // WLS Logs
		    /*String strWLSLogs = unixResultMap.get("wlsLogs31") + "\n" + unixResultMap.get("wlsLogs32");
		    XSSFRow row20 = sheet2.getRow(35);
		    XSSFCell cell28 = row20.getCell(cellCount);
		    cell28.removeCellComment();
		    cell28.setCellValue(strWLSLogs);*/
		    
		    //int rowcount = 35;
		    //It is started from row 35
		    // AFRA xml
		    String strAFRAxml = unixResultMap.get("AFRA xml");
		    XSSFRow row20 = sheet2.getRow(++rowcount);
		    XSSFCell cell28 = row20.getCell(cellCount);
		    cell28.removeCellComment();
		    cell28.setCellValue(strAFRAxml);
		    
		    // GD Oasis application Logs
		    String strGDOasisLogs = unixResultMap.get("gdoLogs_r21mp1v") + "\n" + unixResultMap.get("gdoLogs_r21mp2v");
		    XSSFRow row21 = sheet2.getRow(++rowcount);
		    XSSFCell cell29 = row21.getCell(cellCount);
		    cell29.removeCellComment();
		    cell29.setCellValue(strGDOasisLogs);
		    
		    // Database Unix File System Free Space
		    String strDBUnixFreeSpace = unixResultMap.get("freeSpaceA27");
		    XSSFRow row22 = sheet2.getRow(++rowcount);
		    XSSFCell cell30 = row22.getCell(cellCount);
		    cell30.removeCellComment();
		    cell30.setCellValue(strDBUnixFreeSpace);
		    
		    // Application Server Unix File system Free space
		    String strAppServerFreeSpace = unixResultMap.get("freeSpace_r21mp1v") + "\n" + unixResultMap.get("freeSpace_r21mp2v");
		    XSSFRow row23 = sheet2.getRow(++rowcount);
		    XSSFCell cell31 = row23.getCell(cellCount);
		    cell31.removeCellComment();
		    cell31.setCellValue(strAppServerFreeSpace);
		    
		    // Check NDM file system space
		    String strNDMFreeSpace = unixResultMap.get("NDM Free Space");
		    XSSFRow row24 = sheet2.getRow(++rowcount);
		    XSSFCell cell32 = row24.getCell(cellCount);
		    cell32.removeCellComment();
		    cell32.setCellValue(strNDMFreeSpace);
		    
		    // Check file transfer to/from XSD0PA27
		    String strFileTransferOfA27 = unixResultMap.get("Check file transfer to/from XSD0PA27");
		    XSSFRow row25 = sheet2.getRow(++rowcount);
		    XSSFCell cell33 = row25.getCell(cellCount);
		    cell33.removeCellComment();
		    cell33.setCellValue(strFileTransferOfA27);

		    String checkDay = this.getDayString();
		 // Highlighting to do CMDB check manually on Thursday
		    if(checkDay != null && checkDay.equals("Thursday"))
			{
				XSSFRow row26 = sheet2.getRow(++rowcount);
			    XSSFCell cell34 = row26.getCell(cellCount);
			    cell34.removeCellComment();
			    cell34.setCellValue("Check CMDB portal (http://dsed/CMDB/CMDBCalendar.aspx) \n for any changes affecting our servers");
			    row26.getCell(cellCountPre).removeCellComment();
			    cell34.setCellStyle(style1);
			    row26.getCell(cellCountPre).setCellStyle(style1);
			}
		    else
		    {
		    	++rowcount;
		    }
 
		 // Highlighting to do LMS Data log check manually on Monday	
		    if(checkDay.equals("Monday"))
			{
				XSSFRow row27 = sheet2.getRow(++rowcount);
			    XSSFCell cell35 = row27.getCell(cellCount);
			    cell35.removeCellComment();
			    cell35.setCellValue("Check for Last Friday's  LMS_CT_EOD_ File manually at \n /apps/gdoasis/prd/ndmin/archive and tables related to it are updated or not");
			    row27.getCell(cellCountPre).removeCellComment();
			    cell35.setCellStyle(style1);
			    row27.getCell(cellCountPre).setCellStyle(style1);
			}
		    		    
		    
		    //Check Failed
		    XSSFRow row28 = sheet2.getRow(5);
		    XSSFCell cell36 = row28.getCell(4);
		    cell36.removeCellComment();
		    cell36.setCellValue(failedCheck);
		    
		    file.close();
		    
		    String reportPath = "C:/Data/HC Automation/GDO Morning Health Check Report - EMEA  APAC - " + reportDay + ".xlsx";
		    fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		    
		    System.out.println("Sheet is written at the loaction - C:\\Data\\HC Automation");
		}
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
	}
	private String getDateString() 
	{
		String strDate = null;

		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		return strDate;
	}
	private String getDayString() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);
		
		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);

		return dayValue;
	}
	
}