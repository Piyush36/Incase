package healthcheckautomation;

import java.util.LinkedHashMap;
import java.util.Map;

public class ReplicationPrintStructure {

	public Map<String, String> createReplicationPrintMap(){
		
		Map<String, String> ReplicationPrintMap = new LinkedHashMap<String, String>();
		ReplicationPrintMap.put("1", "appointment_types:  ");
		ReplicationPrintMap.put("2", "country_codes:  ");
		ReplicationPrintMap.put("3", "currency_codes:  ");
		ReplicationPrintMap.put("4", "currency_holidays:  ");
		ReplicationPrintMap.put("5", "destruction_codes:  ");
		ReplicationPrintMap.put("6", "history_codes:  ");
		ReplicationPrintMap.put("7", "institution_type:  ");
		ReplicationPrintMap.put("8", "institution_details:  ");
		ReplicationPrintMap.put("9", "instrument_class:  ");
		ReplicationPrintMap.put("10", "instrument_types:  ");
		ReplicationPrintMap.put("11", "interest_freq_codes:  ");
		ReplicationPrintMap.put("12", "interest_types:  ");
		ReplicationPrintMap.put("13", "tra_deal:  ");
		ReplicationPrintMap.put("14", "reg_holding:  ");
		ReplicationPrintMap.put("15", "tra_verification:  ");
		ReplicationPrintMap.put("16", "programme_level:  ");
		ReplicationPrintMap.put("17", "claim_hdr:  ");
		ReplicationPrintMap.put("18", "claim_dtl:  ");
		ReplicationPrintMap.put("19", "tra_history:  ");
		ReplicationPrintMap.put("20", "vault:  ");
		ReplicationPrintMap.put("21", "vault_leg:  ");
		ReplicationPrintMap.put("22", "pro_appointments:  ");
		ReplicationPrintMap.put("23", "issr_appointments:  ");
		ReplicationPrintMap.put("24", "issue_appointments:  ");
		ReplicationPrintMap.put("25", "industry_codes:  ");
		ReplicationPrintMap.put("26", "customer_codes:  ");
		ReplicationPrintMap.put("27", "dealer_codes:  ");
		ReplicationPrintMap.put("28", "issue_level:  ");
		ReplicationPrintMap.put("29", "tranche_level:  ");
		ReplicationPrintMap.put("30", "redemption:  ");
		ReplicationPrintMap.put("31", "issr_level:  ");
		ReplicationPrintMap.put("32", "depo_tra_appointments:  ");
		ReplicationPrintMap.put("33", "tranche_level_ext:  ");
		ReplicationPrintMap.put("34", "event_codes:  ");
		ReplicationPrintMap.put("35", "event_master:  ");
		ReplicationPrintMap.put("36", "event_details:  ");
		ReplicationPrintMap.put("37", "tranche_settlement:  ");
		ReplicationPrintMap.put("38", "deal_settlement:  ");
		ReplicationPrintMap.put("39", "admin_group_type:  ");
		ReplicationPrintMap.put("40", "event_details_bd:  ");
		ReplicationPrintMap.put("41", "rate set:  ");
		ReplicationPrintMap.put("42", "FATCA Details:  ");
		return ReplicationPrintMap;
	}
}
