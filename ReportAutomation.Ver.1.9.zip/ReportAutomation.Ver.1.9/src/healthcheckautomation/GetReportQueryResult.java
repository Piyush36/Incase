package healthcheckautomation;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import shellautomation.GetUniXResult_New;

public class GetReportQueryResult 
{
	static String strReplication;
	static Integer iAlertCount;
	static Integer iOutgoingFailedSwift;
	static String strLastOutgoingSwift;
	static Integer iIncomingFailedSwift;
	static String strLastIncomingSwift;
	static Integer numOfpaymentInstruction;
	static String strLastPaymentInstruction;
	static String strDuplicateISIN;
	static Integer amortization;
	static StringBuilder sbIncomingSwift = new StringBuilder();
	static StringBuilder sbOutgoingSwift = new StringBuilder();
	static String strISSAlert;
	static Integer iFreeDBSpace;
	static String dbFreeSpaceInPercent;
	static final SimpleDateFormat dt = new SimpleDateFormat("d-MMM-yyyy hh:mm:ss aaa");
	Map<String, String> dbQueryMap = new HashMap<String, String>();
	Map<String, String> unixResultMap = new HashMap<String, String>();
	
	//Run this to Create HC Sheet
	public static void main(String[] args) 
	{
		new GetReportQueryResult().checkHC();
	}
	
	private void checkHC()
	{
		checkReplication();
		
		GetUniXResult_New getUniXResult = new GetUniXResult_New(); 
		unixResultMap = getUniXResult.getUnixResult();
		
		CreateHCSheet createSheet = new CreateHCSheet();
		createSheet.createHCSheet(dbQueryMap, unixResultMap);
	}
	
	private void checkReplication()
	{
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		ReplicationQueryStructure queryStructure = new ReplicationQueryStructure();
		ReplicationPrintStructure printStructure = new ReplicationPrintStructure();
		Map<String, String> queryMap = null;
		Map<String, String> printMap = null;
		try
		{
			connection = GetConnection.getConnection();
			queryMap = queryStructure.createReplicationQueryMap();
			printMap = printStructure.createReplicationPrintMap();
			Iterator<Entry<String, String>> itr = queryMap.entrySet().iterator();
			Iterator<Entry<String, String>> itr1 = printMap.entrySet().iterator();
			int count = 0;
			label:
			while(itr.hasNext())
			{
				count++;
				Entry<String, String> entry = itr.next();
				Entry<String, String> printentry = itr1.next();
				System.out.print(printentry.getValue());
				String repliactionQuery = entry.getValue();
				stmt = connection.createStatement();
				resultSet = stmt.executeQuery(repliactionQuery);
				while(resultSet.next())
				{
					System.out.println(resultSet.getInt(1));
					if(count == 24 && entry.getKey().equals("24"))
					{
						if(resultSet.getInt(1) == -3)
						{
							//System.out.println("Replication Successfull");
						}
						
						else
						{
							//System.out.println("Replication Failed");
							break label;
						}
					}
					else if(count == 32 && entry.getKey().equals("32"))
					{
						if(resultSet.getInt(1) == -5)
						{
							//System.out.println("Replication Successfull");
						}
						
						else
						{
							//System.out.println("Replication Failed");
							break label;
						}
					}
					else
					{
						if(resultSet.getInt(1) == 0)
						{
							//System.out.println("Replication Successfull");
						}
						else
						{
							//System.out.println("Replication Failed");
							break label;
						}
					}
					
				}
				try
				{
					if(resultSet != null)
						resultSet.close();
				}
				catch(SQLException ex)
				{
					ex.printStackTrace();
				}
			}
			if(count == 41)
			{
				strReplication = "Replication Successfull";
			}
			else
			{
				strReplication = "Replication Failed";
			}
			System.out.println(strReplication);
			dbQueryMap.put("Replication", strReplication);
			checkOtherHC(connection);
		}
		catch(SQLException sExp)
		{
			sExp.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{

			try 
			{
				if(stmt != null)
					stmt.close();
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		
	}
	
	private void checkOtherHC(Connection connection)
	{
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			stmt = connection.createStatement();
			
			// to get the Alert Counts
			resultSet = stmt.executeQuery(QueryConstant.alertCount);
			if(resultSet.next())
			{
				iAlertCount = resultSet.getInt(1);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("AlertsProcessing", iAlertCount.toString());
			System.out.println("Check the row count for ipa_to_depo_alerts table : " + iAlertCount);
			
			// to get the failed Outgoing Swift
			resultSet = stmt.executeQuery(QueryConstant.outgoingSwiftFailed);
			if(resultSet.next())
			{
				iOutgoingFailedSwift = resultSet.getInt(1);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("OutgoingSwifts", iOutgoingFailedSwift.toString());
			System.out.println("Check row count for unprocessed messages : " + iOutgoingFailedSwift);
			
			// to get last outgoing swift
			resultSet = stmt.executeQuery(QueryConstant.lastOutgoingSwift);
			if(resultSet.next())
			{
				strLastOutgoingSwift = dt.format(resultSet.getTimestamp(1));
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("lastOutgoingSwift", strLastOutgoingSwift);
			System.out.println("Check the last successful Outgoing Swift processed : " + strLastOutgoingSwift);
			
			// to get the failed Incoming MT565 Swifts
			unprocessedMT565(connection);
			
			// to get the last Incoming Swift 
			resultSet = stmt.executeQuery(QueryConstant.lastIncomingSwift);
			if(resultSet.next())
			{
				strLastIncomingSwift = dt.format(resultSet.getTimestamp(1));
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("lastIncomingSwift", strLastIncomingSwift);
			System.out.println("Check the last successful Incoming Swift processed : " + strLastIncomingSwift);
			
			//to get the count of payment instruction
			resultSet = stmt.executeQuery(QueryConstant.paymentInstruction);
			if(resultSet.next())
			{
				numOfpaymentInstruction = resultSet.getInt(1);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("paymentInstruction", numOfpaymentInstruction.toString());
			System.out.println("Check row count for Payment instruction processed : " + numOfpaymentInstruction);
			
			// to get the time Stamp of last payment instruction
			resultSet = stmt.executeQuery(QueryConstant.lastPaymentInstruction);
			if(resultSet.next())
			{
				strLastPaymentInstruction = dt.format(resultSet.getTimestamp(1));
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("lastPaymentInstruction", strLastPaymentInstruction);
			System.out.println("Check the Last successful Payment processed : " + strLastPaymentInstruction);
			
			//to check that is there any duplicate ISIN exist
			resultSet = stmt.executeQuery(QueryConstant.duplicateISIN);
			while(resultSet.next())
			{
				strDuplicateISIN = resultSet.getString(1);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("duplicateISIN", strDuplicateISIN);
			System.out.println("Check no duplicate ISIN exist Duplicate ISIN : " + strDuplicateISIN);
			
			//to check the Amortization event
			resultSet = stmt.executeQuery(QueryConstant.amortization);
			if(resultSet.next())
			{
				amortization = resultSet.getInt(1);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("amortization", amortization.toString());
			System.out.println("Check for any logical delete in Oasis Amortization : " + amortization);
			
			//to Check for MT536 messages which are not processed
			resultSet = stmt.executeQuery(QueryConstant.unprocessedMT536CStream);
			Boolean bUnprocessedMT536CStream = resultSet.next();
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			resultSet = stmt.executeQuery(QueryConstant.unprocessedMT536Euroclear);
			Boolean bUnprocessedMT536Euroclear = resultSet.next();
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			if(bUnprocessedMT536CStream || bUnprocessedMT536Euroclear)
			{
				dbQueryMap.put("unprocessedMT536", "Fail");
				System.out.println("Check for MT536 messages which are not processed : Fail");
			}
			else
			{
				dbQueryMap.put("unprocessedMT536", "Pass");
				System.out.println("Check for MT536 messages which are not processed : Pass");
			}
			
			//to get Number of swifts received yesterday
			resultSet = stmt.executeQuery(QueryConstant.incomingSwift);
			sbIncomingSwift.append("\n");
			while(resultSet.next())
			{
				if(resultSet.getString(1) == null)
				{
					
				}
				else
				{
					Integer count = resultSet.getInt(2);
					sbIncomingSwift.append(resultSet.getString(1) + " " + count.toString() + "\n");
				}
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("incomingSwift", sbIncomingSwift.toString());
			System.out.println("Number of swifts received yesterday : " + sbIncomingSwift.toString());
			
			//to get Number of swifts sent yesterday
			resultSet = stmt.executeQuery(QueryConstant.outgoingSwift);
			sbOutgoingSwift.append("\n");
			while(resultSet.next())
			{
				if(resultSet.getString(1) == null)
				{
					
				}
				else
				{
					Integer count = resultSet.getInt(2);
					sbOutgoingSwift.append(resultSet.getString(1) + " " + count.toString() + "\n");
				}
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("outgoingSwift", sbOutgoingSwift.toString());
			System.out.println("Number of swifts sent yesterday : " + sbOutgoingSwift.toString());
			
			//to get the Invalid Currency
			resultSet = stmt.executeQuery(QueryConstant.invalidCurrencies);
			Boolean bInvalidCurrencies = resultSet.next();
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			if(bInvalidCurrencies)
			{
				dbQueryMap.put("invalidCurrencies", "Fail");
				System.out.println("Check for invalid currency(VAR) : Fail");
			}
			else
			{
				dbQueryMap.put("invalidCurrencies", "Pass");
				System.out.println("Check for invalid currency(VAR) : Pass");
			}
			
			// to get the Common Code
			resultSet = stmt.executeQuery(QueryConstant.commonCode1);
			Boolean bCommonCode1 = resultSet.next();
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			resultSet = stmt.executeQuery(QueryConstant.commonCode2);
			Boolean bCommonCode2 = resultSet.next();
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			if(bCommonCode1 || bCommonCode2)
			{
				dbQueryMap.put("commonCode", "Fail");
				System.out.println("Check for Common Code : Fail");
			}
			else
			{
				dbQueryMap.put("commonCode", "Pass");
				System.out.println("Check for Common Code : Pass");
			}
			
			// to get the max date of ISS Alert
			resultSet = stmt.executeQuery(QueryConstant.ISSAlert);
			if(resultSet.next())
			{
				strISSAlert = dt.format(resultSet.getTimestamp(1));
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("issAlert", strISSAlert);
			System.out.println("Max date of ISS Alert in system : " + strISSAlert);
			
			// to get the DB Free space
			resultSet = stmt.executeQuery(QueryConstant.dBFreeSpace);
			while(resultSet.next())
			{
				if(resultSet.getString(7) != null && resultSet.getString(7).equals("sdoasgdo"))
				{
					iFreeDBSpace = resultSet.getInt(5);
					
					String suffix = resultSet.getString(1);
					String suffixF = suffix.substring(suffix.length()-1, suffix.length());

					Integer space = Integer.valueOf("100") - Integer.valueOf(suffix.substring(0, suffix.length()-1));
					
					dbFreeSpaceInPercent = space.toString() + suffixF;
				}
				else
					continue;
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("DBFreeSpace", iFreeDBSpace.toString());
			dbQueryMap.put("DBFreeSpaceInPercent", dbFreeSpaceInPercent);
			System.out.println("Value of DB free space : " + iFreeDBSpace + "\nValue of % DB Free Space : " + dbFreeSpaceInPercent);
			
		}
		catch(SQLException sExp)
		{
			sExp.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{

			try 
			{
				if(stmt != null)
					stmt.close();
				/*if(connection != null)
					connection.close();*/
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	private void unprocessedMT565(Connection connection)
	{
		Statement stmt = null;
		ResultSet resultSet = null;
		String swiftMsg = null;
		int icount = 0;
		try
		{
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueryConstant.failedIncomingSwift);
			while(resultSet.next())
			{
				swiftMsg = resultSet.getString(10);
				if(swiftMsg.contains("MT565"))
					icount++;
			}
			iIncomingFailedSwift = icount;
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			dbQueryMap.put("unprocessedIncomingSwift", iIncomingFailedSwift.toString());
			System.out.println("Check row count for unprocessed messages : MT565 - " + iIncomingFailedSwift);
		}
		catch(SQLException sExp)
		{
			sExp.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{

			try 
			{
				if(stmt != null)
					stmt.close();
				/*if(connection != null)
					connection.close();*/
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	
}
