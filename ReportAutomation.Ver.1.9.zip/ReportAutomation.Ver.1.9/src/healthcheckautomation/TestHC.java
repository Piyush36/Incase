package healthcheckautomation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import reportautomation.GetConnection;

public class TestHC {

	public static void main(String[] args) 
	{
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			// to get the DB Free space
			resultSet = stmt.executeQuery(QueryConstant.dBFreeSpace);
			ResultSetMetaData rsMetaData = resultSet.getMetaData();
			
			while(resultSet.next())
			{
				if(resultSet.getString(7) != null && resultSet.getString(7).equals("sdoasgdo"))
				{
					int iFreeDBSpace = resultSet.getInt(5);
					String suffix = resultSet.getString(1);
					String suffixF = suffix.substring(suffix.length()-1, suffix.length());
					System.out.println(suffix);
					Integer space = Integer.valueOf("100") - Integer.valueOf(suffix.substring(0, suffix.length()-1));
					System.out.println(space);
					
					String dbFreeSpaceInPerc = space.toString() + suffixF;
					
					System.out.println(iFreeDBSpace);
					System.out.println(dbFreeSpaceInPerc);
				}
				else
					continue;
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}

		}
		catch(SQLException sExp)
		{
			sExp.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{

			try 
			{
				if(stmt != null)
					stmt.close();
				/*if(connection != null)
								connection.close();*/
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

}
