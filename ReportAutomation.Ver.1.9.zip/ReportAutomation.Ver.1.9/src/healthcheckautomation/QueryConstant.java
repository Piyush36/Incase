package healthcheckautomation;

public class QueryConstant 
{
	static String replicationQuery1 = "select (select count(*) from  sdbauipa..appointment_types	) -(select count(*) from  sdoasgdo..depo_appointment_types	) as 'appointment_types'";
	static String replicationQuery2 = "select (select count(*) from  sdbauipa..country_codes	) -(select count(*) from  sdoasgdo..depo_country_codes	) as 'country_codes'"; 
	static String replicationQuery3	= "select (select count(*) from  sdbauipa..currency_codes	) -(select count(*) from  sdoasgdo..depo_currency_codes	) as 'currency_codes'";
	static String replicationQuery4	= "select (select count(*) from  sdbauipa..currency_holidays	) -(select count(*) from  sdoasgdo..depo_currency_holidays	) as 'currency_holidays'";
	static String replicationQuery5	= "select (select count(*) from  sdbauipa..destruction_codes	) -(select count(*) from  sdoasgdo..depo_destruction_codes	) as 'destruction_codes'";
	static String replicationQuery6	= "select (select count(*) from  sdbauipa..history_codes	) -(select count(*) from  sdoasgdo..depo_history_codes	) as 'history_codes'";
	static String replicationQuery7	= "select (select count(*) from  sdbauipa..institution_type	) -(select count(*) from  sdoasgdo..depo_institution_type	) as 'institution_type'";
	static String replicationQuery8	= "select (select count(*) from  sdbauipa..institution_details	) -(select count(*) from  sdoasgdo..depo_institution_details	where institution_id > 0) as 'institution_details'";
	static String replicationQuery9	= "select (select count(*) from  sdbauipa..instrument_class	) -(select count(*) from  sdoasgdo..depo_instrument_class	) as 'instrument_class'";
	static String replicationQuery10 = "select (select count(*) from  sdbauipa..instrument_types	) -(select count(*) from  sdoasgdo..depo_instrument_types	) as 'instrument_types'";
	static String replicationQuery11 = "select (select count(*) from  sdbauipa..interest_freq_codes	) -(select count(*) from  sdoasgdo..depo_interest_freq_codes	) as 'interest_freq_codes'";
	static String replicationQuery12 = "select (select count(*) from  sdbauipa..interest_types	) -(select count(*) from  sdoasgdo..depo_interest_types	) as 'interest_types'";
	static String replicationQuery13 = "select (select count(*) from  sdbauipa..ipa_tra_deal	) -(select count(*) from  sdoasgdo..depo_tra_deal	) as 'tra_deal'";
	static String replicationQuery14 = "select (select count(*) from  sdbauipa..ipa_reg_holding	) -(select count(*) from  sdoasgdo..depo_reg_holding	) as 'reg_holding'";
	static String replicationQuery15 = "select (select count(*) from  sdbauipa..ipa_tra_verification	) -(	select count(*) from  sdoasgdo..depo_tra_verification	) as 'tra_verification'";
	static String replicationQuery16 = "select (select count(*) from  sdbauipa..ipa_programme_level	) -(select count(*) from  sdoasgdo..depo_programme_level	) as 'programme_level'";
	static String replicationQuery17 = "select 	(select count(*) from  sdbauipa..ipa_claim_hdr	) -(select count(*) from  sdoasgdo..depo_claim_hdr	) as 'claim_hdr'";
	static String replicationQuery18 = "select (select count(*) from  sdbauipa..ipa_claim_dtl	) -(	select count(*) from  sdoasgdo..depo_claim_dtl	) as 'claim_dtl'";
	static String replicationQuery19 = "select (select count(*) from  sdbauipa..ipa_tra_history	) -(	select count(*) from  sdoasgdo..depo_tra_history	) as 'tra_history'";
	static String replicationQuery20 = "select (select count(*) from  sdbauipa..ipa_vault	) -(	select count(*) from  sdoasgdo..depo_vault	) as 'vault'";
	static String replicationQuery21 = "select (select count(*) from  sdbauipa..ipa_vault_leg	) -(	select count(*) from  sdoasgdo..depo_vault_leg	) as 'vault_leg'"; 
	static String replicationQuery22 = "select (select count(*) from  sdbauipa..ipa_pro_appointments) -(	select count(*) from  sdoasgdo..depo_pro_appointments	)  as 'pro_appointments'";
	static String replicationQuery23 = "select (select count(*) from  sdbauipa..ipa_issr_appointments	) -(	select count(*) from  sdoasgdo..depo_issr_appointments	) as 'issr_appointments'";
	static String replicationQuery24 = "select (select count(*) from  sdbauipa..ipa_issue_appointments	) -(	select count(*) from  sdoasgdo..depo_issue_appointments	) as 'issue_appointments'";
	static String replicationQuery25 = "select (select count(*) from  sdbauipa..industry_codes	) -(	select count(*) from  sdoasgdo..depo_industry_codes	) as 'industry_codes'";
	static String replicationQuery26 = "select (select count(*) from  sdbauipa..customer_codes	) -(	select count(*) from  sdoasgdo..depo_customer_codes	) as 'customer_codes'";
	static String replicationQuery27 = "select (select count(*) from  sdbauipa..dealer_codes	) -(select count(*) from  sdoasgdo..depo_dealer_codes  where dc_code >=0	) as 'dealer_codes'";
	static String replicationQuery28 =	"select (select count(*) from  sdbauipa..ipa_issue_level	) -(select count(*) from  sdoasgdo..depo_issue_level where issu_identifier >= 0	) as 'issue_level'";
	static String replicationQuery29 =	"select (select count(*) from  sdbauipa..ipa_tranche_level) -(select count(*) from  sdoasgdo..depo_tranche_level where tra_identifier < 3000000000	) as 'tranche_level'";
	static String replicationQuery30 =	"select (select count(*) from  sdbauipa..ipa_redemption) -(select count(*) from  sdoasgdo..depo_redemption where redm_identifier >= 0) as 'redemption'";
	static String replicationQuery31 =	"select (select count(*) from  sdbauipa..ipa_issr_level	) -(select count(*) from  sdoasgdo..depo_issr_level where issr_identifier >=0	) as 'issr_level'";

	static String replicationQuery32 = "select (select count(ipa.tra_apt_identifier) from sdbauipa..ipa_tra_appointments ipa, sdoasgdo..depo_tranche_level depo\n" +
			"where ipa.tra_apt_identifier = depo.tra_identifier\n" +
			"and depo.d_ipa_flag <> 'B')\n" +
			"-\n" +
			"(select count(*) from  sdoasgdo..depo_tra_appointments tra_apt , sdoasgdo..depo_tranche_level depo\n" +
			"where tra_apt.tra_apt_identifier = depo.tra_identifier\n" +
			"and tra_apt.tra_apt_identifier < 3000000000\n" +
			"and depo.d_ipa_flag <> 'B')";

	static String replicationQuery33 = "select (select count(*) from  sdbauipa..ipa_tranche_level_ext) -(select count(*) from  sdoasgdo..depo_tranche_level_ext where tra_identifier < 3000000000) as 'tranche_level_ext'";
	static String replicationQuery34 = "select (select count(*) from  sdbauipa..event_codes) -(select count(*) from  sdoasgdo..depo_event_codes) as 'event_codes'";
	static String replicationQuery35 = "select (select count(*) from  sdbauipa..event_master) -(select count(*) from  sdoasgdo..depo_event_master) as 'event_master'";
	static String replicationQuery36 = "select (select count(*) from  sdbauipa..ipa_event_details) -(select count(*) from  sdoasgdo..depo_event_details) as 'event_details'";
	static String replicationQuery37 = "select (select count(*) from  sdbauipa..ipa_tranche_settlement) -(select count(*) from  sdoasgdo..depo_tranche_settlement) as 'tranche_settlement'";
	static String replicationQuery38 = "select (select count(*) from  sdbauipa..ipa_deal_settlement) -(select count(*) from  sdoasgdo..depo_deal_settlement) as 'deal_settlement'";
	static String replicationQuery39 = "select (select count(*) from  sdbauipa..ipa_admin_group_type) -(select count(*) from  sdoasgdo..depo_admin_group_type) as 'admin_group_type'";
	static String replicationQuery40 = "select (select count(*) from  sdbauipa..ipa_event_details_bd) -(select count(*) from  sdoasgdo..depo_event_details_bd) as 'event_details_bd'";
	static String replicationQuery41 = "select (select count(*) from  sdbauipa..ipa_rate_set) -(select count(*) from  sdoasgdo..depo_rate_set) as 'rate set'";
	static String replicationQuery42 = "select (select count(*) from  sdbauipa..ipa_tra_fatca_details ) -(select count(*) from  sdoasgdo..depo_tra_fatca_details where tra_identifier < 3000000000 ) as 'FATCA Details'";
	
	static String alertCount = "select count(*) as 'Alert Pending Count' from ipa_to_depo_alerts";
	static String outgoingSwiftFailed = "select count(*) 'Outgoing Swfit Pending' from outgoing_swift_log where processed_flg = 'N'";
	static String lastOutgoingSwift = "select max(sent_date) 'Last Outgoing Swift Time' from outgoing_swift_log where processed_flg = 'Y'";
	static String failedIncomingSwift = 	"declare\n" + 
									"@ld_from_date datetime\n" +
									"if (datepart(cdw,getdate())= 1)\n" +
									"select @ld_from_date=dateadd(dd,-3,getdate())\n" +
									"else \n" +
									"select @ld_from_date=dateadd(dd,-1,getdate())\n" +
									"select * from incoming_swift_log where swift_msg_status in ('PROC') and receive_date > @ld_from_date";
	static String lastIncomingSwift = "select max(receive_date) 'Incoming Swift Received' from incoming_swift_log ";
	static String paymentInstruction = "select count(*) from payment_instruction pi  where mark_for_release_ind = 'Y' and processed_ind = 'N' and payment_release_ind = 'Y'  and "
											+ "delete_ind is null and pi.row_insert_date>='01 Jan 2010'";
	static String lastPaymentInstruction = "select max(payment_release_date) 'Last Payment Released' from payment_instruction";
	static String duplicateISIN = "select isin, bare_depo_flag from v_tranche group by isin having count(*) > 1 and isin not in('XS0303369416', 'XS0303458516', 'XS0305093741', " +
									" 'XS0307255900', 'XS0307419514', 'XS0308022333', 'XS0308383784', 'XS0308497527', 'XS0313529918', 'XS0314132738', 'XS0314533729'," +
									" 'XS0370517210','XS0275529864')";
	static String amortization = "select count(*) from depo_redemption dr  where redm_identifier > 0 and dr.d_red_status_flg = 'D'";
	static String unprocessedMT536CStream = "Select * from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'N' and s.branch_code "
												+ "= 'CD' and s.contact_id ='782969415818120' " +
													" and s.row_insert_date < CONVERT(VARCHAR(11),getdate()) order by s.isin,s.branch_code,s.contact_id";
	static String unprocessedMT536Euroclear = "Select * from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'N' and "
													+ "s.branch_code = 'CD' and s.contact_id ='782969687257310'" + 
														"and s.row_insert_date < CONVERT(VARCHAR(11),getdate()) order by s.isin,s.branch_code,s.contact_id";
	static String invalidCurrencies = "select * from payment_instruction p where p.payment_date BETWEEN CONVERT(datetime, getdate(),105) AND "
										+ "CONVERT(datetime, dateadd(dd,07,getDate()), 105) AND p.branch_code = 'CD' and p.pay_ccy_code = 'VAR' order by p.pay_ccy_code";
	static String incomingSwift = 	"declare @datepart int\n" +
									"select @datepart=(case when DATEPART(CDW,getdate()) =1 then 3 else 1 end)\n" +
									"select distinct i.swift_msg_type_code,count(*) from incoming_swift_log i where convert(varchar(11),i.receive_date)=convert(varchar(11),dateadd(dd,-@datepart,getdate()))\n" +
									"group by  swift_msg_type_code";
	static String outgoingSwift = 	"declare @datepart int\n" +
									"select @datepart=(case when DATEPART(CDW,getdate()) =1 then 3 else 1 end)\n" +
									"select distinct o.swift_msg_type_code,count(*) from outgoing_swift_log o \n" +
									"where convert(varchar(11),o.sent_date)=convert(varchar(11),dateadd(dd,-@datepart,getdate())) \n" +
									"group by  swift_msg_type_code";
	static String commonCode1 = "select pi.row_insert_date,common_code,pi.seq_no,pi.isin,v_tranche.issue_name,pi.branch_code,\n" +
								"pi.payment_amt,pi.pay_ccy_code,payment_instruction_type.pay_instruct_desc,\n" +
								"pi.payment_type_ind,pi.payment_date,pi.tranche_id,pi.contact_id,pi.mark_for_release_ind,\n" +
								"pi.payment_release_ind,pi.nominal_amt,pi.event_type_code,pi.ppa_contact_id,pi.jpm_is_ppa_ind,\n" +
								"(select party_name from contact noholdlock where contact_id=pi.ppa_contact_id) as 'ppa_name',\n" +
								"contact.party_name as 'clearer_name',contact.await_rekey as 'rekey_status',\n" +
								"contact.await_reenter as 'reenter_status',\n" +
								"pi.version_no,pi.afra_version_no,pi.pay_ref_no,v_tranche.status_code,\n" +
								"pi.original_holding_amt,v_tranche.oasis_issue_type_code,v_tranche.ipa_issue_type_code,\n" +
								"pi.delete_ind,pi.pay_note,pi.record_date_value, v_tranche.issue_reg_type_code\n" +
		
        						"from payment_instruction pi noholdlock, v_tranche noholdlock, contact noholdlock,\n" +
        						"payment_instruction_type noholdlock\n" +
		
  	    						"where pi.tranche_id = v_tranche.tranche_id\n" +
  	    						"and contact.contact_id = pi.contact_id\n" +
  	    						"and pi.pay_instruct_code = payment_instruction_type.pay_instruct_code\n" +
  	    						"and v_tranche.bare_depo_flag not in ('I')\n" +
  	    						"and v_tranche.active_ind = 'Y'\n" +
  	    						"and pi.payment_release_ind='N' \n" +
  	    						"and pi.pay_instruct_code not in ('DELE')\n" +
  	    						"and pi.branch_code='CD'\n" +
  	    						"and common_code is null\n" +
  	    						"and pi.row_insert_date>=dateadd(dd,-1,getdate()) --to consider the payments added in the queue since yesterday\n" +
  	    						"order by pi.contact_id";
	static String commonCode2 = "select common_code,isin,* from v_tranche v where v.maturity_date between getdate() and dateadd(dd,14,getdate()) and v.discount_ind = 'D'" +
									"and status_code not in ('RD','CA') and branch_code = 'CD'and v.active_ind = 'Y'and common_code is null";
	static String ISSAlert = "select max(alert_date) from ipa_to_depo_alerts i where i.alert_type = 'ISS'";
	static String dBFreeSpace = "select\n" +
								"PercentDatabaseFull=convert(varchar,convert(int,100-DataFree/DataSize*100))+'%',':', TotalMB=convert(int,DataSize), ':'\n" +
								", DataFreeMB=convert(int, DataFree), ':'\n" +
								",DatabaseName, ':'\n" +
								"from(\n" +
								"select 'DatabaseName'=db_name(t1.dbid)\n" +
								",'DataSize'=convert(int,sum\n" +
								"(case when t1.segmap!=4\n" +
								"then t1.size/t2.dbpgsmb\n" +
								"else null end))\n" +
								",'DataFree'=convert(decimal(11,1),sum\n" +
								"(case when t1.segmap!=4\n" +
								"then curunreservedpgs(t1.dbid,t1.lstart, t1.unreservedpgs)/t2.dbpgsmb\n" +
								"else null end))\n" +
								"from master..sysusages t1\n" +
								",(select 'dbpgsmb' = (1048576. / v.low)\n" +
								"from master.dbo.spt_values v\n" +
								"where v.number = 1\n" +
								"and v.type = 'E'\n" + 
								")t2\n" +
								"group by t1.dbid\n" +
								")t3\n" +
								"order by DatabaseName" ;
	
}
