import reportautomation.SendingMailWithAttachmentUtility;


public class SendingMailImpl {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new SendingMailImpl().callSendingAPI();

	}
	
	private void callSendingAPI(){
		String fileName = null;
		String emailSubject = null;
		String emailBody = null;
		//String[] toEmails = {"lalittyagi2602@gmail.com"};
		//String[] ccEmails = {"moneytyagi@yahoo.co.in", "lalit.tyagi@live.in"};
		String[] toEmails = {"lalittyagi2602@gmail.com"};
		String[] ccEmails = {"lalit.tyagi@live.in"};
		
		SendingMailWithAttachmentUtility sendingMailUtility = new SendingMailWithAttachmentUtility();
		
		fileName = "C:/Data/Personal/Lalit Train Ticket.pdf";
		
		emailSubject = "Hello";
		emailBody = "Hello, \n " +
			"\n" +
			"Please find the attached Document. \n" +
			"\n" +
			"\n" +
			"\n" +
			"Kind regards, \n" +
			"Lalit Tyagi";
		sendingMailUtility.sendMail(fileName, emailSubject, emailBody, toEmails, ccEmails);
	}

}
