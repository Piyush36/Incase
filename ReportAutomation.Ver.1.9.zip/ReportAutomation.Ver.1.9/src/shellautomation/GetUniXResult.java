package shellautomation;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;


public class GetUniXResult 
{
	Map<String, String> unixResultMap = new HashMap<String, String>();

	public void executeCommands(String uName, String pword, String connIP, String wls_gdo)
	{
		int iDayOfMonth = 0;
		String strDate = null;
		DateFormat dateFormat = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);
		iDayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		
		if(iDayOfMonth < 10)
		{
			dateFormat = new SimpleDateFormat("MMM  d");
		}
		else
		{
			dateFormat = new SimpleDateFormat("MMM d");
		}
		
		strDate = dateFormat.format(cal.getTime());
		
		String userName = uName;
		String password = pword;
		String connectionIP = connIP;
		String commandwls = "";
		String strServer = null;

		if(wls_gdo.equals("wls_gdo_01"))
		{	
			commandwls = " wls status wls_gdo_01";
			strServer = "xsd00g31";
		}
		else
		{
			commandwls = " wls status wls_gdo_02";
			strServer = "xsd00g32";
		}
		
		String command = " [ -f /apps/gdoasis/prd/logs/gdoasis.log ] && echo " + "gdoasis.log File is there" + "|| echo " + "gdoasis.log File is Not there";
		
		//System.out.println("********Check Gdoasis Logs***********");
		String command1 = "ls -ltr /apps/gdoasis/prd/logs";		

		//System.out.println("********Check WLS Logs***********");
		String command2 = "ls -ltr /prod/gdo/weblogic/config/wld_gdo/logs/";
		
		//System.out.println("********Check Nohup Log file***********");
		String command3 = " [ -f /prod/gdo/weblogic/config/wld_gdo/logs/" + wls_gdo + 
					".nohuplog ] && echo " + "nohuplog File is there" + "|| echo "+"nohuplog File is Not there";    
			     
		//String command4 = "ls -ltr /prod/gdo/weblogic/config/wld_gdo/servers/wls_gdo_01/logs/";
		//String command5 = "[ -f /prod/gdo/weblogic/config/wld_gdo/servers/" + wls_gdo + "/logs/access.log ] && echo "+"Access.log File is there" + "|| echo " + "Access.log File is Not there";

		// Check DB Space
		String command6 = "df -k /apps/gdoasis";   	     
		String command7 = "df -k /prod/gdo";
		String command8 = "df -k /prod";
		String command9 = "df -k /tmp";

		java.util.Properties config = new java.util.Properties(); 
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try 
		{
			session = jsch.getSession(userName, connectionIP, 22);

			session.setPassword(password);
			session.setConfig(config);
			session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
			session.connect();
			System.out.println("Connected");
			session.disconnect();
		} 
		catch (JSchException e) 
		{
			e.printStackTrace();
		}

		SSHManager instance = new SSHManager(userName, password, connectionIP, "");
		String errorMessage = instance.connect();

		if(errorMessage != null)
		{
			System.out.println(errorMessage);

		}
		
		// Check the Running instances of Weblogic Service
		String resultwls = instance.sendCommand(commandwls);
		System.out.println("WLS Instance : " + resultwls);
		
		// Check the gdoasis.log File is present
		String result = instance.sendCommand(command);
		System.out.println("Gdoasis Logs \n" + result);
		
		//GD Oasis application Logs
		String result1 = instance.sendCommand(command1);
		System.out.println("Gdoasis Logs \n" + result1);
		// Need to get the value of "47761267 Mar 31 06:58 gdoasis.log" from the whole String
		/*if(result != null && result.equals("gdoasis.log File is there"))
		{	
		}*/
		
		if(result1.contains(strDate) && result1.contains("gdoasis.log"))
		{
			System.out.println(result1.lastIndexOf(strDate));
			System.out.println(result1.substring(result1.lastIndexOf(strDate) + 7, result1.lastIndexOf(strDate) + 13));
			if(strServer != null && strServer.equals("xsd00g31"))
			{
				unixResultMap.put("gdoLogs31", "G31 : " + result1.substring(result1.lastIndexOf(strDate) + 7, result1.lastIndexOf(strDate) + 13) + " AM");
			}
			else if(strServer != null && strServer.equals("xsd00g32"))
			{
				unixResultMap.put("gdoLogs32", "G32 : " + result1.substring(result1.lastIndexOf(strDate) + 7, result1.lastIndexOf(strDate) + 13) + " AM");
			}
			
		}

		//Check WLS logs
		String result2 = instance.sendCommand(command2);
		System.out.println("WLS Logs \n :"+ result2);
		// Need to get the value of "17043340 Mar 31 06:58 wls_gdo_01.log" from the whole String
		
		if(strServer != null && strServer.equals("xsd00g31"))
		{
			if(result2.contains(strDate) && result2.contains("wls_gdo_01.log"))
			{
				System.out.println(result2.lastIndexOf(strDate));
				System.out.println(result2.substring(result2.lastIndexOf(strDate) + 7, result2.lastIndexOf(strDate) + 13));
				unixResultMap.put("wlsLogs31", "G31 : " + result2.substring(result2.lastIndexOf(strDate) + 7, result2.lastIndexOf(strDate) + 13) + " AM");
				
			}
		}
		else if(strServer != null && strServer.equals("xsd00g32"))
		{
			if(result2.contains(strDate) && result2.contains("wls_gdo_02.log"))
			{
				System.out.println(result2.lastIndexOf(strDate));
				System.out.println(result2.substring(result2.lastIndexOf(strDate) + 7, result2.lastIndexOf(strDate) + 13));
				unixResultMap.put("wlsLogs32", "G32 : " + result2.substring(result2.lastIndexOf(strDate) + 7, result2.lastIndexOf(strDate) + 13) + " AM");
				
			}
		}

		// Check Nohup log file
		String result3 = instance.sendCommand(command3);
		System.out.println("result3 : " + result3);
		
		// Check access logs (Dont need for GDO)
		/*
		String result4 = instance.sendCommand(command4);
		System.out.println("result4 :"+ result4);

		String result5 = instance.sendCommand(command5);
		System.out.println("result5 :"+ result5);
		 */
		
		// checking the server space
		String result6 = instance.sendCommand(command6);
		System.out.println("result6 :"+ result6);
		
		System.out.println(result6.lastIndexOf("%"));
		System.out.println(result6.substring(result6.lastIndexOf("%")-2, result6.lastIndexOf("%")));
		Integer i1 = Integer.valueOf("100") - Integer.valueOf(result6.substring(result6.lastIndexOf("%")-2, result6.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i1);
		
		// checking the server space
		String result7 = instance.sendCommand(command7);
		System.out.println("result7 :"+ result7);
		
		System.out.println(result7.lastIndexOf("%"));
		System.out.println(result7.substring(result7.lastIndexOf("%")-2, result7.lastIndexOf("%")));
		Integer i2 = Integer.valueOf("100") - Integer.valueOf(result7.substring(result7.lastIndexOf("%")-2, result7.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i2);
		
		// checking the server space
		String result8 = instance.sendCommand(command8);
		System.out.println("result8 :"+ result8);
		
		System.out.println(result8.lastIndexOf("%"));
		System.out.println(result8.substring(result8.lastIndexOf("%")-2, result8.lastIndexOf("%")));
		Integer i3 = Integer.valueOf("100") - Integer.valueOf(result8.substring(result8.lastIndexOf("%")-2, result8.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i3);
		
		// checking the server space
		String result9 = instance.sendCommand(command9);
		System.out.println("result9 :"+ result9);
		
		System.out.println(result9.lastIndexOf("%"));
		System.out.println(result9.substring(result9.lastIndexOf("%")-2, result9.lastIndexOf("%")));
		Integer i4 = Integer.valueOf("100") - Integer.valueOf(result9.substring(result9.lastIndexOf("%")-2, result9.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i4);
		
		if(strServer != null && strServer.equals("xsd00g31"))
		{
			unixResultMap.put("freeSpaceG31", "G31 : " + i1.toString() + ", " + i2.toString() + ", " + i3.toString() + ", " + i4.toString() + " % respectively.");
		}
		else if(strServer != null && strServer.equals("xsd00g32"))
		{
			unixResultMap.put("freeSpaceG32", "G32 : " + i1.toString() + ", " + i2.toString() + ", " + i3.toString() + ", " + i4.toString() + " % respectively.");
		}

		// close only after all commands are sent
		instance.close();
		//assertEquals(expResult, result);
	}

	public void executeCommandsOnA27(String uName, String pword, String connIP)
	{
		String strYesterdayDate = null;
		String strTodayDate = null;
		String strYesterdayDateForNdmin = null;
		String strTodayDateForNdmin = null;
		int iDayOfMonth = 0;
		DateFormat dateFormatForNdmin = null;
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
		Calendar calendar = Calendar.getInstance();
		Calendar calendarToday = Calendar.getInstance();
		calendarToday.add(Calendar.DATE, 0);
		int day = calendar.get(Calendar.DAY_OF_WEEK);
		iDayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		
		if(iDayOfMonth < 10)
		{
			dateFormatForNdmin = new SimpleDateFormat("MMM  d");
		}
		else
		{
			dateFormatForNdmin = new SimpleDateFormat("MMM d");
		}
		
		System.out.println("Day is : " + day);
		if(day == 2)
		{
			calendar.add(Calendar.DATE, -3);
		}
		else 
		{
			calendar.add(Calendar.DATE, -1);
		}
		strYesterdayDate = dateFormat.format(calendar.getTime());
		strTodayDate = dateFormat.format(calendarToday.getTime());
		strYesterdayDateForNdmin = dateFormatForNdmin.format(calendar.getTime());
		strTodayDateForNdmin = dateFormatForNdmin.format(calendarToday.getTime());

		System.out.println("Yesterday's date :" + strYesterdayDate);
		System.out.println("Today's date :" + strYesterdayDate);
		
		String userName = uName;
		String password = pword;
		String connectionIP = connIP;

		System.out.println("XSD00A27");
		
		String commandA27 = "ls -ltr /apps/gdoasis/prd/ndmout";

		String commandA27_1 = " [ -d /apps/gdoasis/prd/ndmout/intransit ] && echo " + " intransit directory is there" + 
							"|| echo " + "intransit directory is Not there";
		
		//Check the batch Job logs
		String commandA27_3 = "ls -ltr /apps/gdoasis/prd/logs";

		String commandA27_4 = "df -k /apps/gdoasis";   	     
		String commandA27_5 = "df -k /prod/gdo";
		String commandA27_6 = "df -k /prod";
		String commandA27_7 = "df -k /tmp";

		String commandA27_8 = "ls -ltr /apps/gdoasis/prd/ndmout/archive/*OASIS_AFRA_" + strYesterdayDate + "*|wc -l";
		
		String commandA27_9 = "df -k /prodsys/vol1_pa27";
		
		String commandA27_10 = "ls -ltr /apps/gdoasis/prd/ndmout/archive/*_IPACERTS" + strYesterdayDate + ".FTM*";
		
		String commandA27_11 = "ls -ltr /apps/gdoasis/prd/ndmout/archive/" + strTodayDate + "*_gdo2smdb.txt";
		
		String commandA27_12 = "ls -ltr /apps/gdoasis/prd/ndmin/";
		
		java.util.Properties config = new java.util.Properties(); 
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try 
		{
			session = jsch.getSession(userName, connectionIP, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
			session.connect();
			System.out.println("Connected");
			session.disconnect();
		} 
		catch (JSchException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SSHManager instance = new SSHManager(userName, password, connectionIP, "");
		String errorMessage = instance.connect();

		if(errorMessage != null)
		{
			System.out.println(errorMessage);
			//fail();
		}
		
		// check for the directory /apps/gdoasis/prd/ndmout
		String resultA27 = instance.sendCommand(commandA27);
		System.out.println("resultA27 :"+ resultA27);
		
		// check for the directory /apps/gdoasis/prd/ndmout/intransit
		String resultA27_1 = instance.sendCommand(commandA27_1);
		System.out.println("resultA27_1 :"+ resultA27_1);

		//Check the batch Job logs
		String resultA27_3 = instance.sendCommand(commandA27_3);
		System.out.println("resultA27_3 :"+ resultA27_3);

		// Check the server space - 1
		String resultA27_4 = instance.sendCommand(commandA27_4);
		System.out.println("resultA27_4 :"+ resultA27_4);
		
		System.out.println(resultA27_4.lastIndexOf("%"));
		System.out.println(resultA27_4.substring(resultA27_4.lastIndexOf("%")-2, resultA27_4.lastIndexOf("%")));
		Integer i1 = Integer.valueOf("100") - Integer.valueOf(resultA27_4.substring(resultA27_4.lastIndexOf("%")-2, resultA27_4.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i1);
		
		// Check the server space - 2
		String resultA27_5 = instance.sendCommand(commandA27_5);
		System.out.println("resultA27_5 :"+ resultA27_5);
		
		System.out.println(resultA27_5.lastIndexOf("%"));
		System.out.println(resultA27_5.substring(resultA27_5.lastIndexOf("%")-2, resultA27_5.lastIndexOf("%")));
		Integer i2 = Integer.valueOf("100") - Integer.valueOf(resultA27_5.substring(resultA27_5.lastIndexOf("%")-2, resultA27_5.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i2);
		
		// Check the server space - 3
		String resultA27_6 = instance.sendCommand(commandA27_6);
		System.out.println("resultA27_6 :"+ resultA27_6);
		
		System.out.println(resultA27_6.lastIndexOf("%"));
		System.out.println(resultA27_6.substring(resultA27_6.lastIndexOf("%")-2, resultA27_6.lastIndexOf("%")));
		Integer i3 = Integer.valueOf("100") - Integer.valueOf(resultA27_6.substring(resultA27_6.lastIndexOf("%")-2, resultA27_6.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i3);
		
		// Check the server space - 4
		String resultA27_7 = instance.sendCommand(commandA27_7);
		System.out.println("resultA27_7 : " + resultA27_7);
		
		System.out.println(resultA27_7.lastIndexOf("%"));
		System.out.println(resultA27_7.substring(resultA27_7.lastIndexOf("%")-2, resultA27_7.lastIndexOf("%")));
		Integer i4 = Integer.valueOf("100") - Integer.valueOf(resultA27_7.substring(resultA27_7.lastIndexOf("%")-2, resultA27_7.lastIndexOf("%")).trim());
		System.out.println("Lalit Tyagi : " + i4);
		
		unixResultMap.put("freeSpaceA27", "/apps/gdoasis :- " + i1.toString() + "%\n /prod/gdo :- " + i2.toString() + "%\n /prod  :- " + i3.toString() + "%\n /tmp :- " + i4.toString() + "%");
		System.out.println("Database Unix File System Free Space " + unixResultMap.get("freeSpaceA27"));
		

		// Check for the Afra xml
		String resultA27_8 = instance.sendCommand(commandA27_8);
		System.out.println("Count of AFRA xml : " + resultA27_8);
		
		unixResultMap.put("AFRA xml", resultA27_8.trim() + " XML sent yesterday");
		System.out.println("AFRA xml " + unixResultMap.get("AFRA xml"));
		
		// Check NDM file system space
		String resultA27_9 = instance.sendCommand(commandA27_9);
		System.out.println("NDM file system space : " + resultA27_9);
		
		System.out.println(resultA27_9.lastIndexOf("%"));
		System.out.println(resultA27_9.substring(resultA27_9.lastIndexOf("%")-2, resultA27_9.lastIndexOf("%") + 1));
		
		unixResultMap.put("NDM Free Space", resultA27_9.substring(resultA27_9.lastIndexOf("%")-2, resultA27_9.lastIndexOf("%") + 1).trim());
		System.out.println("Check NDM file system space " + unixResultMap.get("NDM Free Space"));
		
		// Check ipacert file
		Boolean bipacert = false;
		String resultA27_10 = instance.sendCommand(commandA27_10);
		System.out.println("Yesterday ipacert file : " + resultA27_10);
		if(resultA27_10 != null && resultA27_10.contains("_IPACERTS" + strYesterdayDate + ".FTM"))
		{
			System.out.println("ipacert file is present for yesterday's date in the directory /apps/gdoasis/prd/ndmout/archive/");
			bipacert = true;
		}
		else
		{
			System.out.println("ipacert file is not present for yesterday's date in the directory /apps/gdoasis/prd/ndmout/archive/");
			bipacert = false;
		}
		
		// Check _gdo2smdb file
		Boolean bgdo2smdb = false;
		String resultA27_11 = instance.sendCommand(commandA27_11);
		System.out.println("Today's _gdo2smdb file : " + resultA27_11);
		if(resultA27_11 != null && resultA27_11.contains(strTodayDate) && resultA27_11.contains("_gdo2smdb.txt"))
		{
			System.out.println("gdo2smdb file is present for today's date in the directory /apps/gdoasis/prd/ndmout/archive/");
			bgdo2smdb = true;
		}
		else
		{
			System.out.println("gdo2smdb file is not present for today's date in the directory /apps/gdoasis/prd/ndmout/archive/");
			bgdo2smdb = false;
		}
		
		// Check _File of CNT, CCY, CAL with yesterdays date should be present and gdoasisprice.del of current date should be present.
		String resultA27_12 = instance.sendCommand(commandA27_12);
		System.out.println("Check LMS feed and gdoasisprice.del file : " + resultA27_12);
		
		// Check for LMS feed of Currency
		Boolean bLMSCurrency = false;
		if(resultA27_12 != null && resultA27_12.contains("LMS_CT_EOD_CCY.TXT"))
		{
			System.out.println(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CCY.TXT")-13, resultA27_12.indexOf("LMS_CT_EOD_CCY.TXT")-7).trim());
			if(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CCY.TXT")-13, resultA27_12.indexOf("LMS_CT_EOD_CCY.TXT")-7).trim().
					equals(strYesterdayDateForNdmin))
			{
				System.out.println("LMS_CT_EOD_CCY.TXT file is present for yesterday's date in the directory /apps/gdoasis/prd/ndmin");
				bLMSCurrency = true;
			}
			else
			{
				System.out.println("LMS_CT_EOD_CCY.TXT file is not present for yesterday's date in the directory /apps/gdoasis/prd/ndmin");
				bLMSCurrency = false;
			}
		}
		
		// Check for LMS feed of Country
		Boolean bLMSCountry = false;
		if(resultA27_12 != null && resultA27_12.contains("LMS_CT_EOD_CNT.TXT"))
		{
			System.out.println(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CNT.TXT")-13, resultA27_12.indexOf("LMS_CT_EOD_CNT.TXT")-7).trim());
			if(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CNT.TXT")-13, resultA27_12.indexOf("LMS_CT_EOD_CNT.TXT")-7).trim().
					equals(strYesterdayDateForNdmin))
			{
				System.out.println("LMS_CT_EOD_CNT.TXT file is present for yesterday's date in the directory /apps/gdoasis/prd/ndmin");
				bLMSCountry = true;
			}
			else
			{
				System.out.println("LMS_CT_EOD_CNT.TXT file is not present for yesterday's date in the directory /apps/gdoasis/prd/ndmin");
				bLMSCountry = false;
			}
		}
		
		// Check for LMS feed of Calendar
		Boolean bLMSCalendar = false;
		if(resultA27_12 != null && resultA27_12.contains("LMS_CT_EOD_CAL.TXT"))
		{
			System.out.println(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CAL.TXT")-13, resultA27_12.indexOf("LMS_CT_EOD_CAL.TXT")-7).trim());
			if(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CAL.TXT")-13, resultA27_12.indexOf("LMS_CT_EOD_CAL.TXT")-7).trim().
					equals(strYesterdayDateForNdmin))
			{
				System.out.println("LMS_CT_EOD_CAL.TXT file is present for yesterday's date in the directory /apps/gdoasis/prd/ndmin");
				bLMSCalendar = true;
			}
			else
			{
				System.out.println("LMS_CT_EOD_CAL.TXT file is not present for yesterday's date in the directory /apps/gdoasis/prd/ndmin");
				bLMSCalendar = false;
			}
		}
		
		// Check for gdoasisprice.del file 
		Boolean bgdoasispriceFile = false;
		if(resultA27_12 != null && resultA27_12.contains("gdoasisprice.del"))
		{
			System.out.println(resultA27_12.substring(resultA27_12.indexOf("gdoasisprice.del")-13, resultA27_12.indexOf("gdoasisprice.del")-7).trim());
			if(resultA27_12.substring(resultA27_12.indexOf("gdoasisprice.del")-13, resultA27_12.indexOf("gdoasisprice.del")-7).trim().
					equals(strTodayDateForNdmin))
			{
				System.out.println("gdoasisprice.del file is present for today's date in the directory /apps/gdoasis/prd/ndmin");
				bgdoasispriceFile = true;
			}
			else
			{
				System.out.println("gdoasisprice.del file is not present for today's date in the directory /apps/gdoasis/prd/ndmin");
				bgdoasispriceFile = false;
			}
		}
		if(bLMSCalendar && bLMSCountry && bLMSCurrency && bgdoasispriceFile && bgdo2smdb && bipacert)
		{
			unixResultMap.put("Check file transfer to/from XSD0PA27", "Pass");
		}
		else
		{
			unixResultMap.put("Check file transfer to/from XSD0PA27", "Fail");
		}

		// close only after all commands are sent
		instance.close();
		//assertEquals(expResult, result);
	}
	
	public String readpassword()
	{
		return readpassword();

	}
	
	public Map<String, String> getUnixResult()
	{
		String wls_gdo_01 = "wls_gdo_01";
		String wls_gdo_02 = "wls_gdo_02";
		String username = null;
		String password = null;

		/*System.out.println("Enter username : ");
		Scanner n = new Scanner(System.in);
		username = n.next();
		System.out.println("Username :"+username);

		System.out.println("Enter Password : ");
		Scanner n1 = new Scanner(System.in);
		password = n1.next();*/
		
		username = "xbblxdt";
		password = "Delhi999";

		executeCommands(username, password, "160.254.55.43", wls_gdo_01);
		executeCommands(username, password, "160.254.55.50", wls_gdo_02);
		executeCommandsOnA27(username, password, "160.254.55.57");
		
		// here we print all the output of UNIX commands
		System.out.println("--------------------------------------------");
		System.out.println("GD Oasis application Logs : " + unixResultMap.get("gdoLogs31") + "\n" + unixResultMap.get("gdoLogs32"));
		System.out.println("WLS Logs : " + unixResultMap.get("wlsLogs31") + "\n" + unixResultMap.get("wlsLogs32"));
		System.out.println("Application Server Unix File system Free space : " + unixResultMap.get("freeSpaceG31") + "\n" + unixResultMap.get("freeSpaceG32"));
		System.out.println("Database Unix File System Free Space " + unixResultMap.get("freeSpaceA27"));
		System.out.println("AFRA xml " + unixResultMap.get("AFRA xml"));
		System.out.println("Check NDM file system space " + unixResultMap.get("NDM Free Space"));
		System.out.println("Check file transfer to/from XSD0PA27 " + unixResultMap.get("Check file transfer to/from XSD0PA27"));
		
		return unixResultMap;
	}
	
	public static void main(String args[]) throws IOException
	{
		new GetUniXResult().getUnixResult();
	}
}