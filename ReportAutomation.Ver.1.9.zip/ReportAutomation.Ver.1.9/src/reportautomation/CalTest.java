package reportautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class CalTest 
{
	public static void main(String[] args) 
	{
		/*String strDate;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        System.out.println(strDate);
        
        StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	String strVal = strToken.nextToken();
        	//System.out.println(strVal);
        	
        	list.add(strVal);
        }
        Integer intYear = Integer.valueOf(list.get(2));
        Integer intDate = Integer.valueOf(list.get(0));
       
        yearMap = hValues.createYearMap();
        Integer intMonth = yearMap.get(list.get(1));
        //System.out.println(intMonth);
        //
        Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
        System.out.println(date1.toString());
        String dayValue = new SimpleDateFormat("EEEE").format(date1);
        System.out.println(dayValue);*/
		
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("d MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, +0);
        
        System.out.println(cal.get(Calendar.DAY_OF_MONTH));
        strDate = dateFormat.format(cal.getTime());
        System.out.println(strDate);
        
        String resultA27_12 = "drwxrwxr-x   2 pgdop02  pgdo        1024 Nov  3 12:21 raw " +
        						"-rw-r--r--   1 pgdop02  pgdo        6481 Nov  3 12:24 NEW_FILE_GDOASIS_EOD_FX_RATES_NEW_FILE.TXT " +
        						"-rw-r--r--   1 pgdop02  pgdo        9680 Apr 11 21:48 LMS_CT_EOD_CCY.TXT " +
        						"-rw-r--r--   1 pgdop02  pgdo       18924 Apr 11 21:48 LMS_CT_EOD_CNT.TXT " +
        						"-rw-r--r--   1 pgdop02  pgdo     7398325 Apr 11 21:49 LMS_CT_EOD_CAL.TXT " +
        						"drwxrwxr-x   2 pgdop02  pgdo      106496 Apr 12 05:03 archive " +
        					    "-rw-rw-r--   1 pgdop02  pgdo      476296 Apr 12 05:15 gdoasisprice.del";	
        System.out.println(resultA27_12.substring(resultA27_12.indexOf("LMS_CT_EOD_CCY.TXT")-13, resultA27_12.indexOf("LMS")-7));
        
        
	}
}
