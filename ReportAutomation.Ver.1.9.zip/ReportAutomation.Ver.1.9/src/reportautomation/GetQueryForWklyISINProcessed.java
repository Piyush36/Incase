package reportautomation;

public class GetQueryForWklyISINProcessed
{
	public static String getQueryForOASISISINProcessed(String strFrom, String strTo)
	{
		String strOASISQuery = "select p.isin,vt.issue_name,(select user_name from east_users where user_id=p.marked_by_user) as 'PROCCESSED BY', \n" + 
								"(select user_name from east_users where user_id= p.payment_released_user) as 'VERIFIED USER'\n" +
								"from payment_instruction p ,v_tranche vt\n" +
								"where vt.isin=p.isin\n" +
								"and p.payment_date >= '" + strFrom + "' and p.payment_date <= '" + strTo + "'\n" +
								"and p.payment_release_ind='Y'";
		return strOASISQuery;
	}
	
	public static String getQueryForMANUALISINProcessed(String strFrom, String strTo)
	{
		String strMANUALQuery = "select m.isin,v.issue_name,(select user_name from east_users where user_id=m.last_edit_user) as 'PROCCESSED BY',\n" +
								"(select user_name from east_users where user_id=m.verified_user) as 'VERIFIED USER'\n" +
								"from manual_payment m,v_tranche v\n" +
								"where v.isin=m.isin \n" +
								"and m.payment_date >= '" + strFrom + "' and m.payment_date <= '" + strTo + "'\n" +
								"and m.status_ind='Y'";
				
		return strMANUALQuery;
	}
}
