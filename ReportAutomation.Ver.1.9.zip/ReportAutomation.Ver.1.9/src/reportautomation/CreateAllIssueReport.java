package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class CreateAllIssueReport 
{
	public static void main(String[] args)
	{
		new CreateAllIssueReport().createReport();
	}
	
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		File directory = null;
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("Sheet1");
		    
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.allIssueQuery);
		    System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createAllIssueHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();

		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell(icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setIndention((short) 0);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
	            HSSFCell cell1 = row.createCell(0);
	            cell1.setCellValue(resultSet.getString(1));							//tra_isin
	            cell1.setCellStyle(style);
	            
	            HSSFCell cell2 = row.createCell(1);
	            cell2.setCellValue(resultSet.getString(2));							//issu_cur
	            cell2.setCellStyle(style);
	            
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));							//Shared
		    	cell3.setCellStyle(style);
		    	
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));							//d_tra_principle_ccy
		    	cell4.setCellStyle(style);
		    	
		    	HSSFCell cell5 = row.createCell(4);
		    	cell5.setCellValue(resultSet.getString(5));							//tra_int_curr
		    	cell5.setCellStyle(style);
		    	
		    	HSSFCell cell6 = row.createCell(5);
		    	double traMinDenom = resultSet.getDouble(6);						//d_tra_min_denom
		    	if(traMinDenom == 0)
		    		cell6.setCellValue("");
		    	else
		    		cell6.setCellValue(traMinDenom);	
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);
		    	float minTradeDenomination = resultSet.getFloat(7);					//min_trade_denomination
		    	if(minTradeDenomination == 0)
		    		cell7.setCellValue("");		
		    	else
		    		cell7.setCellValue(minTradeDenomination);
		    	cell7.setCellStyle(style);
		    	
		    	HSSFCell cell8 = row.createCell(7);
		    	long traDenomIntRates = resultSet.getLong(8);						//d_tra_denom_interest_rates
		    	if(traDenomIntRates == 0)
		    		cell8.setCellValue("");		
		    	else
		    		cell8.setCellValue(traDenomIntRates);
		    	cell8.setCellStyle(style);
		    	
		    	HSSFCell cell9 = row.createCell(8);
		    	float claimDenom = resultSet.getFloat(9);							//claim_denom
		    	if(claimDenom == 0)
		    		cell9.setCellValue("");
		    	else
		    		cell9.setCellValue(claimDenom);
		    	cell9.setCellStyle(style);
		    	
		    	HSSFCell cell10 = row.createCell(9);
		    	cell10.setCellValue(resultSet.getString(10));						//issr_prog_no
		    	cell10.setCellStyle(style);
		    	
		    	HSSFCell cell11 = row.createCell(10);
		    	cell11.setCellValue(resultSet.getString(11));						//in_int_desc
		    	cell11.setCellStyle(style);
		    	
		    	HSSFCell cell12 = row.createCell(11);
		    	cell12.setCellValue(resultSet.getString(12));   					//prod_identifier
		    	cell12.setCellStyle(style);

		    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
			    //Date date = dt.parse(resultSet.getDate(5).toString());
			    String strTraValueDate = dt.format(resultSet.getDate(13));    		//tra_value_date
			    String strRecordDate = dt.format(resultSet.getDate(14));			//record_date
			    String strTraLastIntDate = dt.format(resultSet.getDate(15));		//tra_last_int_date
			    String strTraNextIntDate = dt.format(resultSet.getDate(16));		//tra_next_int_date
			    
			    HSSFCell cell13 = row.createCell(12);
			    if(strTraValueDate != null && strTraValueDate.equals("01/01/1900"))
			    	cell13.setCellValue("");
			    else
			    	cell13.setCellValue(strTraValueDate);
			    cell13.setCellStyle(style);
			    
			    HSSFCell cell14 = row.createCell(13);
			    if(strRecordDate != null && strRecordDate.equals("01/01/1900"))
			    	cell14.setCellValue("");
			    else
			    	cell14.setCellValue(strRecordDate);
			    cell14.setCellStyle(style);
			    
			    HSSFCell cell15 = row.createCell(14);
			    if(strTraLastIntDate != null && strTraLastIntDate.equals("01/01/1900"))
			    	cell15.setCellValue("");
			    else
			    	cell15.setCellValue(strTraLastIntDate);
			    cell15.setCellStyle(style);
			    
			    HSSFCell cell16 = row.createCell(15);
			    if(strTraNextIntDate != null && strTraNextIntDate.equals("01/01/1900"))
			    	cell16.setCellValue("");
			    else
			    	cell16.setCellValue(strTraNextIntDate);
			    cell16.setCellStyle(style);
			    
		    	HSSFCell cell17 = row.createCell(16);
		    	cell17.setCellValue(resultSet.getString(17));						//tra_fx_flag
		    	cell17.setCellStyle(style);
		    	
		    	HSSFCell cell18 = row.createCell(17);
		    	float traIntRate = resultSet.getFloat(18);							//tra_int_rate
		    	if(traIntRate == 0)
		    		cell18.setCellValue("");	
		    	else
		    		cell18.setCellValue(traIntRate);
		    	cell18.setCellStyle(style);
		    	
		    	HSSFCell cell19 = row.createCell(18);
		    	int traRecordDateDaysP = resultSet.getInt(19);						//tra_record_date_days_prior
		    	if(traRecordDateDaysP == 0)
		    		cell19.setCellValue("");		
		    	else
		    		cell19.setCellValue(traRecordDateDaysP);
		    	cell19.setCellStyle(style);
		    	
		    	HSSFCell cell20 = row.createCell(19);
		    	cell20.setCellValue(resultSet.getString(20));						//tra_coupon_type
		    	cell20.setCellStyle(style);
		    	
		    	HSSFCell cell21 = row.createCell(20);
		    	int traIntBasis = resultSet.getInt(21);								//tra_int_basis
		    	if(traIntBasis == 0)
		    		cell21.setCellValue("");		
		    	else
		    		cell21.setCellValue(traIntBasis);
		    	cell21.setCellStyle(style);
		    	
		    	HSSFCell cell22 = row.createCell(21);
		    	cell22.setCellValue(resultSet.getString(22));						//tra_bus_day_convention
		    	cell22.setCellStyle(style);
		    	
		    	HSSFCell cell23 = row.createCell(22);
		    	cell23.setCellValue(resultSet.getString(23));						//d_adjust_flg
		    	cell23.setCellStyle(style);
		    	
		    	HSSFCell cell24 = row.createCell(23);
		    	String strTraMatDate = dt.format(resultSet.getDate(24));			//tra_mat_date
		    	if(strTraMatDate != null && strTraMatDate.equals("01/01/1900"))
		    		cell24.setCellValue("");	
		    	else
		    		cell24.setCellValue(strTraMatDate);
		    	cell24.setCellStyle(style);
		    	
		    	HSSFCell cell25 = row.createCell(24);
		    	double traPoolFactor = resultSet.getDouble(25);						//tra_pool_factor
		    	if(traPoolFactor == 0)
		    		cell25.setCellValue("");	
		    	else
		    		cell25.setCellValue(traPoolFactor);
		    	cell25.setCellStyle(style);
		    	
		    	HSSFCell cell26 = row.createCell(25);
		    	String strFrnFixDate = dt.format(resultSet.getDate(26));			//tra_frn_fix_date
		    	if(strFrnFixDate != null && strFrnFixDate.equals("01/01/1900"))
		    		cell26.setCellValue("");
		    	else
		    		cell26.setCellValue(strFrnFixDate);
		    	cell26.setCellStyle(style);
		    	
		    	HSSFCell cell27 = row.createCell(26);
		    	cell27.setCellValue(resultSet.getString(27));						//tra_registered
		    	cell27.setCellStyle(style);
		    	
		    	HSSFCell cell28 = row.createCell(27);
		    	double clearStreamHolding = resultSet.getDouble(28);				//Clearstream Holding
		    	if(clearStreamHolding == 0)
		    		cell28.setCellValue("");
		    	else
		    		cell28.setCellValue(clearStreamHolding);
		    	cell28.setCellStyle(style);
		    	
		    	HSSFCell cell29 = row.createCell(28);
		    	double euroClearHolding = resultSet.getDouble(29);					//Euroclear Holding
		    	if(euroClearHolding == 0)
		    		cell29.setCellValue("");	
		    	else
		    		cell29.setCellValue(euroClearHolding);
		    	cell29.setCellStyle(style);
		    	
		    	HSSFCell cell30 = row.createCell(29);
		    	cell30.setCellValue(resultSet.getString(30));						//Held With
		    	cell30.setCellStyle(style);
		    	
		    }
		    
		    for(int columnIndex = 0; columnIndex < 30; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    
		 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Morning/All Issues/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Morning/All Issues/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/All Issues Report - " + reportDay + ".xls";
		    String reportDestPath = "//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/All Issues/All Issues Report - " + reportDay + ".xls";
		    FileOutputStream fileOut = new FileOutputStream(reportSrcPath);
		    workbook.write(fileOut);
		    fileOut.close();
		    
		    System.out.println("All Issue Report is created successfully!");
		    // Moving file to the network Location
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		  //Sending Mail through Generic mail sending method
		    String[] strToList = {"ditdatareconciliation@bnymellon.com"};  //ditdatareconciliation@bnymellon.com
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
		    String strEmailSubject = "All Issues Report - " + reportDay;
		    String strEmailBody = "Hi,<br><br> \n " +
					"Please find the All Issues Report for today " +
					"<a href='file:" + reportDestPath + "'> here.</a> <br>\n";
		    new SendingMailUtility().sendMail(strEmailSubject, strEmailBody, strToList, strCCList);
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}
}
