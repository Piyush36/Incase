package reportautomation;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailForHC 
{



	
	public  void sendMail(StringBuilder sb2) throws SQLException  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		Multipart multipart;
		String emailBody;
		String emailSubject;
		String from;
		String emailPort;
		String emailHost;
		//StringBuilder sb=new StringBuilder();  
		
		try
		{
			//strLocationLink = "file://whexpfseur11/corptrustpoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/X40347222-Number of ISIN's processed";
			emailPort = "25";//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

		
			
			String[] toEmails = {"ctsd.gdoasis@bnymellon.com","henry.mantell@bnymellon.com"};
			
			from = "ctsd.gdoasis@bnymellon.com";
			String fromDate=getTodayDate();
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();
	//		DFS	= new FileDataSource(fileName);
			//1stLine
			
			//1st query result
		/*	try {
				if(!NettingsCheck.next())
				{
					sb.append("Query returned no results");
					NettingsCheck.beforeFirst();
				}
				else
				{	sb.append("Query returned Results");
					do{
						sb.append(NettingsCheck.getString(ccount_for_NettingsCheck++));
						
					}while(NettingsCheck.next());
				}
				//Step 2
				sb.append("\n<br><br> 2) Nettings Flag Set Check\n  <br>");
				if(!NettingsFlagCheck1.next())
				{	
					sb.append("Query returned no results");
					NettingsFlagCheck1.beforeFirst();
					
				}
				else
				{
					sb.append("Query returned Results");
					do{
						sb.append(NettingsFlagCheck1.getString(ccount_for_NettingsFlagCheck1++));
						
					}while(NettingsFlagCheck1.next());
				}
				if(!NettingsFlagCheck2.next())
				{	
					sb.append("Query returned no results");
					NettingsFlagCheck2.beforeFirst();
					
				}
				else
				{
					sb.append("Query returned Results");
					do{
						sb.append(NettingsFlagCheck2.getString(ccount_for_NettingsFlagCheck2++));
						
					}while(NettingsFlagCheck2.next());
				}
				//Step 3
				sb.append("\n<br><br> 3)MT536 Check for ClearStream and EuroClear\n  <br>");
				if(!mt536_clearstream.next())
				{	
					sb.append("Query returned no results");
					mt536_clearstream.beforeFirst();
					
				}
				else
				{
					sb.append("Query returned Results");
					do{
						sb.append(mt536_clearstream.getString(ccount_for_mt536_clearstream++));
						
					}while(mt536_clearstream.next());
				}
				if(!mt536_Euroclear.next())
				{	
					sb.append("Query returned no results");
					mt536_Euroclear.beforeFirst();
					
				}
				else
				{
					sb.append("Query returned Results");
					do{
						sb.append(mt536_Euroclear.getString(ccount_for_mt536_Euroclear++));
						
					}while(mt536_clearstream.next());
				}
				
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			*/
			sb2.append("<br><span style="+"color:Crimson"+">** Sometimes 2-5 MT536 may not be processed due to data issue, but it is not critical.</span><br>");
			sb2.append("<br>In case any of the above status is <span style="+"color:Crimson"+">unsuccessful</span> please call below numbers:<br>");
			sb2.append("Primary Support Phone Number: +91 855-099-7252<br>");
			
			sb2.append("Pulkit : +91 788-884-1765<br>");
			sb2.append("Piyush :  +91 980-572-9936<br>");
			sb2.append("Abhijit : +91 740-415-9972<br>");
			
			sb2.append("Abhishek : +91 808-797-0916<br>");
			sb2.append("Vinoth : +91 962-988-6452<br>");
			sb2.append("Somyajit : +91 916-805-2596<br>");
			
			
			multipart = new MimeMultipart();

		emailSubject = "Post Nettings Job Validation-" + fromDate;
			emailBody=sb2.toString();
		
					
			
			//if(reportDay != null && reportDay.equals("Monday"))

		/*	emailBody = "Hi,<br> \n " +
			"<br>\n" +
			"Please find attached the report for No. of ISINs processed today." +
			"\n<br><br><br><br>" +
			"<br>Kind regards," +
			"<br>Abhishek Kumar" +
			"<br>Application Service Delivery" +
			"<br>iNautix Technologies India - A BNY Mellon Company" +
			"<br>Client Technology Solutions : Corporate Trust Technology" +
			"<br>Tel : +1 646 782 3387 ";
			*/
					
					
		/*	String message = "<html>" +
					"<body>" +
					"Click <a href=\"" + strLocationLink + "\">here</a> to activate your free subscription." +
					"</body>" +
					"</html>";
*/
			emailMessage.setSubject(emailSubject);
			//emailMessage.setText(emailBody, "text/html");
			//emailMessage.setContent(emailBody, "text/html");
			
			messageBodyPart.setText(emailBody, "UTF-8", "html");
			//messageBodyPart.setText(emailBody);
			//messageBodyPart.setContent(emailBody, "text/html");
		//	messageBodyPart1.setDataHandler(new DataHandler(DFS));
			//messageBodyPart1.setFileName(DFS.getName());
			multipart.addBodyPart(messageBodyPart);
			//multipart.addBodyPart(messageBodyPart1);
			emailMessage.setContent(multipart);
			
			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
//			for (int i = 0; i < bccEmails.length; i++) {
//				emailMessage.addRecipient(Message.RecipientType.BCC, new InternetAddress(bccEmails[i]));
//			}
			//emailMessage.addRecipient(Message.RecipientType.BCC, new InternetAddress("piyushpsh36@gmail.com"));
			//emailMessage.addRecipient(Message.RecipientType.BCC, new InternetAddress("kumar543.abhishek@gmail.com"));
			
			//for (int i = 0; i < ccEmails.length; i++) {
	//			emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
		//	}

			Transport.send(emailMessage);

			System.out.println("Email sent successfully.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}

	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;       
	}
}