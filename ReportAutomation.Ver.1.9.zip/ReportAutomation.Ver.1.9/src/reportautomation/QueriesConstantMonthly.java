package reportautomation;

public class QueriesConstantMonthly 
{
	static String strISINDetails = "select \n" +
	"    convert(varchar,l.isin) as 'ISIN', \n" +
	"    '\"' + l.issue_name + '\"' as 'Issue Name', \n" +
	"    convert(varchar,isNull((case l.jpm_is_ppa_ind when 'Y' then isNull(l.current_pool_factor,l.pool_factor) else     l.pool_factor end),1)) as 'Pool Factor', \n" +
	"    convert(varchar,l.depo_pays_down_principal_flag) as 'Amortize Issue',\n" +
	"    convert(varchar,isnull(tch1.holding_amt, 0)) as 'Clearstream Holding', \n" +
	"    convert(varchar,isnull(tch2.holding_amt,0)) as 'Euroclear Holding',\n" +
	"    convert(varchar,isnull(l.current_nominal ,0)) as 'Current Nominal', \n" +
	"    l.principle_ccy as 'CCY', \n" +
	"    convert(varchar,l.status_code) as 'Status',\n" +
	"    convert(varchar,l.maturity_date,103) as 'Maturity Date', \n" +
	"    convert(varchar,l.bare_depo_flag) as 'Depo Type',\n" +
	"    '\"' + CON.party_name + '\"' as 'PPA'\n" +
	"from v_tranche l noholdlock , tranche_clearer_holding tch1 noholdlock, tranche_clearer_holding tch2 noholdlock, gdoasis_appointments APP, contact CON\n" +
	"where status_code in ('LI','SV','DD')\n" +
	"and tch1.tranche_id =* l.tranche_id\n" +
	"and tch1.contact_id ='782969415818120' \n" +
	"and tch2.tranche_id =* l.tranche_id\n" +
	"and tch2.contact_id  = '782969687257310' \n" +
	"and l.tranche_id=APP.tranche_id\n" +
	"and APP.ppa_code=CON.contact_id\n" +
	"and CON.branch_code='CD'\n" +
	"and CON.role_id='PPA'\n" +
	"and l.branch_code = 'CD'\n" +
	"and l.bare_depo_flag <> 'I'\n" +
	"order by l.isin";

	static String strB40319444 = "select convert(varchar, v.isin) as 'ISIN', convert(varchar, v.issue_name) as 'Issue Name', \n" +
	"convert(varchar, v.status_code) as 'Oasis status', convert(varchar, v.tra_status) as 'IPA status', \n" +
	"convert(varchar, v.maturity_date) as 'Maturity Date', convert(varchar, dv.location_id) as 'Sack location', \n" +
	"(isNull(TCH.holding_amt ,0) + isNull(TCH.temp_balance ,0)) as 'CLEARSTREAM POSITION',  \n" +
	"(isNull(TCH1.holding_amt ,0) + isNull(TCH1.temp_balance ,0)) as 'EUROCLEAR POSITION' \n" +
	"from v_tranche v,depo_vault dv,tranche_clearer_holding TCH, tranche_clearer_holding TCH1  \n" +
	"where v.tranche_id = TCH.tranche_id and v.tranche_id = TCH1.tranche_id \n" +
	"and TCH.contact_id = '782969415818120' \n" +
	"and TCH1.contact_id = '782969687257310' \n" +
	"and v.tranche_id=dv.tra_identifier \n" +
	"and v.bare_depo_flag = 'S' \n" +
	"and v.branch_code in ('CD','LTS') \n" +
	"and (case  \n" +
	"when v.status_code='LI' then 'L' \n" +
	"when v.status_code='SV' then 'L' \n" +
	"when v.status_code='PR' then 'M' \n" +
	"when v.status_code='RD' then 'M' \n" +
	"when v.status_code='CA' then 'C' \n" +
	"when v.status_code='DD' then 'D' \n" +
	"else 'NULL' end \n" +
	") != v.tra_status";
	
	static String paymentVolCreditSuisseQuery = "DECLARE @end_date DATETIME \n " +
			"SELECT @end_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE())-1, '20150131'))+'  23:59') \n " +
			" \n " +
			" \n " +
			"DECLARE @first_date datetime \n " +
			"SELECT @first_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00') \n " +
			" \n " +
			" \n " +
			"select  \n " +
			"    drl.issr_prog_no, \n " +
			"    drl.issr_name  AS 'Issuer Name', \n " +
			"    convert(varchar,count(*)) as 'count'  \n " +
			"from  \n " +
			"    swift_mt564 M564 noholdlock, \n " +
			"    depo_tranche_level dtl noholdlock, \n " +
			"    depo_issr_level drl noholdlock, \n " +
			"    depo_issue_level dil noholdlock \n " +
			"where  \n " +
			"    M564.isin_no=dtl.tra_isin  \n " +
			"    and dtl.issu_identifier=dil.issu_identifier  \n " +
			"    and dil.issr_identifier =drl.issr_identifier  \n " +
			"    and drl.issr_prog_no in ('8703','8690','6089','6711','9513','10024','8702','6386','7648','6123','5924','5081', \n " +
			"    '8874','8376','8701','8751','9745','4840','11122','11012','11128') \n " +
			"    and dtl.d_ipa_flag not in('I')  \n " +
			"    and M564.source_trxn_type in ('MANUALPAYMENTS','PAYMENTS')  \n " +
			"    and M564.swift_variant_type not in ('NFRD','NIPA','NPUT','NCAL','NDIV','EXNO') \n " +
			"    and convert(datetime,M564.row_insert_date) between convert(datetime,@first_date) \n " +
			"    and convert(datetime,@end_date) \n " +
			"group by drl.issr_prog_no,drl.issr_name \n ";
	
	static String paymentVolAmericaMeryllQuery = "DECLARE @end_date DATETIME \n " +
			"SELECT @end_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE())-1, '20150131'))+'  23:59') \n " +
			" \n " +
			" \n " +
			"DECLARE @first_date datetime \n " +
			"SELECT @first_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00') \n " +
			"select  \n " +
			"    drl.issr_prog_no, \n " +
			"    drl.issr_name, \n " +
			"    count(*) as 'count'  \n " +
			"from  \n " +
			"    swift_mt564 M564 noholdlock, \n " +
			"    depo_tranche_level dtl noholdlock, \n " +
			"    depo_issr_level drl noholdlock, \n " +
			"    depo_issue_level dil noholdlock \n " +
			"where  \n " +
			"    M564.isin_no=dtl.tra_isin  \n " +
			"and dtl.issu_identifier=dil.issu_identifier  \n " +
			"and dil.issr_identifier =drl.issr_identifier  \n " +
			"and drl.issr_prog_no in  \n " +
			"( \n " +
			"'3408', \n " +
			"'7383', \n " +
			"'SA120', \n " +
			"'SA1190', \n " +
			"'7777777', \n " +
			"'8888888', \n " +
			"'8942', \n " +
			"'SA3174', \n " +
			"'SA3243', \n " +
			"'8906', \n " +
			"'SA3517', \n " +
			"'SA4094', \n " +
			"'8941', \n " +
			"'123123', \n " +
			"'123124', \n " +
			"'ML01', \n " +
			"'SA4503', \n " +
			"'SA4785', \n " +
			"'SA5221', \n " +
			"'SA5266', \n " +
			"'6934' \n " +
			") \n " +
			"and dtl.d_ipa_flag not in('I')  \n " +
			"and M564.source_trxn_type in ('MANUALPAYMENTS','PAYMENTS')  \n " +
			"and M564.swift_variant_type not in ('NFRD','NIPA','NPUT','NCAL','NDIV','EXNO') \n " +
			"and convert(datetime,M564.row_insert_date) between convert(datetime,@first_date) \n " +
			"and convert(datetime,@end_date) \n " +
			"group by drl.issr_prog_no,drl.issr_name \n " ;
	
	static String cSKVaultLocation = "select v.isin 'ISIN', \n " +
			"convert(varchar,v.issue_name) as 'Issue Name', \n " +
			"convert(varchar,v.issue_desc) as 'Issuer Name', \n " +
			"isnull(convert(varchar(20),v.issuance_date,103),'') as 'Issuance Date', \n " +
			"isnull(convert(varchar(20),v.maturity_date,103),'') as 'Maturity Date', \n " +
			"isnull(convert(varchar(20),v.pay_date,103),'') as 'Pay Date', \n " +
			"case when v.depo_global_notes_location = 'CLRS' then 'Clearstream' \n " +
			"when depo_global_notes_location = 'EURO' then 'Euroclear' \n " +
			"else depo_global_notes_location  \n " +
			"end as 'Note Location',  \n " +
			"convert(varchar, v.status_code) as 'Status Code', \n " +
			"convert(varchar, c.party_name) as 'CSK Name' \n " +
			"from v_tranche v,contact c,gdoasis_appointments g \n " +
			"where v.tranche_id = g.tranche_id \n " +
			"and v.bare_depo_flag <> 'I' \n " +
			"and c.contact_id = g.csk_code \n " +
			"--and v.note_type = 'Y' \n " +
			"and v.status_code in ('LI','DD','SV') \n " +
			"and c.party_name not in \n " +
			"(case when v.depo_global_notes_location = 'CLRS' then 'Clearstream' \n " +
			"when depo_global_notes_location = 'EURO' then 'Euroclear' \n " +
			"else depo_global_notes_location end)  \n " +
			"and (c.contact_id in ('Euroclear', 'Clearstream') or c.party_name in ('Euroclear', 'Clearstream') ) \n " ;
	
	static String volMetricsTaxonomyMT564 = "declare \n " +
			"@from_date datetime, \n " +
			"@to_date datetime \n " +
			" \n " +
			"select @from_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00') \n " +
			"select @to_date = (select convert(varchar(11),dateadd(dd,-1, dateadd(mm, 1, @from_date)))+'  23:59') \n " +
			"select SUBSTRING(CONVERT(VARCHAR(11), @to_date, 6), 4, 8) 'Month', count(*) 'MT564_CHAN' from swift_mt564 noholdlock where t22_caev_ind='CHAN'  \n " +
			"and swift_date >= @from_date and swift_date <= @to_date \n ";
	
	static String volMetricsTaxonomyMT565 = "declare \n " +
			"@from_date datetime, \n " +
			"@to_date datetime \n " +
			" \n " +
			"select @from_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00') \n " +
			"select @to_date = (select convert(varchar(11),dateadd(dd,-1, dateadd(mm, 1, @from_date)))+'  23:59') \n " +
			"select SUBSTRING(CONVERT(VARCHAR(11), @to_date, 6), 4, 8) 'Month', count(*) 'MT565_CHAN' from swift_mt565 noholdlock where t22_caev_ind='CHAN'  \n " +
			"and row_insert_date >= @from_date and row_insert_date <= @to_date \n " ;
	
	static String volMetricsTaxonomyMT535 = "declare \n " +
			"@from_date datetime, \n " +
			"@to_date datetime \n " +
			" \n " +
			"select @from_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00') \n " +
			"select @to_date = (select convert(varchar(11),dateadd(dd,-1, dateadd(mm, 1, @from_date)))+'  23:59') \n " +
			"select SUBSTRING(CONVERT(VARCHAR(11), @to_date, 6), 4, 8) 'Month', count(*) 'MT535_Sent' from swift_mt535 noholdlock \n " +
			"where swift_date >= @from_date and swift_date <= @to_date \n " ;
	
	static String volMetricsTaxonomyMT536 = "declare \n " +
			"@from_date datetime, \n " +
			"@to_date datetime \n " +
			" \n " +
			"select @from_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00') \n " +
			"select @to_date = (select convert(varchar(11),dateadd(dd,-1, dateadd(mm, 1, @from_date)))+'  23:59') \n " +
			"select SUBSTRING(CONVERT(VARCHAR(11), @to_date, 6), 4, 8) 'Month', count(*) 'MT536_Count' from swift_mt536_out noholdlock \n " +
			"where swift_date >= @from_date and swift_date <= @to_date \n " ;
	
}
