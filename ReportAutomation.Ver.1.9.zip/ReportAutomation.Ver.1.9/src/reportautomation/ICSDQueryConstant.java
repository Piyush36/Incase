package reportautomation;

public class ICSDQueryConstant 
{
	static String queryCSP = "";
	static String queryCSK = "";
	static String queryCD = "";
	static String queryEURConversion = "";
}
