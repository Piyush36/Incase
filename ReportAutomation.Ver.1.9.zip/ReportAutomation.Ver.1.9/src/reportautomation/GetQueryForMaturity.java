package reportautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class GetQueryForMaturity 
{
	static String strDate = null;
	/*public static void main(String[] args)
	{
		//getDate();
		System.out.println(new GetQueryForMaturity().getQuery());
	}*/
	
	/*static
	{
		DateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, +1);
        
        strDate = dateFormat.format(cal.getTime());
        System.out.println("Date for Maturity Report is : " + strDate);
	}*/
	
	public String getQuery(String strDate)
	{
		String maturityQuery = "DECLARE\n" +
							"@Vault_Location VARCHAR (4),\n" +
							"@From_Date DATETIME,\n" + 
							"@To_Date DATETIME\n" +
							"SELECT @Vault_Location = 'LON'\n" +
					
							"SELECT @From_Date = '" + strDate + " 00:00 AM'\n" +
							"SELECT @To_Date = '" + strDate + " 11:59 PM'\n" +
							"SELECT\n" +
							"TR.isin,\n" + 
							"(SELECT party_name\n" +
							"FROM contact CON1 NOHOLDLOCK\n" +
							"WHERE\n" +
							"contact_id = APP.ppa_code AND\n" +
							"branch_code = TR.branch_code AND\n" +
							"role_id = 'PPA') AS PPA,\n" +
							"(SELECT party_name\n" +
							"FROM contact CON1 NOHOLDLOCK\n" +
							"WHERE\n" +
							"contact_id = APP.issuer_code AND\n" +
							"branch_code = TR.branch_code AND\n" +
							"role_id = 'ISS') AS Issuer,\n" +
							"TR.maturity_date,\n" +
							"TR.issuance_date,\n" +
							"TR.principle_ccy,\n" +
							"TRDE.denomination,\n" +
							"TRDE.bond_range_from,\n" +
							"TRDE.bond_range_to,\n" +
							"(TRDE.bond_range_to - TRDE.bond_range_from + 1) AS no_of_bonds,\n" +
							"TR.current_nominal AS TotalAmount,\n" +
							"TR.int_rate_perc,\n" +
							"CASE WHEN TR.warrant_flag = 'Y' THEN 'WARRANT' WHEN (CASE WHEN TR.jpm_is_ppa_ind = 'Y' THEN ipa_issue_type_code\n" +
							"ELSE TR.oasis_issue_type_code END) = 'DRP' THEN 'DEP REC' WHEN (CASE WHEN TR.\n" +
							"jpm_is_ppa_ind =\n" + 
							"'Y' THEN\n" + 
							"ipa_issue_type_code\n" +
							"ELSE TR.\n" +
							"oasis_issue_type_code\n" + 
							"END) = \n" +
							"'IFD' THEN 'FUND'\n" +
							"ELSE (SELECT VRT.vault_issue_type_desc\n" +
							"FROM v_report_issue_type VRT NOHOLDLOCK\n" +
							"WHERE VRT.it_code = (CASE WHEN TR.jpm_is_ppa_ind = 'Y' THEN TR.ipa_issue_type_code\n" +
							"ELSE TR.oasis_issue_type_code END)) END AS vault_issue_type_desc\n" +
							"FROM\n" +
							"v_tranche TR NOHOLDLOCK,\n" +
							"gdoasis_appointments APP NOHOLDLOCK,\n" +
							"tranche_denomination TRDE NOHOLDLOCK,\n" +
							"currency_code CC NOHOLDLOCK,\n" +
							"contact CON NOHOLDLOCK\n" +
							"WHERE\n" +
							"TR.tranche_id *= TRDE.tranche_id AND\n" +
							"TRDE.contact_id *= CON.contact_id\n" +
							"AND\n" +
							"TR.tranche_id = APP.tranche_id AND\n" +
							"TR.principle_ccy = CC.ccy_code AND\n" +
							"TR.maturity_date IS NOT NULL AND\n" +
							"TR.status_code = 'LI'\n" +
							"AND\n" +
							"DATEDIFF (DAY,\n" +
							"TR.maturity_date,\n" +
							"CONVERT (VARCHAR (11),\n" +
							"@From_Date)) <= 0 AND\n" +
							"DATEDIFF (DAY,\n" +
							"TR.maturity_date,\n" +
							"CONVERT (VARCHAR (11),\n" +
							"@To_Date)) >= 0 AND\n" +
							"TR.depo_global_notes_location = @Vault_Location AND\n" +
							"TR.branch_code = 'CD'\n" +
							"ORDER BY\n" +
							"vault_issue_type_desc,\n" +
							"maturity_date,\n" +
							"isin";
		return maturityQuery;
	}
}
