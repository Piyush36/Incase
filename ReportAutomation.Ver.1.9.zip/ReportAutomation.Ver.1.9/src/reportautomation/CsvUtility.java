package reportautomation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import au.com.bytecode.opencsv.CSVWriter;

public class CsvUtility {
                

                public static Boolean createCSV(String query, String sourcePath) {
                                System.out.println("Creating CSV");
                	Connection connection = null;
            		Statement stmt = null;
            		ResultSet resultSet = null;
            		//FileOutputStream fileOut = null;
            		Boolean isData = false;
                                
                                try {
                                				connection = GetConnection.getConnection();
                                				stmt = connection.createStatement();
                                				resultSet = stmt.executeQuery(query);
                                				
                                                System.out.println("***Result set returned successfully***");
                                                                                      
                                                /*if(resultSet.next()){
                                                resultSet.isBeforeFirst();*/
                                                File file =new File(sourcePath); 
                                                CSVWriter writer = new CSVWriter(new FileWriter(file)); 
                                                writer.writeAll(resultSet, true);
                                                System.out.println("***File successfully created in "+sourcePath+" ***");
                                                writer.close();
                                               
                                                //}
                                                
                                                
                                                
                                } catch (SQLException se) {
                                                // TODO Auto-generated catch block
                                                System.out.println("***Exception occured while running the query*** ");
                                                se.printStackTrace();
                                } catch (IOException ie) {
                                                // TODO Auto-generated catch block
                                                System.out.println("***Exception occured while writing the file*** ");
                                                ie.printStackTrace();
                                }
                                catch (Exception e) {
                                                // TODO Auto-generated catch block
                                                System.out.println("***Some Exception occured while creating the report *** ");
                                                e.printStackTrace();
                                }
                                return isData;
                }

}
