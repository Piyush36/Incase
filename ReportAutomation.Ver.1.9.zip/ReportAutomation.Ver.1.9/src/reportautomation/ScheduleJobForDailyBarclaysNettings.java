package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobForDailyBarclaysNettings implements Job
{
	public void execute(JobExecutionContext arg0) throws JobExecutionException 
	{			System.out.println("Here");
		new CreateReportDailyBarclays().createReport();
		System.out.println("Here1");
		new CreateReportDailyNettings().createReport();
		System.out.println("Here 3");
		new CreateOasisManualAmortizationReport().createReport();
	}
}
