package reportautomation;

public class QueriesConstant 
{
	static String strQuery1 = "declare @datepart int,\n" +
	"@from_date datetime,\n" +
	"@to_date datetime\n" +

	"select @datepart=(case when DATEPART(CDW,getdate()) =1 then 3 else 1 end)\n" + 

	"select @from_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+' 00:00')\n" +

	"select @to_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+'  23:59')\n" +

	"SELECT VIT.it_desc, TR.issue_name,  TR.isin, CC.full_name as currency, TR.maturity_date, TR.current_nominal,\n" + 

	"(case\n" +
	"when d.tra_registered = 'Y' then 'Registered  (Y)'\n" +
	"when d.tra_registered = 'N' then 'Bearer  (N)' \n" + 
	"end) as 'Register Type',\n" +
	"upper(TR.ipa_issue_held_as_code) as issue_held_as_code\n" +

	"FROM v_tranche TR noholdlock, v_instrument_type VIT noholdlock, currency_code CC noholdlock ,depo_tranche_level d\n" +
	"Where (TR.oasis_issue_type_code = VIT.it_code or TR.ipa_issue_type_code = VIT.it_code) and\n" +
	"TR.principle_ccy = CC.ccy_code and TR.isin  = d.tra_isin and TR.active_ind = 'Y' and \n" +

	"convert(datetime,TR.issuance_date,102) between convert(datetime, @from_date,102) and convert(datetime, @to_date ,102)\n" +
	"and TR.branch_code='CD' Order By TR.isin";

	static String receiptSecuritiesQuery = "declare @datepart int,\n" + 
	"@from_date datetime,\n" +
	"@to_date datetime\n" +

	"select @datepart=(case when DATEPART(CDW,getdate()) =1 then 3 else 1 end) ---- CDW meanscaldayofweek\n" +

	"select @from_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+' 00:00')\n" +

	"select @to_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+'  23:59')\n" +

	"SELECT VIT.it_desc, TR.issue_name, TR.isin, CC.full_name as currency, TR.maturity_date, TR.current_nominal,\n" +

	"(case \n" +
	"when d.tra_registered = 'Y' then 'Registered  (Y)' \n" +
	"when d.tra_registered = 'N' then 'Bearer  (N)' \n" +
	"end) as 'Register Type',\n" +
	"upper(TR.ipa_issue_held_as_code) as issue_held_as_code\n" +

	"FROM v_tranche TR noholdlock, v_instrument_type VIT noholdlock, currency_code CC noholdlock ,depo_tranche_level d\n" +
	"Where (TR.oasis_issue_type_code = VIT.it_code or TR.ipa_issue_type_code = VIT.it_code) and\n" +
	"TR.principle_ccy = CC.ccy_code and\n" +
	"TR.isin  = d.tra_isin and\n" +
	"TR.active_ind = 'Y' and\n" +
	"convert(datetime,TR.issuance_date,102) between convert(datetime, @from_date,102) and convert(datetime, @to_date ,102)\n" +
	"and TR.branch_code='CD'-- in ('CD','CDS','LTS')\n" +
	"Order By TR.isin";

	static String allIssueQuery = "select DT.tra_isin, isnull(DI.issu_cur, '') as issu_cur,\n" + 
	"(case \n" + 
	"when DT.d_ipa_flag = 'S' then 'Y' \n" + 
	"when DT.d_ipa_flag is null then '' else 'N'\n" +
	"end) as 'Shared',\n" +
	"isnull(DT.d_tra_principle_ccy, '') as d_tra_principle_ccy,\n" +
	"isnull(DT.tra_int_curr, '') as tra_int_curr,\n" +
	"DT.d_tra_min_denom ,\n" +
	"(select min(DV.min_trade_denomination) from depo_vault DV where DV.tra_identifier = DT.tra_identifier and DT.tra_note_form = 'G')  as min_trade_denomination,\n" +
	"DT.d_tra_denom_interest_rates as d_tra_denom_interest_rates,\n" +
	"(select min(DV.claim_denom) from depo_vault DV where DV.tra_identifier = DT.tra_identifier and DT.tra_note_form = 'G') as claim_denom,\n" +
	"DL.issr_prog_no,\n" +
	"isnull(DIT.in_int_desc, '') as in_int_desc,\n" +
	"DI.prod_identifier, isnull(DT.tra_value_date, '') as tra_value_date, isnull(DI.record_date,'') as record_date, isnull(DT.tra_last_int_date,'') as tra_last_int_date,\n" +				
	"isnull(DT.tra_next_int_date, '') as tra_next_int_date, isnull(DT.tra_fx_flag, '') as tra_fx_flag, DT.tra_int_rate,\n" +
	"DT.tra_record_date_days_prior, isnull(DT.tra_coupon_type, '') as tra_coupon_type, DT.tra_int_basis,\n" +
	"isnull(DT.tra_bus_day_convention, '') as tra_bus_day_convention,\n" +
	"isnull(DT.d_adjust_flg, '') as d_adjust_flg, isnull(DT.tra_mat_date, '') as tra_mat_date, DT.tra_pool_factor,\n" +
	"isnull(DT.tra_frn_fix_date, '') as tra_frn_fix_date,\n" +
	"isnull(DT.tra_registered, '') as tra_registered,\n" +
	"isnull(TCH1.holding_amt, 0) as 'Clearstream Holding', \n" +
	"isnull(TCH2.holding_amt, 0) as 'Euroclear Holding',\n" +
	"(case \n" +
	"when TCH1.holding_amt = 0 and TCH2.holding_amt = 0 then 'Neither' \n" +
	"when TCH1.holding_amt <> 0 and TCH2.holding_amt <> 0 then 'Both' \n" +
	"when TCH1.holding_amt <> 0 and TCH2.holding_amt = 0 then 'Clearstream' \n" +
	"when TCH1.holding_amt = 0 and TCH2.holding_amt <> 0 then 'Euroclear' \n" +
	"end) as 'Held With'\n" +
	"from\n" + 
	"depo_tranche_level DT noholdlock,\n" +
	"depo_issr_level DL noholdlock,\n" +
	"depo_interest_types DIT noholdlock,\n" +
	"depo_issue_level DI noholdlock,\n" +
	"tranche_clearer_holding TCH1 noholdlock, \n" +
	"tranche_clearer_holding TCH2 noholdlock\n" +
	"where \n" +
	"DT.d_tra_branch_code='CD'\n" +
	"and DT.d_tranche_status='LI'\n" +
	"and DT.issu_identifier  = DI.issu_identifier\n" +
	"and DI.issr_identifier = DL.issr_identifier\n" +
	"and DT.tra_int_code = DIT.in_int_code\n" +
	"and TCH1.tranche_id =* DT.tra_identifier\n" +
	"and TCH1.contact_id ='782969415818120' \n" +
	"and TCH2.tranche_id =* DT.tra_identifier\n" +
	"and TCH2.contact_id  = '782969687257310'";

	static String adhocReportQuery = "declare @datepart int,\n" +
	"@from_date datetime,\n" +
	"@to_date datetime\n" +
	"select @datepart=(case when DATEPART(CDW,getdate()) =1 then 3 else 1 end)\n" +
	"select @from_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+' 04:00 PM')\n" +
	"select @to_date = (select convert(varchar(11),getdate())+' 04:00 PM')\n" +

	"select\n" + 
	"swift_mt564.isin_no,\n" +
	"SUBSTRING (('ISIN' || swift_mt564.isin_no || '/' || v_tranche.issue_name), 1, 52)  || '/',\n" +
	"swift_mt564.row_insert_date,\n" +
	"swift_mt564.destination_address,\n" +
	"swift_mt564.t20_corp_reference,\n" +
	"swift_mt564.t20_seme_reference,\n" +
	"swift_mt564.t23_function,\n" +
	"swift_mt564.t22_caev_ind,\n" +
	"swift_mt564.t98_prep_date,\n" +
	"swift_mt564.t93_holding_amount,\n" +
	"swift_mt564.t98_pay_date,\n" +
	"100,\n" + 
	"'PRCT/' || swift_mt564.t90_redm_opt_value,\n" +
	"swift_mt564.t98_pay_date,\n" +
	"swift_mt564.t98_valu_date,\n" +
	"(case when DATEPART(CDW,t98_valu_date) =1 then dateadd(dd,-3,t98_valu_date) else dateadd(dd,-1,t98_valu_date) end)\n" +
	"from swift_mt564 noholdlock,v_tranche noholdlock\n" +
	"where swift_mt564.isin_no=v_tranche.isin and\n" +
	"swift_mt564.t22_caev_ind='MCAL' and\n" +
	"swift_mt564.swift_variant_type='NCAL'\n" + 
	"and swift_mt564.row_insert_date >@from_date\n" +
	"and swift_mt564.row_insert_date <=@to_date";

	static String dRCBMT564Query = "declare @from_date datetime,\n " +
	"@to_date datetime\n " +
	"select @from_date = (select convert(varchar(11),DATEADD(mm, DATEDIFF(mm, '20150101', GETDATE()) - 1, '20150101'))+'  00:00')\n " +
	"select @to_date = (select convert(varchar(11),dateadd(dd,5, dateadd(mm, 1, @from_date)))+'  23:59')\n " +
	"select\n " +
	"    v.isin as 'ISIN', \n " +
	"    v.issue_name as 'Issue Name',\n " +
	"    v.principle_ccy as 'Principal Currency',\n " +
	"    v.ipa_issue_desc as 'IPA Issue Description',\n " +
	"    v.maturity_method as 'Maturity Method',\n " +
	"    v.maturity_proceed as 'Maturity Proceed',\n " +
	"	sm.t19_prin_amount as 'PRIN Amount',\n " +
	"	sm.t19_entl_amount as 'ENTL Amount',\n " +
	"    --sm.elig as 'ELIG',\n " +
	"    v.maturity_date as 'Maturity Date',\n " +
	"    isnull ((case \n " +
	"                when sm.contact_id = '782969415818120' then 'Clearstream'\n " +
	"                when sm.contact_id = '782969687257310' then 'Euroclear'\n " +
	"            end),'') as 'Clearer', \n " +
	"    o.t20_seme_reference as 'MT564 TRN reference', \n " +
	"    o.sent_date as 'Sent Date & Time'\n " +
	"from \n " +
	"    outgoing_swift_log o noholdlock, \n " +
	"    v_tranche v noholdlock,\n " +
	"    swift_mt564 sm noholdlock\n " +
	"where \n " +
	"    v.isin = o.isin AND\n " +
	"    sm.isin_no = o.isin AND\n " +
	"    v.isin = sm.isin_no AND\n " +
	"    o.swift_msg_type_code = 'MT564' AND \n " +
	"    o.sent_date between @from_date and @to_date AND   ---Give date of last month\n " +
	"    v.ipa_issue_desc = 'REVERSE CONVERTIBLE NOTE' AND\n " +
	"    sm.t22_caev_ind = 'REDM' AND\n " +
	"    sm.t20_seme_reference = o.t20_seme_reference AND\n " +
	"    v.maturity_method	= 'PAR' AND\n " +
	"    v.maturity_proceed = 100 \n ";

	static String liveIssueHKQuery = "select \n " +
			"    convert(varchar,TRA.isin) as 'ISIN',\n " +
			"    convert(varchar,TRA.common_code) as 'COMMON CODE',\n " +
			"    convert(varchar,(case when TRA.jpm_is_ppa_ind = 'Y' then TRA.ipa_issuance_date else TRA.issuance_date end),103) \n " +
			"    as 'ISSUE DATE',\n " +
			"    convert(varchar,TRA.maturity_date,103) as 'REDEMPTION DATE' ,\n " +
			"    convert(varchar,(isnull(tch1.holding_amt, 0)+isnull(tch1.temp_balance, 0)+isnull(tch2.holding_amt, 0)+isnull(\n " +
			"    tch2.temp_balance, 0))) as 'CURRENT HOLDING(NOMINAL)',\n " +
			"    (case when TRA.jpm_is_ppa_ind = 'Y' then TRA.ipa_issue_currency else TRA.principle_ccy end) as 'CURRENCY(ISSUE  \n " +
			"    CURRENCY)',\n " +
			"     (select CON.party_name from contact CON noholdlock , gdoasis_appointments APP noholdlock where \n " +
			"    APP.tranche_id = TRA.tranche_id and CON.contact_id = APP.issuer_code) as 'ISSUER NAME',\n " +
			"    TRA.issue_name as 'ISSUE NAME' \n " +
			"from \n " +
			"    v_tranche TRA noholdlock, \n " +
			"    tranche_clearer_holding tch1 noholdlock, \n " +
			"    tranche_clearer_holding tch2 noholdlock\n " +
			"where \n " +
			"    TRA.status_code in ('LI','DD')\n " +
			"	and TRA.bare_depo_flag <> 'I'\n " +
			"    and tch1.tranche_id =* TRA.tranche_id\n " +
			"    and tch1.contact_id ='782969415818120' --CLEARSTREAM\n " +
			"    and tch2.tranche_id =* TRA.tranche_id\n " +
			"    and tch2.contact_id  = '782969687257310' --EUROCLEAR\n " +
			"    and TRA.depo_global_notes_location = 'HK'\n " +
			"    and TRA.branch_code='CD'\n ";

	static String liveIssueNominalExpCurrency = "DECLARE @end_date DATETIME\n " +
			"SELECT @end_date = DateAdd(day, -1, convert(datetime, '1-' + datename(month, getdate()) + '-' + datename(year, getdate())))\n " +
			"DECLARE @first_date datetime --this is first day of current month\n " +
			"SELECT @first_date =convert(datetime, '1-' + datename(month, getdate()) + '-' + datename(year, getdate()))\n " +
			"select \n " +
			"    distinct convert(varchar,TR.isin) as ISIN, \n " +
			"    TR.issue_name as 'Issue Name' ,\n " +
			"    TR.principle_ccy as 'Principal Currency',\n " +
			"    TR.ipa_issue_currency as 'IPA Issue Currency',\n " +
			"    convert(varchar,TR.redemption_ccy) as 'Redemption Currency',\n " +
			"    convert(varchar,TR.interest_ccy) as 'Interest Currency',\n " +
			"    convert(varchar,(isNull(TCH.holding_amt,0)+isNull(TCH.temp_balance,0)+isNull(TCH1.holding_amt,0) \n " +
			"    +isNull(TCH1.temp_balance,0)))  as 'Current Nominal',\n " +
			"    convert(varchar,case when TR.principle_ccy = 'USD' then 1 else isnull((select case when FX.multi_div_ind = 'D' \n " +
			"    then 1/FX.exchange_rate else FX.exchange_rate end from fx_rate FX (index idx_fx_rate1) noholdlock where \n " +
			"    FX.ccy_code = TR.principle_ccy and FX.usd_ccy_code = 'USD' and FX.biz_center = 'NYC' and FX.asof_date = (select \n " +
			"    max(FX1.asof_date) from fx_rate FX1 (index idx_fx_rate1) noholdlock where FX1.ccy_code = FX.ccy_code and\n " +
			"    FX1.usd_ccy_code = FX.usd_ccy_code and FX1.biz_center = FX.biz_center and FX1.asof_date< @first_date)),1) \n " +
			"    end ) as 'Exchange Rate', \n " +
			"    convert(varchar,TR.status_code) as 'Status Code', \n " +
			"(CASE TR.depo_global_notes_location WHEN 'CLRS' THEN 'Clearstream' WHEN 'EURO' THEN 'Euroclear' \n " +
			"WHEN 'HK' THEN 'Hong Kong' WHEN 'LON' THEN 'London' WHEN 'LUX' THEN 'Luxembourg' \n " +
			"WHEN 'NON' THEN 'None' WHEN 'NY' THEN 'New York' END) VaultLocation \n " +
			"from  \n " +
			"    v_tranche TR noholdlock, \n " +
			"    currency_code CC, \n " +
			"    au_tranche_clearer_holding TCH, \n " +
			"    au_tranche_clearer_holding TCH1\n " +
			"where \n " +
			"    (TR.principle_ccy = CC.ccy_code) \n " +
			"    and TCH.tranche_id =* TR.tranche_id\n " +
			"    and TCH1.tranche_id =* TR.tranche_id\n " +
			"    and TCH.contact_id in ('782969415818120')  --, '1181351451564') --CLEARSTREAM\n " +
			"    and TCH1.contact_id in ('782969687257310')  --, '1181351456960') --EUROCLEAR\n " +
			"    and convert(char(8), convert(datetime, TCH.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, \n " +
			"    @end_date, 101), 112)\n " +
			"    and TCH.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C1 noholdlock where \n " +
			"    C1.tranche_id = TCH.tranche_id \n " +
			"    and C1.contact_id =TCH.contact_id and convert(char(8), convert(datetime, C1.last_edit_date, 101), 112) <=\n " +
			"    convert(char(8), convert(datetime, @end_date, 101), 112))\n " +
			"    and convert(char(8), convert(datetime, TCH1.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, \n " +
			"    @end_date, 101), 112)\n " +
			"    and TCH1.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C2 noholdlock where\n " +
			"    C2.tranche_id = TCH1.tranche_id \n " +
			"    and C2.contact_id =TCH1.contact_id and convert(char(8), convert(datetime, C2.last_edit_date, 101), 112) <=\n " +
			"    convert(char(8), convert(datetime, @end_date, 101), 112))\n " +
			"    and    TR.status_code in ('LI', 'DD', 'SV') \n " +
			"    and    TR.active_ind = 'Y' \n " +
			"    and    TR.branch_code in ('CD')  \n " +
			"    and    TR.bare_depo_flag not in ('I')\n " +
			"    and    (TR.oasis_issue_type_code not in ('TC') and TR.bare_depo_flag not in ('D')) \n "  +
			"    order by isin desc\n ";

	static String dailyEarlyMaturity = "create table #DA_EARLY_MATURITY_VAULT \n " +
	"( \n " +
	"col01 varchar(12) NOT NULL, \n " +
	"col02 varchar(100) NULL, \n " +
	"col03 varchar(60) NULL, \n " +
	"col04 varchar(20) NULL, \n " +
	"col05 varchar(30) NULL, \n " +
	"col06 varchar(20) NULL, \n " +
	"col07 varchar(20) NULL, \n " +
	"col08 varchar(20) NULL, \n " +
	"col09 varchar(10) NULL, \n " +
	"col10 varchar(50) NULL \n " +
	") \n " +
	"\n " +
	"declare @datepart1 int, @datepart2 int, @datepart3 int \n " +
	"select @datepart1=(CASE DATEPART(CDW,getdate()) \n " +
	"WHEN 1 THEN 5 \n " +
	"WHEN 2 THEN 5 \n " +
	"WHEN 3 THEN 5 \n " +
	"ELSE 3 \n " +
	"END) \n " +
	"select @datepart2=(CASE DATEPART(CDW,getdate()) \n " +
	"WHEN 1 THEN 5 \n " +
	"WHEN 2 THEN 5 \n " +
	"WHEN 3 THEN 4 \n " +
	"ELSE 3 \n " +
	"END) \n " +
	"select @datepart3=(CASE DATEPART(CDW,getdate()) \n " +
	"WHEN 1 THEN 5 \n " +
	"WHEN 2 THEN 5 \n " +
	"WHEN 3 THEN 3 \n " +
	"ELSE 3 \n " +
	"END) \n " +
	"\n " +
	/*"insert into #DA_EARLY_MATURITY_VAULT values('ISIN','ISSUE NAME','ISSUE TYPE','CURRENT STATUS','CURRENT HOLDING', \n " +
			"'MATURITY DATE','REDEEMED DATE','GLOBAL NOTES LOCATION','CGN/NGN','GLOBAL NOTES LOCATION') \n " +*/
	"insert into #DA_EARLY_MATURITY_VAULT \n " +
	"select TR.isin, \n " +
	"TR.issue_name, \n " +
	"(CASE jpm_is_ppa_ind \n " +
	"WHEN 'N' THEN (select issue_type_desc from issue_type noholdlock where issue_type_code=TR.oasis_issue_type_code) \n " +
	"ELSE (select it_desc from v_instrument_type noholdlock where it_code=TR.ipa_issue_type_code) \n " +
	"END), \n " +
	"TR.status_code, \n " +
	"convert(varchar,0) as CurrentHolding , \n " +
	"convert(varchar(11),TR.maturity_date,103), \n " +
	"convert(varchar(11),IT.last_verify_date,103), \n " +
	"TR.depo_global_notes_location, \n " +
	"(CASE TR.note_type \n " +
	"WHEN 'Y' THEN 'NGN' \n " +
	"ELSE 'CGN' \n " +
	"END), \n " +
	"vlc.va_desc \n " +
	"from issue_transaction IT noholdlock, v_tranche TR noholdlock, depo_vault vault, depo_vault_location_codes vlc \n " +
	"\n " +
	"where \n " +
	"TR.tranche_id=IT.tranche_id \n " +
	"and TR.isin *= vault.tra_isin \n " +
	"and vault.location_id *= vlc.va_vaultcode \n " +
	"and IT.transaction_type='MATU' \n " +
	"and TR.branch_code='CD' \n " +
	"and TR.status_code IN ('RD') \n " +
	"and datediff(dd,IT.last_verify_date,getDate()) in (@datepart1,@datepart2,@datepart3) \n " +
	"--and (TR.maturity_date > getdate() or TR.maturity_date is NULL) \n " +
	"and TR.depo_global_notes_location not in ('CLRS','EURO') \n " +
	"and TR.issue_name not like '%KOTAK%' \n " +
	"\n " +
	"union all \n " +
	"\n " +
	"SELECT \n " +
	"isin, \n " +
	"issue_name, \n " +
	"(CASE jpm_is_ppa_ind \n " +
	"WHEN 'N' THEN (select issue_type_desc from issue_type noholdlock where issue_type_code=TR.oasis_issue_type_code)\n " +
	"ELSE (select it_desc from v_instrument_type noholdlock where it_code=TR.ipa_issue_type_code) \n " +
	"END) IssueType, \n " +
	"status_code, \n " +
	"convert(varchar,(select sum(TCH2.holding_amt+TCH2.temp_balance) from tranche_clearer_holding TCH2 where \n " +
	"TCH2.tranche_id=TR.tranche_id)) as CurrentHolding, \n " +
	"convert(varchar(11), \n " +
	"maturity_date,103) maturity_date, \n " +
	"'' RedeemedDate, \n " +
	"depo_global_notes_location, \n " +
	"case note_type \n " +
	"WHEN 'N' THEN 'CGN' \n " +
	"WHEN 'Y' THEN 'NGN' \n " +
	"ELSE note_type \n " +
	"end note_type, \n " +
	"vlc.va_desc \n " +
	"FROM \n " +
	"v_tranche TR noholdlock, depo_vault vault, depo_vault_location_codes vlc \n " +
	"WHERE \n " +
	"TR.isin *= vault.tra_isin \n " +
	"and vault.location_id *= vlc.va_vaultcode \n " +
	"and \n " +
	"datediff(dd,TR.maturity_date,getdate()) in (@datepart1,@datepart2,@datepart3) \n " +
	"AND TR.branch_code='CD' \n " +
	"and TR.depo_global_notes_location not in ('CLRS','EURO') \n " +
	"and TR.issue_name not like '%KOTAK%' \n " +
	"\n " +
	"select \n " +
	"col01, \n " +
	"col02, \n " +
	"col03, \n " +
	"col04, \n " +
	"col05, \n " +
	"col06, \n " +
	"col07, \n " +
	"col08, \n " +
	"col09, \n " +
	"col10 \n " +
	"from #DA_EARLY_MATURITY_VAULT ";

	static String regulatoryReportQuery = "SELECT \n" + 
	"dt.tra_isin 'ISIN',\n" +
	"CASE (dt.tra_status) WHEN 'L' THEN 'Live' WHEN 'D' THEN 'Defaulted' WHEN 'M' THEN 'Matured' WHEN 'C' THEN 'Cancelled' END AS\n" +
	"'IPA Status',\n" +
	"CASE (dt.d_tranche_status) WHEN 'LI' THEN 'Live' WHEN 'DD' THEN 'Defaulted' WHEN 'RD' THEN 'Redeemed' WHEN 'PR' THEN \n" +
	"'Pending Redeemed' WHEN 'PS' THEN 'Pre Step Verified' WHEN 'SV' THEN 'Step Verified' WHEN 'PC' THEN 'Pre Closure' WHEN 'CA' THEN \n" +
	"'Cancelled' END AS 'GDO Status',\n" +
	"CASE (dt.d_ipa_flag) WHEN 'I' THEN 'IPA Only' WHEN 'D' THEN 'Depo Only' WHEN 'S' THEN 'Shared Issue' WHEN 'B' THEN 'Bare Depo' END \n" +
	"AS 'IPA Flag',\n" +
	"convert(char(12),  dt.d_tra_issuance_date, 103) 'Issuance Date' ,\n" +
	"convert(char(12),  vt.maturity_date, 103) 'Maturity Date' ,    \n" +
	"dt.d_global_notes_location 'Global Note Location'\n" +
	"FROM\n" +
	"depo_tranche_level dt NOHOLDLOCK,\n" +
	"v_tranche vt NOHOLDLOCK\n" +
	"where vt.isin = dt.tra_isin";

	static String dailyBarclaysReport = "SELECT  \n" +
	"		convert(varchar, v.isin) as 'ISIN',\n" +
	"		convert(varchar, d.issr_name) as 'ISSUER NAME',\n" +
	"		convert(varchar, v.issue_name) as 'ISSUE NAME',\n" +
	"		convert(varchar, v.ipa_issuance_date, 106) 'ISSUE DATE',\n" +
	"		convert(varchar, v.maturity_date, 106) 'MATURITY DATE',\n" +
	"		(select fr_desc from depo_interest_freq_codes where v.interest_freq  = depo_interest_freq_codes.fr_code) 'INTEREST FREQUENCY',\n" +
	"		convert(varchar, v.biz_day_ccy) as 'BUSINESS DAY CURRENCY',\n" +
	"		convert(varchar, v.principle_ccy) as 'PRINCIPLE CURRENCY',\n" +
	"		isnull(v.interest_ccy,'NONE') 'INTEREST CURRENCY',\n" +
	"		isnull(v.original_nominal, NULL) as 'ORIGINAL AMOUNT',\n" +
	"		isnull(v.current_nominal, NULL) as 'CURRENT AMOUNT',\n" +
	"		convert(varchar, v.current_pool_factor) as 'NEW POOL FACTOR',\n" +
	"		isnull(v.int_rate_perc,0) 'INTEREST RATE',\n" +
	"		'BASIS FOR INTEREST PAYMENT'=(\n" +
	"				CASE convert(varchar,v.basis_for_int_pay)			 \n" +
	"				WHEN '5' THEN '30/360'\n" +
	"				WHEN '7' THEN '30/365'  \n" +
	"				WHEN '1' THEN '30E+/360'   \n" +
	"				WHEN '2' THEN '*30E+/360' \n" +
	"				WHEN '6' THEN 'ACT/360F'\n" +
	"				WHEN '11' THEN 'ACT/365'  \n" +
	"				WHEN '9' THEN 'ACT/365F'   \n" +
	"				WHEN '3' THEN '*ACT/365L'\n" +
	"				WHEN '8' THEN 'ACT/ACT'   \n" +
	"				WHEN '4' THEN '*ACT/ACT ISMA'\n" +
	"				WHEN 'NULL!' THEN 'Not applicable'\n" +
	"				END ),\n" +
	"				'BUSINESS DAY RULES' =  (  \n" +
	"				case v.biz_day_rules\n" +
	"				when 'F' then 'Following Business Day'\n" +
	"				when 'M' then 'Modified Business Day'\n" +
	"				when 'P' then 'Preceding Business Day'\n" +
	"				when 'L' then 'Last Business Day'\n" +
	"				when 'X' then 'Modified Business Day/Last Business Day'\n" +
	"				when 'Y' then 'Following Business Day/Last Business Day'\n" +
	"				when '1' then 'Not Applicable'\n" +
	"				end),\n" +
	"				isnull(v.denom_interest_rate, NULL) as 'DENOM TO APPLY INTEREST RATE',\n" +
	"				(select in_int_desc from depo_interest_types where v.interest_type  = depo_interest_types.in_int_code) 'INTEREST TYPE',\n" +
	"				'FIXED INTEREST RATE'=\n" +
	"					CASE v.fixed_rate_ind \n" +
	"					WHEN 'X' THEN 'Fixed'\n" +
	"					WHEN 'F' THEN 'Floating'  \n" +
	"					END,\n" +
	"					'REGISTER TYPE' =  (  \n" +
	"					case v.issue_reg_type_code\n" +
	"					when 'Y' then 'Registered'\n" +
	"					when 'N' then 'Bearer'\n" +
	"					end),\n" +
	"					isnull(v.record_date,0) 'RECORD DATE (Days)'\n" +
	"					FROM    v_tranche v noholdlock ,         \n" +
	"					depo_issr_level d noholdlock\n" +
	"					WHERE v.issuer = d.issr_identifier \n" +
	"					AND d.issr_prog_no in ('6986','5557','8391','9575','9686','9576','5555555','9909','7867','6067','9910','8132','6696','7478','7880','6837','8390','6838','SA1800','6839','SA3296','9530','SA3436','6836','SA3443','6068','6315','8494','7863', 'SA3445', 'SA2262', 'SA3441', 'SA2262','SA3441','6600','6699','6729','6871','7344','7296','7346','7450','8198','8371','8583','8986','8987','9075','9074','6034','SA3122','SA4086','9786','9788','9859','10093','SA2111','10300','10301','SA3415','SA4041','SA4695', 'SA4829','11694',\n" +
	"							'DU001','SA5176','SA2602')    \n" +
	"	AND v.status_code in ('LI','SV') AND v.bare_depo_flag not in ('I') \n" +
	"	AND v.isin not in ('GB0071486350',\n" +
	"			'GB0071486574',\n" +
	"			'GB0071486681',\n" +
	"			'GB0076736213',\n" +
	"			'KYG5475R1406',\n" +
	"			'NO0010563448',\n" +
	"			'XS0549818309',\n" +
	"			'XS0586671424',\n" +
	"	'GB00B4V5HN27')";

	static String dailyNettingsReport = "select convert(varchar, ne.isin) as 'ISIN', convert(varchar, vt.issue_name) as 'Issue Name' , " +
			"convert(varchar, ne.netting_amt) as 'Nominal' , convert(varchar, pq.pq_datafield) as 'Receipt Date', \n" +
	"(CASE WHEN ne.contact_id='782969687257310' THEN 'Euroclear' ELSE 'Clearstream' END) as 'Instruction received from', \n" +
	"convert(varchar, pq.exception_reason) as 'Oasis Action', convert(varchar, vt.maturity_date) as 'Next Payment Date' \n" +
	"from netting_exception_log ne, v_tranche vt, pending_queue pq \n" +
	"where \n" +
	"ne.isin = vt.isin and \n" +
	"ne.tranche_id = vt.tranche_id and \n" +
	"pq.detail_link_txn_id=ne.netting_seq_no and \n" +
	"pq.pq_status_code='PACT'";
	
	static String dailyOasisManualAmortizationReport = "Declare \n "  +
    "@from_date DATETIME, \n " +
    "@to_date DATETIME, \n " +
    "@datepart int \n " +
    "select @datepart=(case when DATEPART(CDW,getdate()) =1 then 3 else 1 end) \n " +
    "select @from_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+' 00:00') \n " +
    "select @to_date = (select convert(varchar(11),dateadd(dd,-@datepart,getdate()))+'  23:59') \n " +
    "select convert(varchar, last_edit_date) as 'Date Processed', convert(varchar, isin) as 'ISIN', convert(varchar(10),value_date,110) as 'Value Date', \n " +
    "convert(varchar, current_pool_factor) as 'Current Pool Factor', convert(varchar, new_pool_factor) as 'New Pool Factor' \n " +
    "from manual_payment \n " +
    "where last_edit_date>=@from_date and last_edit_date<=@to_date and \n " +
    "payment_type_ind='AMOR' and \n " +
    "status_ind='Y' \n " ;
	
	static String dailyProg9048Report = "select  \n " +
			"convert (date, getdate()) as 'Date', convert(varchar,v.isin) as 'ISIN', convert(varchar,v.issue_name) as 'Issue Name', \n " +
			"'Clearstream Holding' = (select (holding_amt+temp_balance) from tranche_clearer_holding where tranche_clearer_holding.tranche_id=v.tranche_id and tranche_clearer_holding.contact_id ='782969415818120'), \n " +
			"'Euroclear Holding' = (select (holding_amt+temp_balance) from tranche_clearer_holding where tranche_clearer_holding.tranche_id=v.tranche_id and tranche_clearer_holding.contact_id ='782969687257310'), \n " +
			"convert(float,v.current_nominal) as 'Total Holding' \n " +
			"from v_tranche v, \n " +
			"depo_issr_level i \n " +
			"where \n " +
			"i.issr_prog_no='9048' \n " +
			"and v.issuer=i.issr_identifier \n " +
			"and v.status_code='LI' \n " +
			"and v.security_type_code='WARRANT' ";
	
	/*****************************/
	//HC-1)Nettings_Job_Processed
	static String Nettings_Processed_Query="select Count(*) "
			+"from swift_mt536_in s noholdlock, swift_mt536_in_detail sd noholdlock "
			+"where s.swift_seq_no = sd.swift_seq_no "
			+"and CONVERT(date,sd.t98_eset_date,103)>=CONVERT(date, getdate(),103)";
	//HC-1.2) Nettings_Job_UnProcessed
	static String Nettings_Processed_Query1="select Count(*) "
			+"from swift_mt536_in s noholdlock, swift_mt536_in_detail sd noholdlock "
			+"where s.swift_seq_no = sd.swift_seq_no "
			+"and sd.processed_flag = 'N' "
			+"and CONVERT(date,sd.t98_eset_date,103)>=CONVERT(date, getdate(),103)";
	
	
	//HC-2)Nettings_flag_set
	//for swift_mt535_batch
/*	static String Nettings_flag1="select  CASE contact_id WHEN '782969415818120' THEN 'Clearstream' WHEN '782969687257310' THEN 'Euroclear' END AS 'ICSD', "+
        "CASE process_flag WHEN 'S' THEN 'Yet to be sent' WHEN 'N' THEN 'Sent' END AS 'Processing Status', "+
        "CASE source_type WHEN 'NULL' THEN 'NONE' ELSE 'NONE' END  AS 'Source' from swift_mt535_batch noholdlock where branch_code='CD'"; */
	static String Nettings_flag1="select process_flag AS 'Processing Status' from swift_mt535_batch noholdlock where branch_code='CD'";
	
	//for swift_mt535_batch_cd
	/*static String Nettings_flag2="select  CASE contact_id WHEN '782969415818120' THEN 'Clearstream' WHEN '782969687257310' THEN 'Euroclear' END AS 'ICSD', "+
        "CASE process_flag WHEN 'S' THEN 'Yet to be sent' WHEN 'N' THEN 'Sent' END AS 'Processing Status', "+
        "source_type AS 'Source' from swift_mt535_batch_cd noholdlock where branch_code='CD'"; 
	*/
	static String Nettings_flag2="select process_flag AS 'Processing Status' from swift_mt535_batch_cd noholdlock where branch_code='CD'";
	
	//HC-3)MT536_clearstream
	static String swift_mt536_Clearstream1="Select Count(*) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'N' and s.branch_code = 'CD' and s.contact_id ='782969415818120' "+
	"and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)"; 
	static String swift_mt536_Clearstream="Select Count(*) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'Y'and  s.branch_code = 'CD' and s.contact_id ='782969415818120' "+
			"and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)";
	//Euroclear
	static String swift_mt536_Euroclear1="Select Count(*) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'N' and s.branch_code = 'CD' and s.contact_id ='782969687257310' "+
			" and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)";
	static String swift_mt536_Euroclear="Select Count(*) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'Y' and  s.branch_code = 'CD' and s.contact_id ='782969687257310' "+
			" and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)";
	
	/****************************/
	//HC-4)
		 static String Z5D_Check="select Count(*)  "+
				 "from v_tranche t noholdlock  "+
				 "where t.active_ind = 'Y'  "+
				 "and t.branch_code is not null  "+
				 "and (datediff( dd,t.maturity_date,getdate())>=0  "+
				  "OR (datediff( dd,getdate(),isNull(t.maturity_date,'09/09/9999'))>0 and t.status_code IN ('PR'))  "+
				  "OR (t.depo_pays_down_principal_flag = 'Y' and  "+
				   	   "( "+
				         "(t.jpm_is_ppa_ind = 'Y' and isnull(t.current_pool_factor, t.pool_factor) = 0) "+
				     		"OR "+
				     	   "(t.jpm_is_ppa_ind = 'N' and t.pool_factor = 0) "+
				         ") "+
				         "and t.branch_code in ('CD','STS') "+
				   "))  "+
				 "and t.status_code NOT IN ('DD','CA','RD')  "+
				 "and t.tranche_id NOT IN( select pi.tranche_id from payment_instruction as pi noholdlock  "+
				 "where "+
				 "pi.pay_instruct_code not in ('CANC', 'CANR', 'CANM', 'CAMR', 'DELE' ) and  "+
				 "(pi.mark_for_release_ind = 'N' or (pi.mark_for_release_ind = 'Y' and  "+
				 "pi.payment_release_ind = 'N' )) and isnull(delete_ind, 'N') = 'N' and pi.version_no = (select max(version_no) from  "+
				 "payment_instruction as pi2 noholdlock where pi2.tranche_id = pi.tranche_id and  "+
				 "pi2.contact_id = pi.contact_id and pi2.payment_type_ind = pi.payment_type_ind and  "+
				 "pi2.branch_code = pi.branch_code and pi.pay_note=pi2.pay_note and  "+
				 "pi.payment_date=pi2.payment_date  "+
				 "and pi.source_trxn_id=pi2.source_trxn_id)) ";
		 
		/***************************************************/
		 //HC-5)
		 static String S3D_Check_Processed="Select Count(s.isin) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'Y' and s.branch_code = 'CD' "+
			   		"and  v.note_type='N' and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)";
		 
		 static String S3D_Check_Unprocessed="Select Count(s.isin) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'N' and s.branch_code = 'CD' "+
			   		"and  v.note_type='N' and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)";
		 /*****************************************************/
		 //HC-6)
		 static String S4D_Check_Processed="Select Count(s.isin) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'Y' and s.branch_code = 'CD' "+
			   		"and  v.note_type='Y' and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103)";
		 
		 static String S4D_Check_Unprocessed="Select Count(s.isin) from swift_mt536_out_detail s noholdlock, v_tranche v noholdlock where s.isin=v.isin and s.processed_ind = 'N' and s.branch_code = 'CD' "+
			   		"and  v.note_type='Y' and CONVERT(date,s.row_insert_date,103) = CONVERT(date,getdate(),103) ";
		/********************************************************/
}