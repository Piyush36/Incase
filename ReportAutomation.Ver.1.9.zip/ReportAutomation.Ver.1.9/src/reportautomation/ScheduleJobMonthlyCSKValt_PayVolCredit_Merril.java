package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobMonthlyCSKValt_PayVolCredit_Merril implements Job
{
	public void execute(JobExecutionContext arg0) throws JobExecutionException 
	{
		CreateMonthlyCSKVaultReport createReportMonthlyCSKVault = new CreateMonthlyCSKVaultReport();
		createReportMonthlyCSKVault.createReport();
		
		CreateMonthlyLive_Issue_HK_Report createLive_Issue_HK_Report = new CreateMonthlyLive_Issue_HK_Report();
		createLive_Issue_HK_Report.createReport();
		
		new CreateMonthlyLiveIssCDwithExpCcyCSV().createReport();
		
		CreateMonthlyPaymentVolCreditSuisse createReportMonthlyPayVolCreditSuisse = new CreateMonthlyPaymentVolCreditSuisse();
		createReportMonthlyPayVolCreditSuisse.createReport();
		
		CreateMonthlyPaymentVolMerrylLynch createReportMonthlyPayVolMerrilLynch = new CreateMonthlyPaymentVolMerrylLynch();
		createReportMonthlyPayVolMerrilLynch.createReport();
		
		CreateMonthlyTaxonomyReport createMonthlyTaxonomyReport = new CreateMonthlyTaxonomyReport();
		createMonthlyTaxonomyReport.createReport();
		
		CreateNoOfISINProcessedMonthly createNoOfISINProcessedMonthly = new CreateNoOfISINProcessedMonthly();
		createNoOfISINProcessedMonthly.triggerCreateReport();
	}
}
