package reportautomation;
import com.ICSDReport.CreateReportCMAR;
import com.ICSDReport.CreateReportICSD;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobForDailyCMAR implements Job
{
	public void execute(JobExecutionContext context) throws JobExecutionException 
	{
		CreateReportCMAR getReportCMAR = new CreateReportCMAR();
		getReportCMAR.CMARReport();
	}

}
