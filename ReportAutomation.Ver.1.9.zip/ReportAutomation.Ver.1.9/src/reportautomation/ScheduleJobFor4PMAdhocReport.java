package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobFor4PMAdhocReport implements Job
{
	public void execute(JobExecutionContext context) throws JobExecutionException 
	{
		Create4PMAdhocReport create4PMAdhocReport = new Create4PMAdhocReport();
		create4PMAdhocReport.createReport();
	}

}
