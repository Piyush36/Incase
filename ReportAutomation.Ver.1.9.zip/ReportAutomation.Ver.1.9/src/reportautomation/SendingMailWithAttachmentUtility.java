package reportautomation;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailWithAttachmentUtility {


	public static void main(String[] args) 
	{
		
	}
	public  void sendMail(String filename, String emailSubject, String emailBody, String[] toEmails, String[] ccEmails)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		MimeBodyPart messageBodyPart1;
		FileDataSource DFS;
		Multipart multipart;
		String from;
		String emailPort;
		String emailHost;
		String emailBodyWithSignature = emailBody + "<br><br><br><span style=\"font-family:Verdana;font-size:14px\"> Regards</span>,<br>"+
				"<span style=\"color:MediumBlue;font-weight:bold;font-family:Georgia;font-size:18px\">TEAM CTSD GDO</span><br>"+
				
					"<span style=\"color:Grey;font-size:14px\">ctsd.gdoasis@bnymellon.com</span>";
		try
		{
			emailPort = "25";															//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);
			from = "ctsd.gdoasis@bnymellon.com";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();
			messageBodyPart1 =	new MimeBodyPart();
			DFS	= new FileDataSource(filename);
			multipart = new MimeMultipart();
			

			emailMessage.setSubject(emailSubject);
			//messageBodyPart.setText(emailBodyWithSignature, "UTF-8", "html");
			emailMessage.setContent(emailBodyWithSignature, "text/html");
			messageBodyPart.setDataHandler(new DataHandler(DFS));
			messageBodyPart.setFileName(DFS.getName());
			messageBodyPart1.setText(emailBodyWithSignature, "UTF-8", "html");
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(messageBodyPart1);
			emailMessage.setContent(multipart);

			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			System.out.println(DFS.getName());

			Transport.send(emailMessage);

			System.out.println("Email sent successfully for " + emailSubject);
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}
}