package reportautomation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateMailForHC2 {
StringBuilder sb=new StringBuilder();
	public static void main(String Args[])
	{
		new CreateMailForHC().createMail();
		
		
		
		System.out.println("Mail for HC Sent");
	}

	void createMail() {
		// TODO Auto-generated method stub
		Connection connection = null;
		Statement stmt = null;
		Statement stmt1 = null;
		ResultSet resultSet_for_Nettings_Processed = null;
		ResultSet resultSet_for_Nettings_Processed1 = null;
		
		
		SendingMailForHC obj_to_mail2=new SendingMailForHC();
		try{
			connection=GetConnection.getConnection();
			stmt=connection.createStatement();
			stmt1=connection.createStatement();
			//1stCheck
			System.out.println("Query is : " + QueriesConstant.Nettings_Processed_Query);
			resultSet_for_Nettings_Processed = stmt.executeQuery(QueriesConstant.Nettings_Processed_Query);
		    System.out.println("ResultSet for Nettings_Processed_Query is prepared");
		    sb.append("<br> 1) Nettings Processed Check\n : ");
		    
		    resultSet_for_Nettings_Processed1 = stmt1.executeQuery(QueriesConstant.Nettings_Processed_Query1);
		    resultSet_for_Nettings_Processed1.next();
		    resultSet_for_Nettings_Processed.next();
		    System.out.println("ResultSet for Nettings_Processed_Query1 is prepared");
		   
		    if(resultSet_for_Nettings_Processed1.getInt(1)>0)
		    {
		    	sb.append("<span style=\"color:red\">Unsuccessful<br></span>");
		    }
		    else
		    {
		    	sb.append("<span style=\"color:green\">Successful<br></span>");
		    }

		    sb.append("Incoming Nettings: "+resultSet_for_Nettings_Processed.getString(1)+" ");
		    sb.append("\n Unprocessed: "+resultSet_for_Nettings_Processed1.getString(1)+ "\n");

		    
		  resultSet_for_Nettings_Processed.close();
			 resultSet_for_Nettings_Processed1.close();
			
		
		    
		  
		    obj_to_mail2.sendMail(sb);
		}
		
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
	}
		
	}
	 
}
