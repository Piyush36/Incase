package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class CreateMonthlyDRCBMT564Report 
{
	public static void main(String[] args)
	{
		new CreateMonthlyDRCBMT564Report().createReport();
		
	}
	
	public void createReport()
	{	File directory = null;
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		List<String> reportDay = new ArrayList<String>();
		reportDay = getDateStringMap();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		String strEmailSubject = null;
		String strEmailBody = null;
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("Sheet1");
		    
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.dRCBMT564Query);
		    System.out.println("ResultSet is prepared for DRCMMT564");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createDRCBMT564Header();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();

		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell(icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setIndention((short) 0);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
	            HSSFCell cell1 = row.createCell(0);
	            cell1.setCellValue(resultSet.getString(1));							//ISIN
	            cell1.setCellStyle(style);
	            
	            HSSFCell cell2 = row.createCell(1);
	            cell2.setCellValue(resultSet.getString(2));							//Issue Name
	            cell2.setCellStyle(style);
	            
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));							//Principal Currency
		    	cell3.setCellStyle(style);
		    	
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));							//IPA Issue Description
		    	cell4.setCellStyle(style);
		    	
		    	HSSFCell cell5 = row.createCell(4);
		    	cell5.setCellValue(resultSet.getString(5));							//Maturity Method
		    	cell5.setCellStyle(style);
		    	
		    	HSSFCell cell6 = row.createCell(5);									//Maturity Proceed
		    	Float maturityProceed = resultSet.getFloat(6);
		    	cell6.setCellValue(maturityProceed);	
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);									//PRIN Amount
		    	cell7.setCellValue(resultSet.getString(7));
		    	cell7.setCellStyle(style);
		    	
		    	HSSFCell cell8 = row.createCell(7);									//ENTL Amount
		    	cell8.setCellValue(resultSet.getString(8));
		    	cell8.setCellStyle(style);
		    	
		    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aaa");
		    	String strMaturityDate = dt.format(resultSet.getDate(9));
		    	String strSentDateTime = dt.format(resultSet.getDate(12));
		    	
		    	HSSFCell cell9 = row.createCell(8);									//Maturity Date
		    	cell9.setCellValue(strMaturityDate);
		    	cell9.setCellStyle(style);
		    	
		    	HSSFCell cell10 = row.createCell(9);
		    	cell10.setCellValue(resultSet.getString(10));						//Clearer
		    	cell10.setCellStyle(style);
		    	
		    	HSSFCell cell11 = row.createCell(10);
		    	cell11.setCellValue(resultSet.getString(11));						//MT 564 TRN Reference
		    	cell11.setCellStyle(style);
		    	
		    	HSSFCell cell12 = row.createCell(11);
		    	cell12.setCellValue(strSentDateTime);   					//Sent Date and Time
		    	cell12.setCellStyle(style);
		    	
		    }
		    
		    for(int columnIndex = 0; columnIndex < 12; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    directory= new File("C:/Data/Report Automation/Reports/Monthly/DRCB MT564 Notifications/");
		    if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/Monthly/DRCB MT564 Notifications/ is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
		   //String reportDay = getTodayDate();
		    String[] strToList = {"thomas.bolton@bnymellon.com"};
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com", "jonathan.burns@bnymellon.com"};
		    strEmailSubject = "DRCB MT564 Notifications - 01 "+ reportDay.get(0).substring(3, 11) + " - 06 " + reportDay.get(1).substring(3, 11);
		    strEmailBody = "Hi, \n " +
					"\n" +
					"Please find attached DRCB MT564 Notifications report for 01 " + reportDay.get(0).substring(3, 11) + " - 06 " + reportDay.get(1).substring(3, 11) + "\n";
		    String reportPath = "C:/Data/Report Automation/Reports/Monthly/DRCB MT564 Notifications/DRCB MT564 Notifications 01 "+ reportDay.get(0).substring(3, 11) + " - 06 " + reportDay.get(1).substring(3, 11) + ".xls";
		    //String reportPath = "C:/Report Automation/Reports/DRCB MT564.xls";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		    System.out.println("DRCB MT 564 Report is created successfully!");
		    new SendingMailWithAttachmentUtility().sendMail(reportPath, strEmailSubject, strEmailBody, strToList, strCCList);
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	private List<String> getDateStringMap() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("dd MMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		System.out.println("Day is : " + dayValue);
		//if(dayValue != null && dayValue.equals("Monday"))
		//{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -1);
			strDate = dateFormat1.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.MONTH, +1);
			strDate = dateFormat1.format(cal.getTime());
			listofDays.add(strDate);
		//}
		return listofDays;
	}
	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}
}
