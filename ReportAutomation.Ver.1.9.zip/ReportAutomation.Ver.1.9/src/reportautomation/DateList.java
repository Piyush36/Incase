package reportautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class DateList {
	
	List<String> reportDay = new ArrayList<String>();
	
	public static void main(String[] args) {
		//System.out.println();

	}
	
	
	public String todaysDate()
	{
		reportDay = getDateString();
		String strTodayDate = reportDay.get(0);
		//String strMonth = reportDay.get(0).substring(3, 6);
		//String strYear = reportDay.get(0).substring(7, 11);
		return strTodayDate;
	}
	public String lastWorkingDayDate()
	{
		reportDay = getDateString();
		String strYesterdayDate = reportDay.get(1);
		return strYesterdayDate;
	}
	
	private List<String> getDateString()
	{

		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		//DateFormat dateFormat1 = new SimpleDateFormat("MMM dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		System.out.println("Day is : " + dayValue);
		if(dayValue != null && dayValue.equals("Monday"))
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -3);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		else
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -1);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		return listofDays;
	
	}

}
