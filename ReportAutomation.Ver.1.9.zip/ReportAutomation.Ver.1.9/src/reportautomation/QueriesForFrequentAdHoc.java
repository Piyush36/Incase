package reportautomation;

public class QueriesForFrequentAdHoc {
	
	static String jpmfLUXReconcilation = "--Report for Peter Hyde \n " +
			" \n " +
			"DECLARE @end_date DATETIME \n " +
			"SELECT @end_date = convert(date, dateadd(dd,-1,getdate()), 101) \n " +
			" \n " +
			"--Insert into gdo_rp_mo_D39800926 values('ISIN','ISSUE NAME','Current Nominal','PPA')  \n " +
			" \n " +
			"select  \n " +
			"    convert(varchar,tra_isin) as 'ISIN',  \n " +
			"    convert(varchar,d_issue_name) as 'Issue Name',  \n " +
			"    --convert(varchar,TCH.holding_amt) as 'Clearstream Holding',  \n " +
			"    --convert(varchar,TCH1.holding_amt) as 'Euroclear Holding' ,  \n " +
			"    convert(varchar,TCH.holding_amt) as 'Clearstream Holding', \n " +
			"    convert(varchar,TCH1.holding_amt) as 'Euroclear Holding', \n " +
			"    convert(varchar,(TCH.holding_amt+TCH1.holding_amt)) as 'Current Nominal', \n " +
			"    --'Principle Currency'= (select full_name from currency_code where currency_code.ccy_code=l.d_tra_principle_ccy), \n " +
			"    --l.d_tra_principle_ccy,  \n " +
			"    --convert(varchar,l.d_tranche_status),  \n " +
			"    --convert(varchar,l.d_tra_instr_type), \n " +
			"    --l.d_tra_branch_code \n " +
			"    convert(varchar,c.party_name) as 'PPA' \n " +
			"from  \n " +
			"    depo_tranche_level l,  \n " +
			"    au_tranche_clearer_holding TCH,  \n " +
			"    au_tranche_clearer_holding TCH1, \n " +
			"    contact c,  \n " +
			"    gdoasis_appointments g \n " +
			"where  \n " +
			"    TCH.tranche_id = l.tra_identifier \n " +
			"    and g.ppa_code=c.contact_id \n " +
			"    and g.tranche_id=l.tra_identifier \n " +
			"    and TCH1.tranche_id = l.tra_identifier \n " +
			"    and TCH.contact_id in ('782969415818120')  --, '1181351451564') --CLEARSTREAM \n " +
			"    and TCH1.contact_id in ('782969687257310')  --, '1181351456960') --EUROCLEAR \n " +
			"and convert(char(8), convert(datetime, TCH.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @end_date, 101), 112) \n " +
			"and TCH.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C1 noholdlock where C1.tranche_id = TCH.tranche_id  \n " +
			"and C1.contact_id =TCH.contact_id and convert(char(8), convert(datetime, C1.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @end_date, 101), 112)) \n " +
			"and convert(char(8), convert(datetime, TCH1.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @end_date, 101), 112) \n " +
			"and TCH1.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C2 noholdlock where C2.tranche_id = TCH1.tranche_id  \n " +
			"and C2.contact_id =TCH1.contact_id and convert(char(8), convert(datetime, C2.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @end_date, 101), 112)) \n " +
			"    and l.d_tra_branch_code = 'CD' \n " +
			"    and l.d_tranche_status = 'LI' \n " +
			"   -- and (TCH.holding_amt>0 or TCH1.holding_amt>0) \n " +
			"    and d_tra_instr_type = 'IFD' \n " +
			"    and c.role_id='PPA' ";
	
	static String lehman_e39027778report = "select  \n " +
			"    convert(varchar,l.isin) as 'ISIN',  \n " +
			"    convert(varchar,l.issue_name) as 'Issue Name',  \n " +
			"    convert(varchar,isNull((case l.jpm_is_ppa_ind when 'Y' then isNull(l.current_pool_factor,l.pool_factor) else     l.pool_factor end),1)) as 'Pool Factor',  \n " +
			"    convert(varchar,l.depo_pays_down_principal_flag) as 'Amortize Issue', \n " +
			"    convert(varchar,isnull(tch1.holding_amt, 0)) as 'Clearstream Holding',  \n " +
			"    convert(varchar,isnull(tch2.holding_amt,0)) as 'Euroclear Holding', \n " +
			"    convert(varchar,isnull(l.current_nominal ,0)) as 'Current Nominal',  \n " +
			"    convert(varchar,l.principle_ccy) as 'CCY',  \n " +
			"    convert(varchar,l.status_code) as 'Status', \n " +
			"    convert(varchar,l.maturity_date,103) as 'Maturity Date', --103 UK date format(dd/mm/yyyy) \n " +
			"    convert(varchar,l.bare_depo_flag) as 'Depo Type', \n " +
			"    convert(varchar,CON.party_name) as 'PPA' \n " +
			"from v_tranche l noholdlock , tranche_clearer_holding tch1 noholdlock, tranche_clearer_holding tch2 noholdlock, gdoasis_appointments APP, contact CON \n " +
			"where status_code in ('LI','SV','DD') \n " +
			"and tch1.tranche_id =* l.tranche_id \n " +
			"and tch1.contact_id ='782969415818120' --CLEARSTREAM \n " +
			"and tch2.tranche_id =* l.tranche_id \n " +
			"and tch2.contact_id  = '782969687257310' --EUROCLEAR \n " +
			"and l.tranche_id=APP.tranche_id \n " +
			"and APP.ppa_code=CON.contact_id \n " +
			"and CON.branch_code='CD' \n " +
			"and CON.role_id='PPA' \n " +
			"and l.branch_code = 'CD' \n " +
			"and l.bare_depo_flag <> 'I' \n " +
			"order by l.isin \n " ;
	
	static String iPACertReport = "select * from cert_ipa_report noholdlock \n " +
			"where  convert(varchar(11),last_edit_date) = convert(varchar(11),getDate())  \n " +
			"having seq_no = max(seq_no) and processed_ind =  'N'";
	
	public static String alertsTodayBefore_1_Hr (String today, String timeGMT)
	{
		String tstReport ="select * from ipa_to_depo_alerts where alert_date >='"+today+"' and alert_date <='"+timeGMT+"'";
		return tstReport;
	}
	static String totalAlertCount = "select count(*) from ipa_to_depo_alerts";
	static String totalAlertCountType = "select distinct (select count(*) from ipa_to_depo_alerts), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='COA'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='RFD'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='CIS'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='ASE'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='APC'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='MCA'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='CES'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='PID'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='INC'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='MAC'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='SID'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='CAE'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='ISS'), \n " +
			"(select count(*) from ipa_to_depo_alerts where alert_type='STV') \n " +
			"from ipa_to_depo_alerts \n " ;

}
