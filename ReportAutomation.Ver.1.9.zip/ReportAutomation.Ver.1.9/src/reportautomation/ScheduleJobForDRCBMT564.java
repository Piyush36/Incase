package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobForDRCBMT564 implements Job
{
	public void execute(JobExecutionContext context) throws JobExecutionException 
	{
		//CreateMonthlyDRCBMT564Report createMonthlyDRCBMT564Report = new CreateMonthlyDRCBMT564Report();
		//createMonthlyDRCBMT564Report.createReport();
		new CreateMonthlyDRCBMT564Report().createReport();
	}

}
