package reportautomation;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendingMailUtility {


	/*public static void main(String[] args) 
	{
		
	}*/
	public  void sendMail(String emailSubject, String emailBody, String[] toEmails, String[] ccEmails)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		String from;
		String emailPort;
		String emailHost;
		String emailBodyWithSignature = emailBody + "<br><br><br><span style=\"font-family:Verdana;font-size:14px\"> Regards</span>,<br>"+
		"<span style=\"color:MediumBlue;font-weight:bold;font-family:Georgia;font-size:18px\">TEAM CTSD GDO</span><br>"+
	
		"<span style=\"color:Grey;font-size:14px\">ctsd.gdoasis@bnymellon.com</span>";
		try
		{
			emailPort = "25";															//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);
			from = "ctsd.gdoasis@bnymellon.com";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));			
			emailMessage.setSubject(emailSubject);
			emailMessage.setContent(emailBodyWithSignature, "text/html");			//Setting body part as HTML


			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			Transport.send(emailMessage);

			System.out.println("Email sent successfully for " + emailSubject);
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}
}