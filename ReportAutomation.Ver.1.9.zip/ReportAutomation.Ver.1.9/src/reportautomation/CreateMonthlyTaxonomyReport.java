package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class CreateMonthlyTaxonomyReport 
{



	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateMonthlyTaxonomyReport().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		File destDirectory = null;
		String strMonth = null;
		String strYear = null;
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/Monthly/MU Mapping Volume Metrics and Taxonomy/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/Monthly/MU Mapping Volume Metrics and Taxonomy/ is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
			
			strMonth = getTodayDateArray().get(0);
			strYear = getTodayDateArray().get(1);
			destDirectory = new File("//whexpfseur11/CorpTrustPoole/VITAL/COMDEP/Management Useful Info/MU Mapping Volume Metrics and Taxonomy/"+ strYear + "/" + strMonth + "/");
			if(!destDirectory.exists())
			{
				if(destDirectory.mkdirs())
					System.out.println("//whexpfseur11/CorpTrustPoole/VITAL/COMDEP/Management Useful Info/MU Mapping Volume Metrics and Taxonomy/"+ strYear + "/" + strMonth + "/ is created" );
				else
					System.out.println("Failed to create destination directory!");
			}
			else
				System.out.println("destination directory already exist");
		    
		    //String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/CTTISGASD-3821 - MT564 and MT565 - " + strMonth +" "+ strYear + ".xls";
		    String reportSrcPathMT53x = directory.toString() + "/CTTISGASD-3821 - MT535 and MT536 -" + strMonth +" "+ strYear + ".xls";
		    String reportDestPath = "//whexpfseur11/CorpTrustPoole/VITAL/COMDEP/Management Useful Info/MU Mapping Volume Metrics and Taxonomy/"+ strYear + "/" + strMonth +
		    		"/CTTISGASD-3821 - MT564 and MT565 - " + strMonth +" "+ strYear + ".xls";
		    String reportDestPathMT53x = "//whexpfseur11/CorpTrustPoole/VITAL/COMDEP/Management Useful Info/MU Mapping Volume Metrics and Taxonomy/"+ strYear + "/" + strMonth +
		    		"/CTTISGASD-3821 - MT535 and MT536 - " + strMonth +" "+ strYear + ".xls";
		  //Workbook for 1st report MT565 and 564
		    HSSFWorkbook workbook = new HSSFWorkbook();
		    CreateMultipleXLSSheetUtility utility=new CreateMultipleXLSSheetUtility();
		    utility.createXLS(workbook ,QueriesConstantMonthly.volMetricsTaxonomyMT564, "MT564_Count", reportSrcPath);
		    utility.createXLS(workbook ,QueriesConstantMonthly.volMetricsTaxonomyMT565, "MT565_Count", reportSrcPath);
		    //Workbook for 2nd report MT535 and 536
		    HSSFWorkbook workbook2 = new HSSFWorkbook();
		    CreateMultipleXLSSheetUtility utility2=new CreateMultipleXLSSheetUtility();
		    utility2.createXLS(workbook2 ,QueriesConstantMonthly.volMetricsTaxonomyMT535, "MT535_Count", reportSrcPathMT53x);
		    utility2.createXLS(workbook2 ,QueriesConstantMonthly.volMetricsTaxonomyMT536, "MT536_Count", reportSrcPathMT53x);
		    //CreateXLSUtility.createXLS(QueriesConstant.dailyProg9048Report, reportDay, reportSrcPath);
		    System.out.println("MU Mapping Volume Metrics and Taxonomy Report is created successfully!");
		    
		    // Moving file to the network Location
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    ReportMovementUtil.copyFiles(reportSrcPathMT53x, reportDestPathMT53x);
		    
		    //Below code Sneds mail to anna field for report creation and placement
		    String[] strToList = {"Anna.Field@BNYMellon.com"};  //Anna.Field@BNYMellon.com
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
		    String strEmailSubject = "Taxonomy, Unit Costing and Metrics Monthly Report Jira 3821";
		    String strEmailBody = "Hi,<br> \n " +
					"<br>\n" +
					"The Reports for the last month are now available " +
					"<a href='file:" + destDirectory + "'> here.</a> <br>\n" +
					"\n<br><br>";
		    // Below method is responsible to send the mail.
		    new SendingMailUtility().sendMail(strEmailSubject, strEmailBody, strToList, strCCList);
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate; 
	}
	
	private List<String> getTodayDateArray() 
	{
		String strDate = null;
		String strDate1 = null;
		List<String> dateArray = new ArrayList<String>();
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        
        strDate = dateFormat.format(cal.getTime());
        strDate1 = dateFormat1.format(cal.getTime());
       /* StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	strMonth = strToken.
        }*/
        dateArray.add(strDate.substring(3, 6));
        dateArray.add(strDate.substring(7, 11));
        dateArray.add(strDate1);
        return dateArray; 
	}

}
