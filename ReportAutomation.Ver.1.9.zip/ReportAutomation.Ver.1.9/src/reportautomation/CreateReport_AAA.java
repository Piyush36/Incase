package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CreateReport_AAA {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateReport_AAA().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Morning/Daily Maturity/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Morning/Daily Maturity/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/Daily Maturity - " + reportDay + ".xls";
		    String reportDestPath = "//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/All Issues/All Issues Report - " + reportDay + ".xls";
		    
		    CreateXLSUtility.createXLS("Query", "Sheet Name", reportSrcPath);
		    
		    // Moving file to the network Location
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}

}
