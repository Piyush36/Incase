package reportautomation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class CreatePD21N4Report 
{
	public static void main(String[] args) 
	{
		new CreatePD21N4Report().createReport();
	}
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		FileInputStream file = null;
		FileOutputStream fileOut = null;
		try
		{
			file = new FileInputStream(new File("C:/Data/Report Automation/Reports/DailyReports/Morning/PD-21/GFU template_BNYM_ToUse_N4_Template.xls"));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
		    HSSFSheet sheet = workbook.getSheetAt(0);
		    int lastIndex = sheet.getLastRowNum();
		    for(int i = 1; i <= lastIndex; i++)
		    {
		    	row = sheet.getRow(i);
		    	sheet.removeRow(row);
		    }
		    
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueryPD21N4.strQueryN4_1);
			System.out.println("ResultSet is prepared");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	
		    	row = sheet.createRow(++rowid);
		    	
		    	HSSFCell cell1 = row.createCell(0);
		    	cell1.setCellValue(resultSet.getString(1));				//Data
		    	cell1.setCellStyle(style);
		    	
		    	HSSFCell cell2 = row.createCell(1);
		    	cell2.setCellValue(resultSet.getString(2));				//GFU Data
		    	cell2.setCellStyle(style);
		    	
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));				//SOR ID
		    	cell3.setCellStyle(style);
		    	
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));				//Event ID
		    	cell4.setCellStyle(style);
		    	
		    	HSSFCell cell5 = row.createCell(4);
		    	cell5.setCellValue(resultSet.getString(5));				//Reference of the message
		    	cell5.setCellStyle(style);
		    	
		    	HSSFCell cell6 = row.createCell(5);
		    	cell6.setCellValue(resultSet.getString(6));				//Function of the message
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);
		    	cell7.setCellValue(resultSet.getString(7));				//Event Type
		    	cell7.setCellStyle(style);
		    	
		    	HSSFCell cell8 = row.createCell(7);
		    	cell8.setCellValue(resultSet.getString(8));				//Mandatory/Voluntary indicator
		    	cell8.setCellStyle(style);
		    	
		    	HSSFCell cell9 = row.createCell(8);
		    	cell9.setCellValue(resultSet.getString(9));				//Information status
		    	cell9.setCellStyle(style);
		    	
		    	HSSFCell cell10 = row.createCell(9);
		    	cell10.setCellValue(resultSet.getString(10));			//ISIN Code
		    	cell10.setCellStyle(style);
		    	
		    	HSSFCell cell11 = row.createCell(10);
		    	cell11.setCellValue(resultSet.getString(11));			//Local 
		    	cell11.setCellStyle(style);
		    	
		    	HSSFCell cell12 = row.createCell(11);
		    	cell12.setCellValue(resultSet.getString(12));			//Common Code
		    	cell12.setCellStyle(style);
		    	
		    	HSSFCell cell13 = row.createCell(12);
		    	cell13.setCellValue(resultSet.getString(13));			//Security Name
		    	cell13.setCellStyle(style);
		    	
		    	HSSFCell cell14 = row.createCell(13);
		    	cell14.setCellValue(resultSet.getString(14));			//Day Count Fraction/Interest rule
		    	cell14.setCellStyle(style);
		    	
		    	HSSFCell cell15 = row.createCell(14);
		    	cell15.setCellValue(resultSet.getString(15));				//ISO Currency Nominal Amount
		    	cell15.setCellStyle(style);
		    	
		    	SimpleDateFormat dt1 = new SimpleDateFormat("yyyyMMdd");
		    	/*if(resultSet.getDate(16) != null)							//Rate fix Date = Event Determination Date
		    	{
		    		String str = dt1.format(resultSet.getDate(16));
		    		HSSFCell cell16 = row.createCell(15);
		    		cell16.setCellValue(str);
		    		cell16.setCellStyle(style);
		    	}*/
		    	
		    	HSSFCell cell17 = row.createCell(16);
		    	cell17.setCellValue(resultSet.getString(17));				//Pool Factor (new/current)
		    	cell17.setCellStyle(style);
		    	
		    	HSSFCell cell18 = row.createCell(17);
		    	cell18.setCellValue(resultSet.getString(18));				//Pool Factor (old/previous) (in interest payment)
		    	cell18.setCellStyle(style);
		    	
		    	HSSFCell cell19 = row.createCell(18);
		    	cell19.setCellValue(resultSet.getString(19));				//Exercise Minimal quantity.
		    	cell19.setCellStyle(style);
		    	
		    	HSSFCell cell20 = row.createCell(19);
		    	cell20.setCellValue(resultSet.getString(20));				//ISO Quantity type Exercise Minimal
		    	cell20.setCellStyle(style);
		    	
		    	HSSFCell cell21 = row.createCell(20);
		    	cell21.setCellValue(resultSet.getString(21));				//Exercise Multiple quantity
		    	cell21.setCellStyle(style);
		    	
		    	HSSFCell cell22 = row.createCell(21);
		    	cell22.setCellValue(resultSet.getString(22));				//ISO Quantity type  Exercise Multiple
		    	cell22.setCellStyle(style);
		    	
		    	HSSFCell cell23 = row.createCell(22);
		    	cell23.setCellValue(resultSet.getString(23));				//Safekeeping Account
		    	cell23.setCellStyle(style);
		    	
		    	HSSFCell cell24 = row.createCell(23);
		    	cell24.setCellValue(resultSet.getString(24));				//Holding quantity/Eligible balance
		    	cell24.setCellStyle(style);
		    	
		    	HSSFCell cell25 = row.createCell(24);
		    	cell25.setCellValue(resultSet.getString(25));				//ISO Quantity type Eligible Balance
		    	cell25.setCellStyle(style);
		    	
		    	/*if(resultSet.getDate(26) != null)							//Ex Date
		    	{
		    		String str = dt1.format(resultSet.getDate(26));
		    		HSSFCell cell26 = row.createCell(25);
		    		cell26.setCellValue(str);
		    		cell26.setCellStyle(style);
		    	}*/
		    	
		    	/*if(resultSet.getDate(27) != null)							//Information/Announcement date
		    	{
		    		String str = dt1.format(resultSet.getDate(27));
		    		HSSFCell cell27 = row.createCell(26);
		    		cell27.setCellValue(str);
		    		cell27.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(28) != null)							//Lottery Date
		    	{
		    		String str = dt1.format(resultSet.getDate(28));
		    		HSSFCell cell28 = row.createCell(27);
		    		cell28.setCellValue(str);
		    		cell28.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(29) != null)							//Record date
		    	{
		    		String str = dt1.format(resultSet.getDate(29));
		    		HSSFCell cell29 = row.createCell(28);
		    		cell29.setCellValue(str);
		    		cell29.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(30) != null)							//Redemption date
		    	{
		    		String str = dt1.format(resultSet.getDate(30));
		    		HSSFCell cell30 = row.createCell(29);
		    		cell30.setCellValue(str);
		    		cell30.setCellStyle(style);
		    	}*/
		    	
		    	HSSFCell cell31 = row.createCell(30);
		    	cell31.setCellValue(resultSet.getString(31));				//agents/depository deadline
		    	cell31.setCellStyle(style);
		    	
		    	HSSFCell cell32 = row.createCell(31);
		    	cell32.setCellValue(resultSet.getString(32));				//market deadline
		    	cell32.setCellStyle(style);
		    	
		    	HSSFCell cell33 = row.createCell(32);
		    	cell33.setCellValue(resultSet.getString(33));				//Continuously convertible
		    	cell33.setCellStyle(style);
		    	
		    	/*if(resultSet.getDate(34) != null)							//Blocking Date
		    	{
		    		String str = dt1.format(resultSet.getDate(34));
		    		HSSFCell cell34 = row.createCell(33);
		    		cell34.setCellValue(str);
		    		cell34.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(35) != null)							//Un-Blocking date
		    	{
		    		String str = dt1.format(resultSet.getDate(35));
		    		HSSFCell cell35 = row.createCell(34);
		    		cell35.setCellValue(str);
		    		cell35.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(36) != null)							//Coupon Start Date
		    	{
		    		String str = dt1.format(resultSet.getDate(36));
		    		HSSFCell cell36 = row.createCell(35);
		    		cell36.setCellValue(str);
		    		cell36.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(37) != null)							//Coupon end date
		    	{
		    		String str = dt1.format(resultSet.getDate(37));
		    		HSSFCell cell37 = row.createCell(36);
		    		cell37.setCellValue(str);
		    		cell37.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(38) != null)							//Exercise start date
		    	{
		    		String str = dt1.format(resultSet.getDate(38));
		    		HSSFCell cell38 = row.createCell(37);
		    		cell38.setCellValue(str);
		    		cell38.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(39) != null)							//Exercise end date
		    	{
		    		String str = dt1.format(resultSet.getDate(39));
		    		HSSFCell cell39 = row.createCell(38);
		    		cell39.setCellValue(str);
		    		cell39.setCellStyle(style);
		    	}*/
		    	
		    	HSSFCell cell40 = row.createCell(39);
		    	cell40.setCellValue(resultSet.getString(40));				//Interest Rate
		    	cell40.setCellStyle(style);
		    	
		    	HSSFCell cell41 = row.createCell(40);
		    	cell41.setCellValue(resultSet.getString(41));				//Redemption Rate
		    	cell41.setCellStyle(style);
		    	
		    	HSSFCell cell42 = row.createCell(41);
		    	cell42.setCellValue(resultSet.getString(42));				//Drawing Percentage
		    	cell42.setCellStyle(style);
		    	
		    	HSSFCell cell43 = row.createCell(42);
		    	cell43.setCellValue(resultSet.getString(43));				//Gross Amount
		    	cell43.setCellStyle(style);
		    	
		    	HSSFCell cell44 = row.createCell(43);
		    	cell44.setCellValue(resultSet.getString(44));				//Entitlement ratio Proceed Security quantity
		    	cell44.setCellStyle(style);
		    	
		    	HSSFCell cell45 = row.createCell(44);
		    	cell45.setCellValue(resultSet.getString(45));				//Entitlement ratio Base Security Quantity
		    	cell45.setCellStyle(style);
		    	
		    	HSSFCell cell46 = row.createCell(45);
		    	cell46.setCellValue(resultSet.getString(46));				//Redemption amount
		    	cell46.setCellStyle(style);
		    	
		    	HSSFCell cell47 = row.createCell(46);
		    	cell47.setCellValue(resultSet.getString(47));				//Iso currency redemption amount
		    	cell47.setCellStyle(style);
		    	
		    	HSSFCell cell48 = row.createCell(47);
		    	cell48.setCellValue(resultSet.getString(48));				//Iso Currency exercise price
		    	cell48.setCellStyle(style);
		    	
		    	HSSFCell cell49 = row.createCell(48);
		    	cell49.setCellValue(resultSet.getString(49));				//Exercise Price
		    	cell49.setCellStyle(style);
		    	
		    	HSSFCell cell50 = row.createCell(49);
		    	cell50.setCellValue(resultSet.getString(50));				//Other Certification
		    	cell50.setCellStyle(style);
		    	
		    	/*if(resultSet.getDate(51) != null)							//Suspension start date
		    	{
		    		String str = dt1.format(resultSet.getDate(51));
		    		HSSFCell cell51 = row.createCell(50);
		    		cell51.setCellValue(str);
		    		cell51.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(52) != null)							//Suspension end date
		    	{
		    		String str = dt1.format(resultSet.getDate(52));
		    		HSSFCell cell52 = row.createCell(51);
		    		cell52.setCellValue(str);
		    		cell52.setCellStyle(style);
		    	}*/
		    	
		    	HSSFCell cell53 = row.createCell(52);
		    	cell53.setCellValue(resultSet.getString(53));				//CA Option Number
		    	cell53.setCellStyle(style);
		    	
		    	HSSFCell cell54 = row.createCell(53);
		    	cell54.setCellValue(resultSet.getString(54));				//Indicator (Options)
		    	cell54.setCellStyle(style);
		    	
		    	HSSFCell cell55 = row.createCell(54);
		    	cell55.setCellValue(resultSet.getString(55));				//Fractions
		    	cell55.setCellStyle(style);
		    	
		    	HSSFCell cell56 = row.createCell(55);
		    	cell56.setCellValue(resultSet.getString(56));				//ISO Currency Cash Amount
		    	cell56.setCellStyle(style);
		    	
		    	HSSFCell cell57 = row.createCell(56);
		    	cell57.setCellValue(resultSet.getString(57));				//Default action flag
		    	cell57.setCellStyle(style);
		    	
		    	HSSFCell cell58 = row.createCell(57);
		    	cell58.setCellValue(resultSet.getString(58));				//Period Interest Rate (interest amount in percent)
		    	cell58.setCellStyle(style);
		    	
		    	HSSFCell cell59 = row.createCell(58);
		    	cell59.setCellValue(resultSet.getString(59));				//Taxable Amount (Dividends)
		    	cell59.setCellStyle(style);
		    	
		    	HSSFCell cell60 = row.createCell(59);
		    	cell60.setCellValue(resultSet.getString(60));				//Non Taxable Amount (Dividends)
		    	cell60.setCellStyle(style);
		    	
		    	HSSFCell cell61 = row.createCell(60);
		    	cell61.setCellValue(resultSet.getString(61));				//Fees percentage
		    	cell61.setCellStyle(style);
		    	
		    	HSSFCell cell62 = row.createCell(61);
		    	cell62.setCellValue(resultSet.getString(62));				//Fees amount
		    	cell62.setCellStyle(style);
		    	
		    	HSSFCell cell63 = row.createCell(62);
		    	cell63.setCellValue(resultSet.getString(63));				//Credit/Debit Indicator for SecMove Option
		    	cell63.setCellStyle(style);
		    	
		    	HSSFCell cell64 = row.createCell(63);
		    	cell64.setCellValue(resultSet.getString(64));				//Proceeds Security / Resulting Security Identification (ISIN/Local Code/ Common Code)
		    	cell64.setCellStyle(style);
		    	
		    	HSSFCell cell65 = row.createCell(64);
		    	cell65.setCellValue(resultSet.getString(65));				//Proceeds Security Name /Resulting Security Name
		    	cell65.setCellStyle(style);
		    	
		    	HSSFCell cell66 = row.createCell(65);
		    	cell66.setCellValue(resultSet.getString(66));				//Drawing Amount
		    	cell66.setCellStyle(style);
		    	
		    	HSSFCell cell67 = row.createCell(66);
		    	cell67.setCellValue(resultSet.getString(67));				//ISO Quantity Type Drawing Amount
		    	cell67.setCellStyle(style);
		    	
		    	HSSFCell cell68 = row.createCell(67);
		    	cell68.setCellValue(resultSet.getString(68));				//Due Date / Settlement date (Securities)
		    	cell68.setCellStyle(style);
		    	
		    	HSSFCell cell69 = row.createCell(68);
		    	cell69.setCellValue(resultSet.getString(69));				//Credit/Debit indicator for CashMove option
		    	cell69.setCellStyle(style);
		    	
		    	HSSFCell cell70 = row.createCell(69);
		    	cell70.setCellValue(resultSet.getString(70));				//Amount Expected
		    	cell70.setCellStyle(style);
		    	
		    	/*if(resultSet.getDate(71) != null)							//Due Date
		    	{
		    		String str = dt1.format(resultSet.getDate(71));
		    		HSSFCell cell71 = row.createCell(70);
		    		cell71.setCellValue(str);
		    		cell71.setCellStyle(style);
		    	}
		    	
		    	if(resultSet.getDate(72) != null)							//Value Date
		    	{
		    		String str = dt1.format(resultSet.getDate(72));
		    		HSSFCell cell72 = row.createCell(71);
		    		cell72.setCellValue(str);
		    		cell72.setCellStyle(style);
		    	}*/
		    	
		    	HSSFCell cell73 = row.createCell(72);
		    	cell73.setCellValue(resultSet.getString(73));				//exchange rate / FX Rate
		    	cell73.setCellStyle(style);
		    	
		    	HSSFCell cell74 = row.createCell(73);
		    	cell74.setCellValue(resultSet.getString(74));				//ISO Currency FX Rate (First Currency Code)
		    	cell74.setCellStyle(style);
		    	
		    	HSSFCell cell75 = row.createCell(74);
		    	cell75.setCellValue(resultSet.getString(75));				//ISO Currency FX Rate (Second Currency Code)
		    	cell75.setCellStyle(style);
		    	
		    	HSSFCell cell76 = row.createCell(75);
		    	cell76.setCellValue(resultSet.getString(76));				//Resulting Amount
		    	cell76.setCellStyle(style);
		    	
		    	HSSFCell cell77 = row.createCell(76);
		    	cell77.setCellValue(resultSet.getString(77));				//Issuing Agent
		    	cell77.setCellStyle(style);
		    	
		    	HSSFCell cell78 = row.createCell(77);
		    	cell78.setCellValue(resultSet.getString(78));				//Paying agent
		    	cell78.setCellStyle(style);
		    	
		    	HSSFCell cell79 = row.createCell(78);
		    	cell79.setCellValue(resultSet.getString(79));				//Narrative including exercise notice (CONVERT PUTOPT PUTOPEN) others
		    	cell79.setCellStyle(style);
		    	
		    	HSSFCell cell80 = row.createCell(79);
		    	cell80.setCellValue(resultSet.getString(80));				//Narrative text (conditions index others)
		    	cell80.setCellStyle(style);
		    	
		    	HSSFCell cell81 = row.createCell(80);
		    	cell81.setCellValue(resultSet.getString(81));				//Number of Days Accrued
		    	cell81.setCellStyle(style);
		    	
		    	HSSFCell cell82 = row.createCell(81);
		    	cell82.setCellValue(resultSet.getString(82));				//Frequency
		    	cell82.setCellStyle(style);
		    	
		    	HSSFCell cell83 = row.createCell(82);
		    	cell83.setCellValue(resultSet.getString(83));				//Form
		    	cell83.setCellStyle(style);
		    	
		    	HSSFCell cell84 = row.createCell(83);
		    	cell84.setCellValue(resultSet.getString(84));				//Business Convention Rule
		    	cell84.setCellStyle(style);
		    	
		    	HSSFCell cell85 = row.createCell(84);
		    	cell85.setCellValue(resultSet.getString(85));				//Taxable Event
		    	cell85.setCellStyle(style);
		    	
		    	HSSFCell cell86 = row.createCell(85);
		    	cell86.setCellValue(resultSet.getString(86));				//Adjusted Period
		    	cell86.setCellStyle(style);
		    	
		    	HSSFCell cell87 = row.createCell(86);
		    	cell87.setCellValue(resultSet.getString(87));				//New Comment 
		    	cell87.setCellStyle(style);
		    	
		    	HSSFCell cell88 = row.createCell(87);
		    	cell88.setCellValue(resultSet.getString(88));				//Historic Comment
		    	cell88.setCellStyle(style);
		    	
		    	HSSFCell cell89 = row.createCell(88);
		    	cell89.setCellValue(resultSet.getString(89));				//Updated Flag
		    	cell89.setCellStyle(style);
		    	
		    	HSSFCell cell90 = row.createCell(89);
		    	cell90.setCellValue(resultSet.getString(90));				//Comparison Status
		    	cell90.setCellStyle(style);
		    	
		    	HSSFCell cell91 = row.createCell(90);
		    	cell91.setCellValue(resultSet.getString(91));				//Indicator
		    	cell91.setCellStyle(style);
		    	
		    	HSSFCell cell92 = row.createCell(91);
		    	cell92.setCellValue(resultSet.getString(92));				//Ownership Indicator
		    	cell92.setCellStyle(style);
		    	
		    	HSSFCell cell93 = row.createCell(92);
		    	cell93.setCellValue(resultSet.getString(93));				//Current Nominal
		    	cell93.setCellStyle(style);
		    	
		    	HSSFCell cell94 = row.createCell(93);
		    	cell94.setCellValue(resultSet.getString(94));				//Maturity Method
		    	cell94.setCellStyle(style);
		    	
		    	HSSFCell cell95 = row.createCell(94);
		    	cell95.setCellValue(resultSet.getString(95));				//Amortization Amount
		    	cell95.setCellStyle(style);
		    	
		    	HSSFCell cell96 = row.createCell(95);
		    	cell96.setCellValue(resultSet.getString(96));				//Depo Type
		    	cell96.setCellStyle(style);
		    	
		    	HSSFCell cell97 = row.createCell(96);
		    	cell97.setCellValue(resultSet.getString(97));				//Zero Rate Valid
		    	cell97.setCellStyle(style);
		    }
		    for(int columnIndex = 0; columnIndex < 98; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    file.close();
		    String reportDay = getYesterdayDateString();
		    String reportPath = "C:/Data/Report Automation/Reports/DailyReports/Morning/PD-21/GFU template_BNYM_ToUse_N4_" + reportDay + ".xls";
		    fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getYesterdayDateString() 
	{
		String strDate = null;

		DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 21);

		strDate = dateFormat.format(cal.getTime());

		return strDate;
        
	}
}