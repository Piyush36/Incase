package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CreateMonthlyCSKVaultReport 
{



	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateMonthlyCSKVaultReport().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		File destDirectory = null;
		
		try
		{
			 
			System.out.println("\n ***Creating monthly CSK Vault Report***");
			// This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/Monthly/CSK Vault Report/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/Monthly/CSK Vault Report/ is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
			
			destDirectory = new File("//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/" +
					"GD Oasis/ProdReports/Monthly/");
			if(!destDirectory.exists())
			{
				if(destDirectory.mkdirs())
					System.out.println("//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/" +
							"Adhoc Requests/Reports/GD Oasis/ProdReports/Monthly/");
				else
					System.out.println("Failed to create destination directory!");
			}
			else
				System.out.println("destination directory already exist");
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString()+ "/" + reportDay + "_Monthly_X41421296_CSK_Vault_Location.csv";
		    String reportDestPath = destDirectory.toString()+ "/" + reportDay + "_Monthly_X41421296_CSK_Vault_Location.csv";
		    
		    CsvUtility.createCSV(QueriesConstantMonthly.cSKVaultLocation, reportSrcPath);
		    System.out.println("Monthly CSK Vault Report is created successfully!");
		    
		    // Moving file to the network Location
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}
	
}
