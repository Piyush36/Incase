package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class CreateIPACertReport 
{

	public static void main(String[] args) 
	{
		new CreateIPACertReport().createReport();
	}
	
	public void createReport()
	{
		int rowid = 0;
		File directory = null;
		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;
		try
		{
		    
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(QueriesForFrequentAdHoc.iPACertReport);
		    System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    while(rs.next())
		    {
		    	
		    }
		    
		 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Evening/IPACert Report/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Evening/IPACert Report/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/IPACERT - " + reportDay + ".FTM";
		    //String reportDestPath = "//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/All Issues/All Issues Report - " + reportDay + ".xls";
		    /*FileOutputStream fileOut = new FileOutputStream(reportSrcPath);
		    byte[] byteArray = rs.getBytes(icell);
		    fileOut.write(byteArray);
		    //workbook.write(fileOut);
		    fileOut.close();*/
		    
		    ResultSetMetaData rsmd = rs.getMetaData();
		    //System.out.println("querying SELECT * FROM XXX");
		    int columnsNumber = rsmd.getColumnCount();
		    while (rs.next()) {
		        for (int i = 1; i <= columnsNumber; i++) {
		            if (i > 1) System.out.print(",  ");
		            String columnValue = rs.getString(i);
		            System.out.print(columnValue + " " + rsmd.getColumnName(i));
		        }
		        System.out.println("");
		    }
		    
		    System.out.println("All Issue Report is created successfully!");
		    // Moving file to the network Location
		    //ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		  //Sending Mail through Generic mail sending method
		    /*String[] strToList = {"ditdatareconciliation@bnymellon.com"};  //ditdatareconciliation@bnymellon.com
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
		    String strEmailSubject = "All Issues Report - " + reportDay;
		    String strEmailBody = "Hi,<br><br> \n " +
					"Please find the All Issues Report for today " +
					"<a href='file:'> here.</a> <br>\n";
		    new SendingMailUtility().sendMail(strEmailSubject, strEmailBody, strToList, strCCList);*/
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(rs != null)
					rs.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);  									//Selecting Yesterday's date
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate; 
	}

}
