package reportautomation;

import nettingautomation.ScheduleJobForNettings;
import automation.SchedulerForContinuousChecks;
import automation.SchedulerForContinuousChecksHourly;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class CronTriggerForGDOReports
{
	public static void main( String[] args ) throws Exception
	{   	
		
		
		// Get the Scheduler
		Scheduler scheduler = new StdSchedulerFactory().getScheduler();
		
		//job and trigger for Continuously running checks
		JobDetail jobForContinuousChecks = JobBuilder.newJob(SchedulerForContinuousChecks.class).withIdentity("Job1", "group2").build();
	Trigger triggerForContinuousChecks = TriggerBuilder.newTrigger().withIdentity("Trigger1", "group2").withSchedule(CronScheduleBuilder.cronSchedule("0 0/10 12-21 ? * MON-FRI")).build();

		//JobDetail jobForHourlyChecks = JobBuilder.newJob(SchedulerForContinuousChecksHourly.class).withIdentity("Job16", "group1").build();
		//Trigger triggerForHourlyChecks = TriggerBuilder.newTrigger().withIdentity("Trigger16", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 0 1-23 ? * MON-FRI")).build();
		 
		// Job and trigger for Daily Reports according to execution time
		JobDetail jobForAllIssueReport = JobBuilder.newJob(ScheduleJobForAllIssueReport.class).withIdentity("Job2", "group1").build();
		Trigger triggerForAllIssueReport = TriggerBuilder.newTrigger().withIdentity("Trigger2", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 30 10 ? * MON-FRI")).build();

		JobDetail jobForDailyEarlyMaturityReport = JobBuilder.newJob(ScheduleJobForDailyEarlyMaturityReport.class).withIdentity("Job4", "group1").build();
		Trigger triggerForDailyEarlyMaturityReport = TriggerBuilder.newTrigger().withIdentity("Trigger4", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 10 12 ? * MON-FRI")).build();
		
		JobDetail jobForDailyBarclaysNettingsReport = JobBuilder.newJob(ScheduleJobForDailyBarclaysNettings.class).withIdentity("Job6", "group1").build();
		Trigger triggerForDailyBarclaysNettingsReport = TriggerBuilder.newTrigger().withIdentity("Trigger6", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 01 13 ? * MON-FRI")).build();
		
		JobDetail jobForDailyICSD = JobBuilder.newJob(ScheduleJobForDailyICSD.class).withIdentity("Job12", "group1").build();
		Trigger triggerForDailyICSD = TriggerBuilder.newTrigger().withIdentity("Trigger12", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 10 13 ? * MON-FRI")).build();
		
		
		JobDetail jobForNoOfISINProcessedDailyReport = JobBuilder.newJob(ScheduleJobForNoOfISINProcessedDailyReport.class).withIdentity("Job5", "group1").build();
		Trigger triggerForNoOfISINProcessedDailyReport = TriggerBuilder.newTrigger().withIdentity("Trigger5", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 05 17 ? * MON-FRI")).build();
		
		JobDetail jobFor4PMAdhocReport = JobBuilder.newJob(ScheduleJobFor4PMAdhocReport.class).withIdentity("Job1", "group1").build();
		Trigger triggerFor4PMAdhocReport = TriggerBuilder.newTrigger().withIdentity("Trigger1", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 35 21 ? * MON-FRI")).build();
		
		JobDetail jobForDailyNettings = JobBuilder.newJob(ScheduleJobForNettings.class).withIdentity("Job7", "group1").build();
		Trigger triggerForDailyNettings = TriggerBuilder.newTrigger().withIdentity("Trigger7", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 15 23 ? * MON-FRI")).build();
		
		JobDetail jobFor11PMProg9048Report = JobBuilder.newJob(ScheduleJobFor11PMProg9048Report.class).withIdentity("Job8", "group1").build();
		Trigger triggerFor11PMProg9048Report = TriggerBuilder.newTrigger().withIdentity("Trigger8", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 15 03 ? * TUE-SAT")).build();
		//Job for 2nd Mail
		JobDetail jobForHC_Check = JobBuilder.newJob(ScheduleJobForHCMail.class).withIdentity("Job14", "group1").build();
		Trigger triggerForHC_Check = TriggerBuilder.newTrigger().withIdentity("Trigger14", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 15 01 ? * TUE-SAT")).build();
		//Job for 3rd mail
		JobDetail jobForHC_Check3 = JobBuilder.newJob(ScheduleJobForHCMail.class).withIdentity("Job15", "group1").build();
		Trigger triggerForHC_Check3 = TriggerBuilder.newTrigger().withIdentity("Trigger15", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 30 01 ? * TUE-SAT")).build();
		
		JobDetail jobForN1DCheck = JobBuilder.newJob(ScheduleJobForN1DCheck.class).withIdentity("Job13", "group1").build();
		Trigger triggerForN1DCheck = TriggerBuilder.newTrigger().withIdentity("Trigger13", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 20 00 ? * TUE-SAT")).build();
		
		
		// Job and trigger for Weekly Report on timely order
		JobDetail jobForWeeklyRegIssuesReport = JobBuilder.newJob(ScheduleJobForRegIssuesWeeklyReport.class).withIdentity("Job10", "group1").build();
		Trigger triggerForWeeklyRegIssuesReport = TriggerBuilder.newTrigger().withIdentity("Trigger10", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 01 14 ? * MON")).build();
		
		JobDetail jobForNoOfISINProcessedWklyReport = JobBuilder.newJob(ScheduleJobForNoOfISINProcessedWklyReport.class).withIdentity("Job3", "group1").build();
		Trigger triggerForNoOfISINProcessedWklyReport = TriggerBuilder.newTrigger().withIdentity("Trigger3", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 30 12 ? * MON")).build();

		
		
		// Job and trigger for First Day Monthly Reports - CSK Vault, Payment Volume Credit Suisse/Merril Lynch, Taxonomy report, ISINs processed monthly
		JobDetail jobForMonthlyCSK_PayVolCredit_Merril = JobBuilder.newJob(ScheduleJobMonthlyCSKValt_PayVolCredit_Merril.class).withIdentity("Job9", "group1").build();
		Trigger triggerForMonthlyCSK_PayVolCredit_Merril = TriggerBuilder.newTrigger().withIdentity("Trigger9", "group1").withSchedule(CronScheduleBuilder.cronSchedule("20 04 15 1W * ?")).build();

		JobDetail jobForMonthlyDRCBMT564 = JobBuilder.newJob(ScheduleJobForDRCBMT564.class).withIdentity("Job11", "group1").build();
		Trigger triggerForMonthlyDRCBMT564 = TriggerBuilder.newTrigger().withIdentity("Trigger11", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 34 14 7W * ?")).build();
				
		// Job and trigger for Ad Hoc Report
		//JobDetail jobForAdHocReport = JobBuilder.newJob(ScheduleJobForAdHocReport.class).withIdentity("Job14", "group1").build();
		//Trigger triggerForAdHocReport = TriggerBuilder.newTrigger().withIdentity("Trigger14", "group1").withSchedule(CronScheduleBuilder.cronSchedule("0 00 09 ? * MON-FRI")).build();
		
		JobDetail jobForDailyCMAR = JobBuilder.newJob(ScheduleJobForDailyCMAR.class).withIdentity("Job17", "group1").build();
		Trigger triggerForDailyCMAR = TriggerBuilder.newTrigger().withIdentity("Trigger17", "group1").withSchedule(CronScheduleBuilder.cronSchedule("00 25 13 ? * MON-FRI")).build();
		
		//schedule job and trigger for Continuous checks
	scheduler.scheduleJob(jobForContinuousChecks, triggerForContinuousChecks);
		//scheduler.scheduleJob(jobForHourlyChecks, triggerForHourlyChecks);
		
		//schedule job and trigger for 4PMAdhocReport
		scheduler.scheduleJob(jobFor4PMAdhocReport, triggerFor4PMAdhocReport);

		//schedule job and trigger for AllIssueReport
		scheduler.scheduleJob(jobForAllIssueReport, triggerForAllIssueReport);

		//schedule job and trigger for Number Of ISIN's Processed Weekly
		scheduler.scheduleJob(jobForNoOfISINProcessedWklyReport, triggerForNoOfISINProcessedWklyReport);
		
		//schedule job and trigger for Daily Early Maturity
		scheduler.scheduleJob(jobForDailyEarlyMaturityReport, triggerForDailyEarlyMaturityReport);
		
		//schedule job and trigger for Number Of ISIN's Procesed Daily
		scheduler.scheduleJob(jobForNoOfISINProcessedDailyReport, triggerForNoOfISINProcessedDailyReport);
		
		//schedule job and trigger for Daily Barclys/Nettings Reports
		scheduler.scheduleJob(jobForDailyBarclaysNettingsReport, triggerForDailyBarclaysNettingsReport);
		
		//schedule job and trigger for Daily Barclys/Nettings Reports
		scheduler.scheduleJob(jobForDailyNettings, triggerForDailyNettings);
		
		//schedule job and trigger for 11PMProg9048Report
		scheduler.scheduleJob(jobFor11PMProg9048Report, triggerFor11PMProg9048Report);

		//schedule job and trigger for Weekly Registered Issues
		scheduler.scheduleJob(jobForWeeklyRegIssuesReport, triggerForWeeklyRegIssuesReport);
		
		//schedule job and trigger for Daily ICSD Report
		scheduler.scheduleJob(jobForDailyICSD, triggerForDailyICSD);
		
		//schedule job and trigger for Monthly CSK Vault, Payment Volume Credit Suisse/Merril Lynch
		scheduler.scheduleJob(jobForMonthlyCSK_PayVolCredit_Merril, triggerForMonthlyCSK_PayVolCredit_Merril);
		
		//MonthlyDRCBMT564
		scheduler.scheduleJob(jobForMonthlyDRCBMT564, triggerForMonthlyDRCBMT564);
		
		//Scheduler for Daily Nettings Dependent batch check Mail
		scheduler.scheduleJob(jobForHC_Check, triggerForHC_Check);
		
		//Scheduler for Daily Nettings check Mail
		scheduler.scheduleJob(jobForN1DCheck, triggerForN1DCheck);
		
		//Scheduler for 3rd Mail 
		scheduler.scheduleJob(jobForHC_Check3, triggerForHC_Check3);
		
		//schedule job and trigger for AdHoc Report
		//scheduler.scheduleJob(jobForAdHocReport, triggerForAdHocReport);
		//schedule job for daily CMAR
		scheduler.scheduleJob(jobForDailyCMAR, triggerForDailyCMAR);
		
		//Start the Scheduler
		scheduler.start();
	}
}
