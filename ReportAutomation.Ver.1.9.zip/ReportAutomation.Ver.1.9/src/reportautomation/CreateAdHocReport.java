package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CreateAdHocReport 
{



	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateAdHocReport().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		//File destDirectory = null;
		
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/Ad Hoc Reports/Lehmann Report/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/Ad Hoc Reports/Lehmann Report/ is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
			
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/JIRA CTTISGASD-6653 E39027778 - Isin Details Report - Lehmans -" + reportDay + ".csv";
		    
		    CsvUtility.createCSV(QueriesForFrequentAdHoc.lehman_e39027778report, reportSrcPath);
		    System.out.println("Report " + reportSrcPath + " is created successfully!");
		    
		    String[] strToList = {"kellee.mein@bnymellon.com", "graeme.cumming@bnymellon.com"};  // its.puts.and.calls@bnymellon.com
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
		    String strEmailSubject = "JIRA CTTISGASD-6653 E39027778 - Isin Details Report - Lehmans -" + reportDay;
		    String strEmailBody = "Hi,<br><br> \n " +
					"Please find the attached required report. \n";
		    new SendingMailWithAttachmentUtility().sendMail(reportSrcPath, strEmailSubject, strEmailBody, strToList, strCCList);
		    //new SendingMailForJPMFLuxReconcilationReport().sendMail(reportSrcPath, reportDay); // Change the to and CC here
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate; 
	}
	
	private List<String> getTodayDateArray() 
	{
		String strDate = null;
		String strDate1 = null;
		List<String> dateArray = new ArrayList<String>();
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        strDate1 = dateFormat1.format(cal.getTime());
       /* StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	strMonth = strToken.
        }*/
        dateArray.add(strDate.substring(3, 6));
        dateArray.add(strDate.substring(7, 11));
        dateArray.add(strDate1);
        return dateArray; 
	}

}
