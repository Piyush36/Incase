package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Create11PMProg9048Report 
{



	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new Create11PMProg9048Report().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		//File destDirectory = null;
		
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Evening/Prog No 9048 report/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Evening/Prog No 9048 report/ is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/Prog No 9048 Report - " + reportDay + ".xls";
		    
		    CreateXLSUtility.createXLS(QueriesConstant.dailyProg9048Report, reportDay, reportSrcPath);
		    System.out.println("Program 9048 Report is created successfully!");
		    
		    //Sending Mail through Generic mail sending method
		    String[] strToList = {"depo.stockqueries@bnymellon.com"};  //depo.stockqueries@bnymellon.com
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com","PeterSamuel.Hyde@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
		    String strEmailSubject = "Programme No 9048 Daily Report - " + reportDay;
		    String strEmailBody = "Hi,<br><br> \n " +
					"Please find the attached report for Program No 9048 for " + reportDay + "as at 23:00 UK Time. \n";
		    new SendingMailWithAttachmentUtility().sendMail(reportSrcPath, strEmailSubject, strEmailBody, strToList, strCCList);
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);  									//Selecting Yesterday's date
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate; 
	}

}
