package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CreateReportDailyNettings 
{



	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateReportDailyNettings().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		Boolean isData = false;
		
		/*
		List<String> todayDateArray = null;
		File destDirectory = null;
		String strDate = null;
		String strMonth = null;
		String strYear = null;
		*/
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Morning/Daily Nettings/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Morning/Daily Nettings/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
			
			/*
			todayDateArray = getTodayDateArray();
			strMonth = todayDateArray.get(0);
			strYear = todayDateArray.get(1);
			strDate = todayDateArray.get(2);
			
			destDirectory = new File("//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/" +
					"Application Support/Adhoc Requests/Reports/IPA/" + strYear + "/" + strMonth + "/" + strDate + "/");
			if(!destDirectory.exists())
			{
				if(destDirectory.mkdirs())
					System.out.println("//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/" +
							"Application Support/Adhoc Requests/Reports/IPA/" + strYear + "/" + strMonth + "/" + strDate + "/ is created");
				else
					System.out.println("Failed to create destination directory!");
			}
			else
				System.out.println("directory already exist");
		    */
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/Daily Nettings Report " + reportDay + ".xls";
		    
		    
		    String reportDestPath = "//whexpfseur11/corptrustpoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/" +
		    			"Reports/GD Oasis/ProdReports/Daily/Daily Nettings Report " + reportDay + ".xls";
		    
		    
		    isData = CreateXLSUtility.createXLS(QueriesConstant.dailyNettingsReport, "Sheet1", reportSrcPath);
		    System.out.println("Daily Nettings Report is created successfully!");
		    
		    // Moving file to the network Location
		    if(isData)
		    	ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    else
		    	System.out.println("No Data in Daily Nettings report. Hence No Report Movement for date : " + reportDay);
		    
		    // This piece of code will be sending the report to the client if it is not blank 
		    /*
		    if(isData)
		    	new SendingMailForDailyNettingsReport().sendMail(reportSrcPath);
		    else
		    	System.out.println("No Data in Daily Nettings report. date is : " + reportDay);
		    */
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        strDate = dateFormat.format(cal.getTime());
        return strDate; 
	}
	
	private List<String> getTodayDateArray() 
	{
		String strDate = null;
		String strDate1 = null;
		List<String> dateArray = new ArrayList<String>();
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        strDate1 = dateFormat1.format(cal.getTime());
       /* StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	strMonth = strToken.
        }*/
        dateArray.add(strDate.substring(3, 6));
        dateArray.add(strDate.substring(7, 11));
        dateArray.add(strDate1);
        return dateArray; 
	}
}