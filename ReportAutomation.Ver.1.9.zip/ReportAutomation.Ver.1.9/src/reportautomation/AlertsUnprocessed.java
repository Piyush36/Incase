package reportautomation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AlertsUnprocessed
{
	public static void main(String[] args)
	{
		new AlertsUnprocessed().checkAlerts();
	}

	public void checkAlerts()
	{
		Connection connection = null;
		Statement stmt = null;
		Statement stmt2 = null;
		ResultSet resultSet = null;
		ResultSet resultSet2 = null;
		String emailBodyPart = null;
		int count=0;
		try
		{
			connection = GetConnection.getConnection();
			List<String> timeGMT = new ArrayList<String>();
			timeGMT = getDateForQuery();
			stmt = connection.createStatement();
			stmt2 = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesForFrequentAdHoc.alertsTodayBefore_1_Hr(timeGMT.get(0), timeGMT.get(1)));
			String Query = QueriesForFrequentAdHoc.alertsTodayBefore_1_Hr(timeGMT.get(0), timeGMT.get(1));
			resultSet2 = stmt2.executeQuery(QueriesForFrequentAdHoc.totalAlertCountType);
			//System.out.println("Query is \n" + Query);
			
			if (resultSet.isBeforeFirst()==false)
				{
						System.out.println("No result found");
				}
			else
			{
				while(resultSet.next())
				{
					//System.out.println(resultSet.getString(7));
					count++;
				}
				while(resultSet2.next())
				{
					//System.out.println(resultSet2.getString(1));
					emailBodyPart ="<table><tr><td>STV alerts - </td><td>:</td><td>"+resultSet2.getString(15)+
					"</td></tr><tr><td>COA alerts 	- </td><td>:</td><td>"+resultSet2.getString(2)+
					"</td></tr><tr><td>RFD alerts 	- </td><td>:</td><td>"+resultSet2.getString(3)+
					"</td></tr><tr><td>CIS alerts 	- </td><td>:</td><td>"+resultSet2.getString(4)+
					"</td></tr><tr><td>ASE alerts 	- </td><td>:</td><td>"+resultSet2.getString(5)+
					"</td></tr><tr><td>APC alerts 	- </td><td>:</td><td>"+resultSet2.getString(6)+
					"</td></tr><tr><td>MCA alerts 	- </td><td>:</td><td>"+resultSet2.getString(7)+
					"</td></tr><tr><td>CES alerts 	- </td><td>:</td><td>"+resultSet2.getString(8)+
					"</td></tr><tr><td>PID alerts 	- </td><td>:</td><td>"+resultSet2.getString(9)+
					"</td></tr><tr><td>INC alerts 	- </td><td>:</td><td>"+resultSet2.getString(10)+
					"</td></tr><tr><td>MAC alerts 	- </td><td>:</td><td>"+resultSet2.getString(11)+
					"</td></tr><tr><td>SID alerts 	- </td><td>:</td><td>"+resultSet2.getString(12)+
					"</td></tr><tr><td>CAE alerts 	- </td><td>:</td><td>"+resultSet2.getString(13)+
					"</td></tr><tr><td>ISS alerts 	- </td><td>:</td><td>"+resultSet2.getString(14)+
					"</td></tr><tr><td><h4>Total</h4> alerts as of now </td><td>:</td><td>"+resultSet2.getString(1)+"</td></tr></table>";
				}
				String[] strToList = {"ctsd.gdoasis@bnymellon.com"};        //ctsd.gdoasis@bnymellon.com
				String[] strCCList = {"abhikumar@inautix.co.in"};
				String strEmailSubject = count +" alerts unprocessed for today since an hour.";
			    String strEmailBody = "Hi,<br><br> \n " +
										"Please run below query for more details <br><br>" + Query+		//Static part of email body    
										"<br><br><u><h3>Detailed Stats</h3></u><br>"+emailBodyPart;
										
			    new SendingMailUtility().sendMail(strEmailSubject, strEmailBody, strToList, strCCList);
			}
			
			
		}
		catch (SQLException e1) 
		{
			e1.printStackTrace();
		} 
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}

	private List<String> getDateForQuery() 
	{
		String less1GMT = null;
		String todayDate = null;
		List<String> listofDays = new ArrayList<String>();
		DateFormat dateWithTime = new SimpleDateFormat ("dd MMM yyyy hh:mm:ss a");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE,-330);  									//Selecting
        less1GMT = dateWithTime.format(cal.getTime());
        
        DateFormat dateOnly = new SimpleDateFormat ("dd MMM yyyy");
        Calendar cal0 = Calendar.getInstance();
        cal0.add(Calendar.DATE,0);
        todayDate = dateOnly.format(cal0.getTime());
        
        
        listofDays.add(todayDate);		//at index 0
        listofDays.add(less1GMT);		//at index 1
        
        return listofDays; 
	}
}