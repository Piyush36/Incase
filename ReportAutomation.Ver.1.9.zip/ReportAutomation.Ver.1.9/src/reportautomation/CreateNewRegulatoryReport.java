package reportautomation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CreateNewRegulatoryReport 
{


	public static void main(String[] arg)
	{
		new CreateNewRegulatoryReport().createReport();
	}
	
	public void createReport()
	{
		int rowid = 0;
		XSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			XSSFWorkbook workbook = new XSSFWorkbook();
		    XSSFSheet sheet = workbook.createSheet("CASS");
		    
		    connection = GetConnectionDev.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.regulatoryReportQuery);
			System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createRegulatoryHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
		    
		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    XSSFCell cell = row.createCell(icell++);
			    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        XSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		        XSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
	            style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(XSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(XSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
	            
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    XSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
            style.setBorderTop(XSSFCellStyle.BORDER_THIN);
            style.setBorderRight(XSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
		    	XSSFCell cell1 = row.createCell(0);
		    	cell1.setCellValue(resultSet.getString(1));							//ISIN
		    	cell1.setCellStyle(style);
		    	
		    	XSSFCell cell2 = row.createCell(1);
		    	cell2.setCellValue(resultSet.getString(2));							//IPA Status
		    	cell2.setCellStyle(style);
		    	
		    	XSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));							//GDO Status
		    	cell3.setCellStyle(style);
		    	
		    	XSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));							//IPA Flag
		    	cell4.setCellStyle(style);
		    	
		    	//System.out.println(resultSet.getObject(5));							//Issuance Date				
		    	XSSFCell cell5 = row.createCell(4);
		    	if(resultSet.getObject(5) != null)
		    	{
		    		cell5.setCellValue(resultSet.getObject(5).toString());
		    	}
		    	else
		    	{
		    		cell5.setCellValue("");
		    	}
		    	cell5.setCellStyle(style);
		    	
		    	//System.out.println(resultSet.getObject(6));							//Maturity Date					
		    	XSSFCell cell6 = row.createCell(5);
		    	if(resultSet.getObject(6) != null)
		    	{
		    		cell6.setCellValue(resultSet.getObject(6).toString());
		    	}
		    	else
		    	{
		    		cell6.setCellValue("");
		    	}
		    	cell6.setCellStyle(style);
		    	
		    	XSSFCell cell7 = row.createCell(6);
		    	cell7.setCellValue(resultSet.getString(7));							//Global Note Location
		    	cell7.setCellStyle(style);
		    }
		    for(int columnIndex = 0; columnIndex < 7; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    
		    String reportDay = getDateString();
		    String reportPath = "C:/Reports/Weekly Reports/New Regulatory Report/GDO_regulatory_ " + reportDay + ".xlsx";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		    System.out.println("NewRegulatoryReport Report is created successfully!");
		    
		    // Moving file to the network Location
		    //ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		    //Sending mail to the client
		    //new SendingMailForAllIssueReport().sendMail();
		    
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		catch (Exception e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getDateString() 
	{
		String strDate = null;
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        strDate = dateFormat.format(cal.getTime());
        return strDate;
        
	}
}