package reportautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailForNoOfISINProcessed 
{


	public static void main(String[] args) 
	{
		//new SendingMailForNoOfISINProcessed().sendMail("", "", "");
	}
	public void sendMail(String fromDate, String toDate, String fileName, String strFrequency)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		MimeBodyPart messageBodyPart1;
		FileDataSource DFS;
		Multipart multipart;
		String emailBody = null;
		String emailSubject = null;
		String from;
		String emailPort;
		String emailHost;
		String reportDay;
		String strLocationLink;
		try
		{
			strLocationLink = "file://whexpfseur11/corptrustpoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/X40347222-Number of ISIN's processed";
			reportDay = getTodayDate();
			emailPort = "25";//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

			//String[] toEmails = {"ltyagi@inautix.co.in"};  								//ditdatareconciliation@bnymellon.com
			//String[] ccEmails = {"ltyagi@inautix.co.in"};								//ctsd.gdoasis@bnymellon.com
			String[] toEmails = {"ITSAmendments@BNYMellon.com"};
			String[] ccEmails = {"ctsd.gdoasis@bnymellon.com", "jonathan.burns@bnymellon.com", "Michelle.Payne@bnymellon.com", "thomas.bolton@bnymellon.com","garry.rendell@bnymellon.com"};	
			from = "ctsd.gdoasis@bnymellon.com";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();
			messageBodyPart1 = new MimeBodyPart();
			DFS	= new FileDataSource(fileName);

			multipart = new MimeMultipart();
			
			if(strFrequency != null && strFrequency.equals("Weekly"))
			{
				emailSubject = "Number of ISINs processed - " + fromDate + " - " + toDate;
				emailBody = "Good Morning,<br> \n " +
				"<br>\n" +
				"Please find attached the number of ISINs processed report for previous week. The report is also available at this " +
				"<a href=\"" + strLocationLink + "\">path.</a>" +
				"\n<br><br><br><br>" +
				"Regards \n" +
				"TEAM CTSD GDO \n" +
				
				"ctsd.gdoasis@bnymellon.com ";
			}
			else if(strFrequency != null && strFrequency.equals("Monthly"))
			{
				emailSubject = "Number of ISINs processed - " + fromDate + " " + toDate;
				emailBody = "Good Morning,<br> \n " +
				"<br>\n" +
				"Please find attached the number of ISINs processed report for previous month. The report is also available at this " +
				"<a href=\"" + strLocationLink + "\">path.</a>" +
				"\n<br><br><br><br>" +
				"<br>Kind regards," +
				"<br>Pulkit Arya" +
				"<br>Application Service Delivery" +
				"<br>BNY Mellon Technology" +
				"<br>Client Technology Solutions : Corporate Trust Technology" +
				"<br>Tel : +1 646 782 0456 ";
			}
			String message = "<html>" +
					"<body>" +
					"Click <a href=\"" + strLocationLink + "\">here</a> to activate your free subscription." +
					"</body>" +
					"</html>";

			emailMessage.setSubject(emailSubject);
			//emailMessage.setText(emailBody, "text/html");
			//emailMessage.setContent(emailBody, "text/html");
			
			messageBodyPart.setText(emailBody, "UTF-8", "html");
			//messageBodyPart.setText(emailBody);
			//messageBodyPart.setContent(emailBody, "text/html");
			messageBodyPart1.setDataHandler(new DataHandler(DFS));
			messageBodyPart1.setFileName(DFS.getName());
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(messageBodyPart1);
			emailMessage.setContent(multipart);
			
			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			Transport.send(emailMessage);

			System.out.println("Email sent successfully.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}

	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}

}
