package reportautomation;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class GetConnection
{
	private static String strUserName = null;
	private static String strPassword = null;
	
	public static Connection getConnection()
	{
		// To make a connection first we need driver loaded in, User name password and URL according to the database
		// For Oracle
		//String strDriver = "oracle.jdbc.driver.OracleDriver";
		String strDriver = "com.sybase.jdbc3.jdbc.SybDriver";
		String strURL = "jdbc:sybase:Tds:xsd0pa27:3025/sdoasgdo";
		//For Oracle
		//String strURL = "jdbc:oracle:thin:@localhost:1521:sid";
		Connection connection = null;
		Scanner scanner = null;
		try
		{
			init();
			Class.forName(strDriver);
			System.out.println("Driver Loaded");	
			/*System.out.println("Please Enter the DataBase User Name");
			strUserName = scanner.nextLine();
			System.out.println("Please Enter the DataBase User Password");
			strPassword = scanner.nextLine();*/
			//System.out.println(strUserName+" "+strPassword );
			connection = DriverManager.getConnection(strURL,strUserName,strPassword);
			System.out.println("Connection Established");
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		} 
		catch(ClassNotFoundException ex)
		{
			ex.printStackTrace();
		} 
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return connection;
	}
	
	private static void init(){
		Properties prop = new Properties();
		InputStream input = null;
		try{
			input = GetConnection.class.getClassLoader().getResourceAsStream("config.properties");
			prop.load(input);
			
			strUserName = prop.getProperty("UserName");
			strPassword = prop.getProperty("Password");
			//System.out.println(strUserName+" "+strPassword );
			System.out.println("Values are loaded successfully from property file - config.properties");
		}
		catch(IOException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public ResultSet getData(String query)
	{
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			connection = getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(query);
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		} 
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally
		{
			try 
			{
				if(stmt != null)
				stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
		return resultSet;
	}
}
