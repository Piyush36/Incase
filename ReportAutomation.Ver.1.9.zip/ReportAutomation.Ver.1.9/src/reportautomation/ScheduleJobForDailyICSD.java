package reportautomation;
import com.ICSDReport.CreateReportICSD;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobForDailyICSD implements Job
{
	public void execute(JobExecutionContext context) throws JobExecutionException 
	{
		CreateReportICSD getReportICSD = new CreateReportICSD();
		getReportICSD.ICSDReport();
	}

}
