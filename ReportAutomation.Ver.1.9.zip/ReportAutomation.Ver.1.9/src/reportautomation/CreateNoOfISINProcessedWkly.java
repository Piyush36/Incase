package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.util.TreeSet;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;

public class CreateNoOfISINProcessedWkly 
{

	public static void main(String[] arg)
	{
		CreateNoOfISINProcessedWkly createNoOfISINs = new CreateNoOfISINProcessedWkly();
		createNoOfISINs.triggerCreateReport();
	}

	public void triggerCreateReport()
	{	
		String reportDay = this.getDayForReport();
		if(reportDay != null && reportDay.equals("Monday"))
		{
			//System.out.println("day is : " + reportDay + "  Calling the method createReport");
			this.createReport();

		}
	}

	public void createReport()
	{
		int rowid = 0;
		int rowid1 = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		List<String> reportDay = new ArrayList<String>();
		reportDay = getDateStringMap();
		File directory = null;
		Set<String> userSet = new TreeSet<String>();
		List<String> oasisProcessed = new ArrayList<String>();
		List<String> oasisVerified = new ArrayList<String>();
		List<String> manualProcessed = new ArrayList<String>();
		List<String> manualVerified = new ArrayList<String>();
		Map<String, Integer> oasisProcessedMap = new HashMap<String, Integer>();
		Map<String, Integer> oasisVerifiedMap = new HashMap<String, Integer>();
		Map<String, Integer> manualProcessedMap = new HashMap<String, Integer>();
		Map<String, Integer> manualVerifiedMap = new HashMap<String, Integer>();
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
			connection = GetConnection.getConnection();

			// Below code will create a TAB named AUTO
			HSSFSheet sheet = workbook.createSheet("AUTO");
			System.out.println("Report will be created for the date range from  " + reportDay.get(0) + " to " + reportDay.get(1));
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(GetQueryForWklyISINProcessed.getQueryForOASISISINProcessed(reportDay.get(0), reportDay.get(1)));
			System.out.println("ResultSet is prepared for AUTO");
			int key = 1;
			int icell = 0;
			hMap = hValues.createISINProcessedHeader();
			row = sheet.createRow(rowid);
			Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
			while(itr.hasNext())
			{
				Entry<Integer, String> entry = itr.next();

				HSSFCell cell = row.createCell(icell++);
				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				cell.setCellValue(hMap.get(key++));            
				HSSFCellStyle style = workbook.createCellStyle();
				style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				HSSFFont arialBoldFont = workbook.createFont();
				arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				arialBoldFont.setFontName("Calibri");
				arialBoldFont.setFontHeightInPoints((short) 11);
				style.setFont(arialBoldFont);
				style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
				style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				style.setBorderTop(HSSFCellStyle.BORDER_THIN);
				style.setBorderRight(HSSFCellStyle.BORDER_THIN);
				style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				cell.setCellStyle(style);
			}
			System.out.println("Header Created Successfully for AUTO");

			HSSFCellStyle style = workbook.createCellStyle();
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			while(resultSet.next())
			{
				row = sheet.createRow(++rowid);
				String strOasisProcessed;
				String strOasisVerified;

				HSSFCell cell1 = row.createCell(0);
				cell1.setCellValue(resultSet.getString(1));								//ISIN
				cell1.setCellStyle(style);

				HSSFCell cell2 = row.createCell(1);
				cell2.setCellValue(resultSet.getString(2));								//ISSUE NAME
				cell2.setCellStyle(style);
				
				strOasisProcessed = resultSet.getString(3);
				HSSFCell cell3 = row.createCell(2);
				cell3.setCellValue(strOasisProcessed);									//PROCCESSED BY
				cell3.setCellStyle(style);
				userSet.add(strOasisProcessed);
				oasisProcessed.add(strOasisProcessed);
				
				strOasisVerified = resultSet.getString(4);
				HSSFCell cell4 = row.createCell(3);
				cell4.setCellValue(strOasisVerified);									//VERIFIED USER
				cell4.setCellStyle(style);
				userSet.add(strOasisVerified);
				oasisVerified.add(strOasisVerified);
			}
			
			// Creating Map to get the count of users
			for(String value : oasisProcessed)
			{
				Integer iOasisProcessed = oasisProcessedMap.get(value);
				oasisProcessedMap.put(value, (iOasisProcessed == null) ? 1 : iOasisProcessed + 1);
			}
			
			for(String value : oasisVerified)
			{
				Integer iOasisVerified = oasisVerifiedMap.get(value);
				oasisVerifiedMap.put(value, (iOasisVerified == null) ? 1 : iOasisVerified + 1);
			}
			for(int columnIndex = 0; columnIndex < 4; columnIndex++) 
			{
				sheet.autoSizeColumn(columnIndex);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
				if(stmt != null)
					stmt.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			finally
			{
				hMap = null;
			}

			//Below code creates a TAB named MANUAL
			HSSFSheet sheet1 = workbook.createSheet("MANUAL");
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(GetQueryForWklyISINProcessed.getQueryForMANUALISINProcessed(reportDay.get(0), reportDay.get(1)));
			System.out.println("ResultSet is prepared for MANUAL");
			int key1 = 1;
			int icell1 = 0;
			hMap = hValues.createISINProcessedHeader();
			row = sheet1.createRow(rowid1);
			Iterator<Entry<Integer, String>> itr1 = hMap.entrySet().iterator();
			while(itr1.hasNext())
			{
				Entry<Integer, String> entry = itr1.next();

				HSSFCell cell = row.createCell(icell1++);
				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				cell.setCellValue(hMap.get(key1++));            
				HSSFCellStyle style1 = workbook.createCellStyle();
				style1.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				HSSFFont arialBoldFont = workbook.createFont();
				arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				arialBoldFont.setFontName("Calibri");
				arialBoldFont.setFontHeightInPoints((short) 11);
				style1.setFont(arialBoldFont);
				style1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				style1.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
				style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
				style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
				style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				cell.setCellStyle(style1);
			}
			System.out.println("Header Created Successfully for MANUAL");

			/* HSSFCellStyle style1 = workbook.createCellStyle();
	    	style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);*/
			while(resultSet.next())
			{
				row = sheet1.createRow(++rowid1);
				String strManualProcessed;
				String strManualVerified;

				HSSFCell cell1 = row.createCell(0);
				cell1.setCellValue(resultSet.getString(1));								//ISIN
				cell1.setCellStyle(style);

				HSSFCell cell2 = row.createCell(1);
				cell2.setCellValue(resultSet.getString(2));								//ISSUE NAME
				cell2.setCellStyle(style);

				strManualProcessed = resultSet.getString(3);
				HSSFCell cell3 = row.createCell(2);
				cell3.setCellValue(strManualProcessed);									//PROCCESSED BY
				cell3.setCellStyle(style);
				userSet.add(strManualProcessed);
				manualProcessed.add(strManualProcessed);
				
				strManualVerified = resultSet.getString(4);
				HSSFCell cell4 = row.createCell(3);
				cell4.setCellValue(strManualVerified);									//VERIFIED USER
				cell4.setCellStyle(style);
				userSet.add(strManualVerified);
				manualVerified.add(strManualVerified);

			}
			
			// Creating Map to get the count of distinct users
			for(String value : manualProcessed)
			{
				Integer iManualProcessed = manualProcessedMap.get(value);
				manualProcessedMap.put(value, (iManualProcessed == null) ? 1 : iManualProcessed + 1);
			}
			
			for(String value : manualVerified)
			{
				Integer iManualVerified = manualVerifiedMap.get(value);
				manualVerifiedMap.put(value, (iManualVerified == null) ? 1 : iManualVerified + 1);
			}
			
			for(int columnIndex = 0; columnIndex < 4; columnIndex++) 
			{
				sheet1.autoSizeColumn(columnIndex);
			}
			try
			{
				if(resultSet != null)
					resultSet.close();
				if(stmt != null)
					stmt.close();
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			}
			finally
			{
				hMap = null;
			}
			
			//Below code will create a TAB named COUNT
			HSSFSheet sheet2 = workbook.createSheet("COUNT");
			HSSFRow row1 = sheet2.createRow(0);
			{
				HSSFCellStyle styleCount = workbook.createCellStyle();
				styleCount.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				styleCount.setBorderTop(HSSFCellStyle.BORDER_THIN);
				styleCount.setBorderRight(HSSFCellStyle.BORDER_THIN);
				styleCount.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				styleCount.setAlignment(styleCount.ALIGN_CENTER);
				
				HSSFCell cell = row1.createCell(0);
				cell.setCellValue("");								
				cell.setCellStyle(styleCount);
				
				//CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 0, 1, 2);
				
				HSSFCell cell1 = row1.createCell(1);
				cell1.setCellValue("OASIS QUEUE");								
				cell1.setCellStyle(styleCount);

				HSSFCell cell2 = row1.createCell(2);
				cell2.setCellValue("");								
				cell2.setCellStyle(styleCount);

				HSSFCell cell3 = row1.createCell(3);
				cell3.setCellValue("MANUAL PAYMENTS");								
				cell3.setCellStyle(styleCount);

				HSSFCell cell4 = row1.createCell(4);
				cell4.setCellValue("");								
				cell4.setCellStyle(styleCount);
				
				@SuppressWarnings("deprecation")
				CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 0, 1, 2);
				sheet2.addMergedRegion(cellRangeAddress);
				
				@SuppressWarnings("deprecation")
				CellRangeAddress cellRangeAddress1 = new CellRangeAddress(0, 0, 3, 4);
				sheet2.addMergedRegion(cellRangeAddress1);
			}


			/*HSSFRow row2 = sheet2.createRow(1);
			{
				HSSFCell cell1 = row2.createCell(0);
				cell1.setCellValue("");								
				cell1.setCellStyle(style);

				HSSFCell cell2 = row2.createCell(1);
				cell2.setCellValue("Processed By");								
				cell2.setCellStyle(style);

				HSSFCell cell3 = row2.createCell(2);
				cell3.setCellValue("Verified By");								
				cell3.setCellStyle(style);

				HSSFCell cell4 = row2.createCell(3);
				cell4.setCellValue("Processed By");								
				cell4.setCellStyle(style);

				HSSFCell cell5 = row2.createCell(4);
				cell5.setCellValue("Verified By");								
				cell5.setCellStyle(style);
			}*/
			
			int key2 = 1;
			int icell2 = 1;
			
			HSSFRow row2 = sheet2.createRow(1);
			HSSFCell cell1 = row2.createCell(0);
			cell1.setCellValue("");								
			cell1.setCellStyle(style);
			
			hMap = hValues.createISINProcessedHeaderCount();
			Iterator<Entry<Integer, String>> itr2 = hMap.entrySet().iterator();
			while(itr2.hasNext())
			{
				Entry<Integer, String> entry = itr2.next();

				HSSFCell cell = row2.createCell(icell2++);
				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				cell.setCellValue(hMap.get(key2++));            
				HSSFCellStyle style1 = workbook.createCellStyle();
				style1.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				HSSFFont arialBoldFont = workbook.createFont();
				arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				arialBoldFont.setFontName("Calibri");
				arialBoldFont.setFontHeightInPoints((short) 11);
				style1.setFont(arialBoldFont);
				style1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				style1.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
				style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
				style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
				style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				cell.setCellStyle(style1);
			}
			System.out.println("Header Created Successfully for COUNT");
			
			int rowid2 = 1;
			for(String value : userSet)
			{
				int icell3 = 0;
				row = sheet2.createRow(++rowid2);
				
				HSSFCell cell2 = row.createCell(icell3++);
				cell2.setCellValue(value);								
				cell2.setCellStyle(style);
				
				HSSFCell cell3 = row.createCell(icell3++);
				cell3.setCellValue((oasisProcessedMap.get(value) == null) ? 0 : oasisProcessedMap.get(value));								
				cell3.setCellStyle(style);
				
				HSSFCell cell4 = row.createCell(icell3++);
				cell4.setCellValue((oasisVerifiedMap.get(value) == null) ? 0 : oasisVerifiedMap.get(value));								
				cell4.setCellStyle(style);
				
				HSSFCell cell5 = row.createCell(icell3++);
				cell5.setCellValue((manualProcessedMap.get(value) == null) ? 0 : manualProcessedMap.get(value));								
				cell5.setCellStyle(style);
				
				HSSFCell cell6 = row.createCell(icell3++);
				cell6.setCellValue((manualVerifiedMap.get(value) == null) ? 0 : manualVerifiedMap.get(value));								
				cell6.setCellStyle(style);
				
				
			}
			
			for(int columnIndex = 0; columnIndex < 5; columnIndex++) 
			{
				sheet2.autoSizeColumn(columnIndex);
			}
			
			// This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/Weekly Reports/Number of ISIN's processed/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("Directory C:/Data/Report Automation/Reports/Weekly Reports/X40347222-Number of ISIN's processed/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");

			String reportSrcPath = directory.toString() + "/X40347222-Number of ISIN's processed " + reportDay.get(0).substring(0, 6) + " - " + reportDay.get(1) + ".xls";
			String reportDestPath = "//whexpfseur11/corptrustpoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/X40347222-Number of ISIN's processed/X40347222-Number of ISIN's processed " + reportDay.get(0).substring(0, 6) + " - " + reportDay.get(1) + ".xls";
			FileOutputStream fileOut = new FileOutputStream(reportSrcPath);
			workbook.write(fileOut);
			fileOut.close();
			System.out.println("NumberOfISIN'sProcessed Report is created successfully for Monday to Sunday !");
			
			// Moving file to the network Location
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		    //Sending mail to the client
		    new SendingMailForNoOfISINProcessed().sendMail(reportDay.get(0), reportDay.get(1), reportSrcPath, "Weekly");
		}
		catch (SQLException e1) 
		{
			e1.printStackTrace();
		} 
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		finally
		{
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}

	private List<String> getDateStringMap() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("dd MMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		System.out.println("Day is : " + dayValue);
		if(dayValue != null && dayValue.equals("Monday"))
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -7);
			strDate = dateFormat1.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, +6);
			strDate = dateFormat1.format(cal.getTime());
			listofDays.add(strDate);
		}
		return listofDays;
	}

	private String getDayForReport() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);
		
		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);

		return dayValue;
	}
}