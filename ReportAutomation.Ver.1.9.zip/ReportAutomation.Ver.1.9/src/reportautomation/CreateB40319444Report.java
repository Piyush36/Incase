package reportautomation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CreateB40319444Report {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new CreateB40319444Report().createReport();
	}

	public void createReport() {
		File directory = null;
		String strEmailSubject = null;
		String strEmailBody = null;
		try {
			// This piece of code will be creating the directory to save the
			// reports
			directory = new File(
					"C:/Data/Report Automation/Reports/Monthly/B40319444 Reports/");
			if (!directory.exists()) {
				if (directory.mkdirs())
					System.out
							.println("C:/Data/Report Automation/Reports/Monthly/B40319444 Reports/ is created");
				else
					System.out.println("Failed to create source directory!");
			} else
				System.out.println("source directory already exist");

			// String reportDay = getTodayDate();
			// String reportSrcPath = directory.toString() + "/B40319444_" +
			// reportDay + ".xls";

			// CreateXLSUtility.createXLS(QueriesConstantMonthly.strB40319444,
			// "Sheet1", reportSrcPath);
			System.out.println("B40319444 Report is created successfully!");

			String[] strToList = {}; // abhikumar@inautix.co.in
			String[] strCCList = { "abhikumar@inautix.co.in" };

			strEmailSubject = "Documents request";
			strEmailBody = "Hi,<br><br> \n " + "Please find the attached Docs "; // Static
																					// part
																					// of
																					// email
																					// body
			// "<a href='file:" + directory + "'> here.</a> <br>\n";
			// Below method is responsible to send the mail. Client do not need
			// mail hence commented.
			// System.out.println("Code Runs till this point");
			// new SendingMailUtility().sendMail(strEmailSubject, strEmailBody,
			// strToList, strCCList);

			String strfile = "C:/Data/Report Automation/Reports/Monthly/B40319444 Reports/FileName.ext";
			new SendingMailWithAttachmentUtility().sendMail(strfile,
					strEmailSubject, strEmailBody, strToList, strCCList);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private String getTodayDate() {
		String strDate = null;

		// DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		return strDate;
	}
}