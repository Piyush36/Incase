package reportautomation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CreateMailForHC {
StringBuilder sb=new StringBuilder();
	public static void main(String Args[])
	{
		new CreateMailForHC().createMail();
		
		
		
		System.out.println("Mail for HC Sent");
	}

	void createMail() {
		// TODO Auto-generated method stub
		Connection connection = null;
		Statement stmt = null;
		Statement stmt1 = null;
		ResultSet resultSet_for_Nettings_Processed = null;
		ResultSet resultSet_for_Nettings_Processed1 = null;
		ResultSet Nettings_flag1 = null;
		ResultSet Nettings_flag2 = null;
		ResultSet S3D_Check_Processed=null;
		ResultSet S3D_Check_Unprocessed=null;
		ResultSet S4D_Check_Processed=null;
		ResultSet S4D_Check_Unprocessed=null;
		
		
		SendingMailForHC obj_to_mail=new SendingMailForHC();
		try{
			connection=GetConnection.getConnection();
			stmt=connection.createStatement();
			stmt1=connection.createStatement();
			//1stCheck
			System.out.println("Query is : " + QueriesConstant.Nettings_Processed_Query);
			resultSet_for_Nettings_Processed = stmt.executeQuery(QueriesConstant.Nettings_Processed_Query);
		    System.out.println("ResultSet for Nettings_Processed_Query is prepared");
		    sb.append("<br> 1) Nettings Processed Check\n : ");
		    
		    resultSet_for_Nettings_Processed1 = stmt1.executeQuery(QueriesConstant.Nettings_Processed_Query1);
		    resultSet_for_Nettings_Processed1.next();
		    resultSet_for_Nettings_Processed.next();
		    System.out.println("ResultSet for Nettings_Processed_Query1 is prepared");
		   
		    if(resultSet_for_Nettings_Processed1.getInt(1)>0)
		    {
		    	sb.append("<span style=\"color:red\">Unsuccessful<br></span>");
		    }
		    else
		    {
		    	sb.append("<span style=\"color:green\">Successful<br></span>");
		    }
		 /*   ResultSetMetaData rsmd = resultSet_for_Nettings_Processed.getMetaData();
		    int columnsNumber =rsmd.getColumnCount();
		    //printdata(resultSet_for_Nettings_Processed, columnsNumber, rsmd);
		    */
		    sb.append("Incoming Nettings: "+resultSet_for_Nettings_Processed.getString(1)+" ");
		    sb.append("Unprocessed: "+resultSet_for_Nettings_Processed1.getString(1)+"<br>");

		    //2ndCheck
		    
		
		    
		    
	
//		    sb.append("<br>3)Job Z5D Check :");
//		    System.out.println("Query is: Z5D Check");
//		    Z5D_Check=stmt.executeQuery(QueriesConstant.Z5D_Check);
//		    Z5D_Check.next();
//		    if(Z5D_Check.getInt(1)>0)
//		    {
//		    	sb.append("<span style=\"color:red\">Unsuccessful </span><br>");
//		    }
//		    else
//		    	{sb.append("<span style=\"color:green\">Successful</span><br>");
//		    	
//		    	}
//		    sb.append("Unprocessed :"+Z5D_Check.getString(1)+"<br>");
		
		    //S3D Check 
		   sb.append("<br>2)S3D Check:");
		   System.out.println("Running Query for S3D Check");
		   S3D_Check_Processed=stmt.executeQuery(QueriesConstant.S3D_Check_Processed);
		   S3D_Check_Processed.next();
		   S3D_Check_Unprocessed=stmt1.executeQuery(QueriesConstant.S3D_Check_Unprocessed);
		   S3D_Check_Unprocessed.next();
		   if(S3D_Check_Unprocessed.getInt(1)>0)
		    {
		    	sb.append("<span style=\"color:red\">Unsuccessful </span><br>");
		    }
		    else
		    	{sb.append("<span style=\"color:green\">Successful</span><br>");
		    	
		    	}
		   sb.append("Processed:"+S3D_Check_Processed.getString(1)+" Unprocessed:"+S3D_Check_Unprocessed.getString(1)+"<br>");
		  //S4D Check
		   sb.append("<br>3)S4D Check:");
		   System.out.println("Running Query for S4D Check");
		   S4D_Check_Processed=stmt.executeQuery(QueriesConstant.S4D_Check_Processed);
		   S4D_Check_Processed.next();
		   S4D_Check_Unprocessed=stmt1.executeQuery(QueriesConstant.S4D_Check_Unprocessed);
		   S4D_Check_Unprocessed.next();
		   if(S4D_Check_Unprocessed.getInt(1)>0)
		    {
		    	sb.append("<span style=\"color:red\">Unsuccessful </span><br>");
		    }
		    else
		    	{sb.append("<span style=\"color:green\">Successful</span><br>");
		    	
		    	}
		   sb.append("Processed:"+S4D_Check_Processed.getString(1)+"Unprocessed:"+S4D_Check_Unprocessed.getString(1)+"<br>");
		   
		   sb.append("<br>4)S5D Check :");
		   
		   
		    System.out.println("Query is : " + QueriesConstant.Nettings_flag1);
		    Nettings_flag1 = stmt.executeQuery(QueriesConstant.Nettings_flag1);
		    Nettings_flag2 = stmt1.executeQuery(QueriesConstant.Nettings_flag2);
		 
		  
		  
		    
		    String N="N";
		    String S="S";
		    int flagCheck =0;
		    String[] NettingFlags= new String[8];
		    int i=0;
		    while(Nettings_flag1.next())
		    {
		    	NettingFlags[i]=Nettings_flag1.getString(1);
		    	System.out.println("Nettings Flag 1 i :"+i+" String "+Nettings_flag1.getString(1));
		    	i++;
		    }
		    while(Nettings_flag2.next())
		    {
		    	NettingFlags[i]=Nettings_flag2.getString(1);
		     	System.out.println("Nettings Flag 2 i :"+i+" String :"+ Nettings_flag2.getString(1));
		    	i++;
		    }
		    //8 is used here because total number of rows in two queries is 2+6=8
		   
		    
		    for(i=0;i<8;++i)
		    {
		    	System.out.println("Checking in the String");
		    	if(!N.equalsIgnoreCase(NettingFlags[i]))
		    	{
		    		System.out.println("Flag Set Failed"+i);
		    	flagCheck=1;
		    	}
		    	
		    }
		    System.out.println("i should be 8-i:"+i);
		    if(i==8&&flagCheck==0)
		    {
		    	sb.append("<span style=\"color:green\">Successful</span><br>");
		    }
		    else
		    { System.out.println("i:"+i);
		    	sb.append("<span style=\"color:red\">Unsuccessful</span><br>");
		    }
		    sb.append("<span style=\"color:white\">");
		    for( i=0;i<NettingFlags.length;i++)
		    {	System.out.println("Netting Array Length: "+NettingFlags.length);
		   sb.append(NettingFlags[i]);
		  
		    System.out.println("Appending:"+NettingFlags[i]);
		    }
		    
		    sb.append("</span>");
		    
		   
		   
		  resultSet_for_Nettings_Processed.close();
			 resultSet_for_Nettings_Processed1.close();
			 Nettings_flag1.close();
			 Nettings_flag2.close();
			 //stmt.close();
			   stmt1.close();
			 S3D_Check_Processed.close();
			 S3D_Check_Unprocessed.close();
			 S4D_Check_Processed.close();
			 S4D_Check_Unprocessed.close();
		    obj_to_mail.sendMail(sb);
		}
		
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(stmt != null)
					stmt.close();
				
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
	}
		
	}
	 
}
