package reportautomation;

public class QueriesConstantWeekly 
{
	static String regIssuesReport = "DECLARE @bod_date DATETIME \n " +
			"SELECT @bod_date = DateAdd(day, -1, getdate()) \n " +
			" \n " +
			"DECLARE @eod_date DATETIME \n " +
			"SELECT @eod_date = DateAdd(day, -8, getdate()) \n " +
			" \n " +
			"select  \n " +
			"    convert(varchar,TR.isin) as 'ISIN',  \n " +
			"    convert(varchar,TR.issue_name) as 'Security Description',  \n " +
			"    convert(numeric,(isNull(TCH1.holding_amt,0)+isNull(TCH1.temp_balance,0)+isNull(TCH2.holding_amt,0)+isNull(TCH2.temp_balance,0))) as 'Current Amount', \n " +
			"    convert(numeric,((isNull(TCH1.holding_amt,0)+isNull(TCH1.temp_balance,0)+isNull(TCH2.holding_amt,0)+isNull(TCH2.temp_balance,0))- (isNull(TCH3.holding_amt,0)+isNull(TCH3.temp_balance,0)+isNull(TCH4.holding_amt,0)+isNull(TCH4.temp_balance,0)))) as 'Nominal Change', \n " +
			"    '' as 'Transaction Reason', \n " +
			"    (select party_name from contact CON where CON.contact_id=APP.csk_code and TR.note_type='Y') as 'CSK' \n " +
			"from  \n " +
			"    v_tranche TR,  \n " +
			"    au_tranche_clearer_holding TCH1,  \n " +
			"    au_tranche_clearer_holding TCH2,  \n " +
			"    au_tranche_clearer_holding TCH3,  \n " +
			"    au_tranche_clearer_holding TCH4,  \n " +
			"    gdoasis_appointments APP \n " +
			"where  \n " +
			"    TR.tranche_id *= TCH1.tranche_id \n " +
			"    and TR.tranche_id *= TCH2.tranche_id \n " +
			"    and TR.tranche_id *= TCH3.tranche_id \n " +
			"    and TR.tranche_id *= TCH4.tranche_id \n " +
			"    and TR.tranche_id = APP.tranche_id \n " +
			"    and TCH1.contact_id='782969415818120' \n " +
			"    and TCH2.contact_id='782969687257310' \n " +
			"    and TCH3.contact_id='782969415818120' \n " +
			"    and TCH4.contact_id='782969687257310' \n " +
			"    and convert(char(8), convert(datetime, TCH1.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @bod_date, 101), 112) \n " +
			"    and TCH1.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C1 noholdlock where C1.tranche_id = TCH1.tranche_id  \n " +
			"    and C1.contact_id =TCH1.contact_id and convert(char(8), convert(datetime, C1.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @bod_date, 101), 112)) \n " +
			"    and convert(char(8), convert(datetime, TCH2.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @bod_date, 101), 112) \n " +
			"    and TCH2.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C2 noholdlock where C2.tranche_id = TCH2.tranche_id  \n " +
			"    and C2.contact_id =TCH2.contact_id and convert(char(8), convert(datetime, C2.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @bod_date, 101), 112)) \n " +
			"    and convert(char(8), convert(datetime, TCH3.last_edit_date, 101), 112) <= convert(char(8), convert(datetime,@eod_date, 101), 112) \n " +
			"    and TCH3.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C1 noholdlock where C1.tranche_id = TCH3.tranche_id  \n " +
			"    and C1.contact_id =TCH3.contact_id and convert(char(8), convert(datetime, C1.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @eod_date, 101), 112)) \n " +
			"    and convert(char(8), convert(datetime, TCH4.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @eod_date, 101), 112) \n " +
			"    and TCH4.last_edit_date = (select max(last_edit_date) from au_tranche_clearer_holding C2 noholdlock where C2.tranche_id = TCH4.tranche_id  \n " +
			"    and C2.contact_id =TCH4.contact_id and convert(char(8), convert(datetime, C2.last_edit_date, 101), 112) <= convert(char(8), convert(datetime, @eod_date, 101), 112)) \n " +
			"    and TR.branch_code='CD' \n " +
			"    and TR.status_code='LI' \n " +
			"    and TR.issue_reg_type_code='Y' \n " +
			"    and TR.note_type='Y' \n " +
			"    and TR.bare_depo_flag in ('B','S') \n " +
			"    and ((isNull(TCH1.holding_amt,0)+isNull(TCH1.temp_balance,0)+isNull(TCH2.holding_amt,0)+isNull(TCH2.temp_balance,0)) - (isNull(TCH3.holding_amt,0)+isNull(TCH3.temp_balance,0)+isNull(TCH4.holding_amt,0)+isNull(TCH4.temp_balance,0))) != 0 ";

	
}
