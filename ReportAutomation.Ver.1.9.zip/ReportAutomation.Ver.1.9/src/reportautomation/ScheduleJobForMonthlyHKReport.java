package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobForMonthlyHKReport implements Job
{
	public void execute(JobExecutionContext context) throws JobExecutionException 
	{
		CreateMonthlyLive_Issue_HK_Report createLive_Issue_HK_Report = new CreateMonthlyLive_Issue_HK_Report();
		createLive_Issue_HK_Report.createReport();
	}

}
