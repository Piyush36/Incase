package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class CreateDailyEarlyMaturityReport
{
	public static void main(String[] args)
	{
		new CreateDailyEarlyMaturityReport().createReport();
	}

	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		File directory = null;
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet("Sheet1");

			connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.dailyEarlyMaturity);
			System.out.println("ResultSet is prepared");
			int key = 1;
			int icell = 0;
			hMap = hValues.createDailyEarlyMaturityHeader();
			row = sheet.createRow(rowid);
			Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();

			while(itr.hasNext())
			{
				Entry<Integer, String> entry = itr.next();

				HSSFCell cell = row.createCell(icell++);
				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				cell.setCellValue(hMap.get(key++));            
				HSSFCellStyle style = workbook.createCellStyle();
				style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				HSSFFont arialBoldFont = workbook.createFont();
				arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				arialBoldFont.setFontName("Calibri");
				arialBoldFont.setFontHeightInPoints((short) 11);
				style.setFont(arialBoldFont);
				style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
				style.setIndention((short) 0);
				style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				style.setBorderTop(HSSFCellStyle.BORDER_THIN);
				style.setBorderRight(HSSFCellStyle.BORDER_THIN);
				style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				cell.setCellStyle(style);
			}
			System.out.println("Header Created Successfully");

			HSSFCellStyle style = workbook.createCellStyle();
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			while(resultSet.next())
			{
				row = sheet.createRow(++rowid);

				HSSFCell cell1 = row.createCell(0);
				cell1.setCellValue(resultSet.getString(1));							//ISIN
				cell1.setCellStyle(style);

				HSSFCell cell2 = row.createCell(1);
				cell2.setCellValue(resultSet.getString(2));							//Issue Name
				cell2.setCellStyle(style);

				HSSFCell cell3 = row.createCell(2);
				cell3.setCellValue(resultSet.getString(3));							//ISSUE TYPE
				cell3.setCellStyle(style);

				HSSFCell cell4 = row.createCell(3);
				cell4.setCellValue(resultSet.getString(4));							//CURRENT STATUS
				cell4.setCellStyle(style);

				HSSFCell cell5 = row.createCell(4);
				cell5.setCellValue(resultSet.getString(5));							//CURRENT HOLDING
				cell5.setCellStyle(style);

				/* SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
		    	String maturityDate = dt.format(resultSet.getDate(6));
		    	String redeemedDate = dt.format(resultSet.getDate(7)); */

				HSSFCell cell6 = row.createCell(5);									//MATURITY DATE
				cell6.setCellValue(resultSet.getString(6));	
				cell6.setCellStyle(style);

				HSSFCell cell7 = row.createCell(6);									//REDEEMED DATE
				/*if (redeemedDate==null)
		    			cell7.setCellValue("");
		    	else*/
				cell7.setCellValue(resultSet.getString(7));
				cell7.setCellStyle(style);

				HSSFCell cell8 = row.createCell(7);									//GLOBAL NOTES LOCATION
				cell8.setCellValue(resultSet.getString(8));
				cell8.setCellStyle(style);

				HSSFCell cell9 = row.createCell(8);									//CGN/NGN
				cell9.setCellValue(resultSet.getString(9));
				cell9.setCellStyle(style);

				HSSFCell cell10 = row.createCell(9);								//GLOBAL NOTES LOCATION
				cell10.setCellValue(resultSet.getString(10));
				cell10.setCellStyle(style);

			}

			for(int columnIndex = 0; columnIndex < 10; columnIndex++) 
			{
				sheet.autoSizeColumn(columnIndex);
			}

			
			// This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Morning/Daily Early Maturity/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Morning/Daily Early Maturity/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
			
			String todayDate = getTodayDate();
			String strMailDate = getTodayDateForMail();
			String reportSrcPath = directory.toString() + "/" + todayDate + "_Daily_Early_Maturity_Report.xls";
			String reportDestPath = "//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/Daily/" + todayDate + "_Daily_Early_Maturity_Report.xls";
			//String reportDestPath = "//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/" + todayDate + "_Daily_Early_Maturity_Report.csv";
			FileOutputStream fileOut = new FileOutputStream(reportSrcPath);
			workbook.write(fileOut);
			fileOut.close();
			System.out.println("Daily Early Maturity Report is created successfully!");

			// Moving file to the network Location
			ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);

			String[] strToList = {"brian.treadway@bnymellon.com", "London.Vault@bnymellon.com", "cthkvault@bnymellon.com"};
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};
		    String strEmailSubject = "Early Maturity Report : " + strMailDate ;
		    String strEmailBody = "Hi,<br><br> \n " +
					"Please find the attached Early Maturity report for today.";		//Static part of email body
		    new SendingMailWithAttachmentUtility().sendMail(reportDestPath, strEmailSubject, strEmailBody, strToList, strCCList);
			//Sending mail to the client
			//new SendingMailForDailyEarlyMaturity().sendMail(reportSrcPath);
			
		}
		catch (SQLException e1) 
		{
			e1.printStackTrace();
		} 
		catch (FileNotFoundException e1) 
		{
			e1.printStackTrace();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}
	private String getTodayDateForMail() 
	{
		String strMailDate = null;
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE,0);  									//Selecting Yesterday's date
        
        strMailDate = dateFormat.format(cal.getTime());
        
        return strMailDate; 
	}
}