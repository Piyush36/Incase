package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobFor11PMProg9048Report implements Job
{
	public void execute(JobExecutionContext context) throws JobExecutionException 
	{
		Create11PMProg9048Report create11PMAdhocReport = new Create11PMProg9048Report();
		create11PMAdhocReport.createReport();
	}

}
