package reportautomation.obsolete.sendingMail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import java.util.ArrayList;
import java.util.Calendar;
//import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailForMonthlyHKReport 
{
	public static void main(String[] args) 
	{

	}

	public  void sendMail(String filename)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		MimeBodyPart messageBodyPart1;
		FileDataSource DFS;
		Multipart multipart;
		String emailBody;
		String emailSubject;
		String from;
		String emailPort;
		String emailHost;
		String reportDate = null;
		try
		{
			emailPort = "25";															//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

			String[] toEmails = {"cthkvault@bnymellon.com"};
			String[] ccEmails = {"ctsd.gdoasis@bnymellon.com"};																				//ctsd.gdoasis@bnymellon.com
			//String[] toEmails = {"abhikumar@inautix.co.in"};
			//String[] ccEmails = {"abhikumar@inautix.co.in"};	
			from = "abhikumar@inautix.co.in";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();
			messageBodyPart1 =	new MimeBodyPart();
			DFS	= new FileDataSource(filename);
			multipart = new MimeMultipart();
			reportDate = getTodayDate();
			
			emailSubject = "CTTISGASD-1173- Monthly_Live_Issue_HK_Report - " + reportDate;

			//if(reportDay != null && reportDay.equals("Monday"))

			emailBody = "Hi, \n " +
					"\n" +
					"Please find attached the Monthly_Live_Issue_HK_Report for last month\n" +
					"\n" +
					"\n" +
					"\n" +
					"Kind regards, \n" +
					"Abhishek Kumar \n" +
					"Application Service Delivery \n" +
					"iNautix Technologies India - A BNY Mellon Company";

			emailMessage.setSubject(emailSubject);
			emailMessage.setText(emailBody);
			emailMessage.setContent(emailBody, "text/html");
			messageBodyPart.setDataHandler(new DataHandler(DFS));
			messageBodyPart.setFileName(DFS.getName());
			messageBodyPart1.setText(emailBody);
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(messageBodyPart1);
			emailMessage.setContent(multipart);

			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			System.out.println("Attachment Name is : " + DFS.getName());

			Transport.send(emailMessage);

			System.out.println("Email sent successfully.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}
	
	// Helper Method to get the today's Date
	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}
}