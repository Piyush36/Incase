package reportautomation.obsolete.sendingMail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailForDaily11PMProg9048Report
{
	public static void main(String[] args) 
	{
		//new SendingMailFor4PMAdhocReport().sendMail("C:/Data/Reports Work/DailyReports/Evening/4pm Report_Adhoc request A40203704/Adhoc Request A40203704_18 May 2015.xls");
	}
	public  void sendMail(String filename)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		MimeBodyPart messageBodyPart1;
		FileDataSource DFS;
		Multipart multipart;
		String strTodayDate;
		//String strYesterdayDate;
		String emailBody;
		String emailSubject;
		String from;
		String emailPort;
		String emailHost;
		List<String> reportDay = new ArrayList<String>();
		reportDay = getDateString();
		try
		{
			emailPort = "25";															//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

			String[] toEmails = {"depo.stockqueries@bnymellon.com"};  					//its.puts.and.calls@bnymellon.com
			String[] ccEmails = {"ctsd.gdoasis@bnymellon.com","PeterSamuel.Hyde@bnymellon.com"};						    //ctsd.gdoasis@bnymellon.com
			//String[] toEmails = {"abhikumar@inautix.co.in"};
			//String[] ccEmails = {"abhikumar@inautix.co.in"};	
			from = "ctsd.gdoasis@bnymellon.com";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();
			messageBodyPart1 =	new MimeBodyPart();
			DFS	= new FileDataSource(filename);
			multipart = new MimeMultipart();
			//String filename = "C:/Data/Report Automation/Reports/DailyReports/Evening/4pm Report_Adhoc request A40203704/Adhoc Request A40203704_ 17 September 2015.xls";
			strTodayDate = reportDay.get(0);
			//strYesterdayDate = reportDay.get(1);
			emailSubject = "Programme No 9048 Daily Report - " + strTodayDate;

			//if(reportDay != null && reportDay.equals("Monday"))

			emailBody = "Hi, \n " +
					"\n" +
					"Please find the attached report for Program No 9048 as of 23:00 UK Time. \n" +
					"\n" +
					"Abhishek Kumar \n" +
					"Application Service Delivery \n" +
					"iNautix Technologies India - A BNY Mellon Company \n" +
					"Client Technology Solutions : Corporate Trust Technology \n" +
					"Tel : +1 646 782 3387 ";

			emailMessage.setSubject(emailSubject);
			emailMessage.setText(emailBody);
			emailMessage.setContent(emailBody, "text/html");
			messageBodyPart.setDataHandler(new DataHandler(DFS));
			messageBodyPart.setFileName(DFS.getName());
			messageBodyPart1.setText(emailBody);
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(messageBodyPart1);
			emailMessage.setContent(multipart);

			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			System.out.println(DFS.getName());

			Transport.send(emailMessage);

			System.out.println("Email sent successfully.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}

	private List<String> getDateString() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("MMM dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		System.out.println("Day is : " + dayValue);
		if(dayValue != null && dayValue.equals("Monday"))
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -3);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		else
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -1);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		return listofDays;
	}
	private String getDayForReport() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);

		return dayValue;
	}
}