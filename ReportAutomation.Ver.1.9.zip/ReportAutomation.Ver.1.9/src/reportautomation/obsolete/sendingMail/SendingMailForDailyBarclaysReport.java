package reportautomation.obsolete.sendingMail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailForDailyBarclaysReport 
{

	public static void main(String[] args) 
	{
		//new SendingMailFor4PMAdhocReport().sendMail("C:/Data/Reports Work/DailyReports/Evening/4pm Report_Adhoc request A40203704/Adhoc Request A40203704_18 May 2015.xls");
	}
	public  void sendMail(String filename)  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		MimeBodyPart messageBodyPart;
		MimeBodyPart messageBodyPart1;
		FileDataSource DFS;
		Multipart multipart;
		String strTodayDate;
		String emailBody;
		String emailSubject;
		String from;
		String emailPort;
		String emailHost;
		try
		{
			emailPort = "25";															//gmail's smtp port
			emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

			//String[] toEmails = {"graeme.cumming@bnymellon.com"};  					    //its.puts.and.calls@bnymellon.com
			//String[] ccEmails = {"ctsd.gdoasis@bnymellon.com"};						    //ctsd.gdoasis@bnymellon.com
			String[] toEmails = {"ltyagi@inautix.co.in"};
			String[] ccEmails = {"ltyagi@inautix.co.in"};	
			from = "abhikumar@inautix.co.in";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			messageBodyPart = new MimeBodyPart();
			messageBodyPart1 =	new MimeBodyPart();
			DFS	= new FileDataSource(filename);
			multipart = new MimeMultipart();
			
			strTodayDate = getDayForReport();

			emailSubject = "JIRA 1522 : Proposed Barclay's Daily repot from GD OASIS - " + strTodayDate;

			//if(reportDay != null && reportDay.equals("Monday"))

			emailBody = "Hi Graeme, \n " +
					"\n" +
					"Please find attached the report for today. \n" +
					"\n" +
					"\n" +
					"\n" +
					"<br>Abhishek Kumar" +
					"<br>Application Service Delivery" +
					"<br>iNautix Technologies India - A BNY Mellon Company" +
					"<br>Client Technology Solutions : Corporate Trust Technology" +
					"<br>Tel : +1 646 782 3387 ";

			emailMessage.setSubject(emailSubject);
			emailMessage.setText(emailBody);
			emailMessage.setContent(emailBody, "text/html");
			//messageBodyPart.setDataHandler(new DataHandler(DFS));
			//messageBodyPart.setFileName(DFS.getName());
			messageBodyPart1.setText(emailBody);
			//multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(messageBodyPart1);
			emailMessage.setContent(multipart);

			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			System.out.println(DFS.getName());

			Transport.send(emailMessage);

			System.out.println("Email sent successfully.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}

	private List<String> getDateString() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("MMM dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		System.out.println("Day is : " + dayValue);
		if(dayValue != null && dayValue.equals("Monday"))
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -3);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		else
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -1);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		return listofDays;
	}
	private String getDayForReport() 
	{
		String strDate = null;
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);
		strDate = dateFormat.format(cal.getTime());
		return strDate;
	}

}
