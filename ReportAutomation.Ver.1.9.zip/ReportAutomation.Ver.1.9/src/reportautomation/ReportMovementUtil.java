package reportautomation;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class ReportMovementUtil 
{
	public static void copyFiles(String srcPath, String destPath)
	{
		try 
		{
			FileUtils.copyFile(new File(srcPath), new File(destPath));
			System.out.println("File movement is done to " + destPath);
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void deleteFiles(String prevFile)
	{
		try
		{
			FileUtils.forceDelete(new File(prevFile));
			System.out.println("Previous File deleted - " + prevFile);
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/*public static void archiveFiles(String prevFile)
	{
		copyFiles(reportSrcPath, reportDestPath);
		copyFiles(prevDayReportSrcPath, prevDayReportDestPath);
		deleteFiles(prevDayReportSrcPath);
		
	}*/
	
	public static void main(String[] args) 
	{
		//new ReportMovementUtil().copyFiles();
	}
}
