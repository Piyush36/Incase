package reportautomation;

import java.util.HashMap;
import java.util.Map;

public class HeaderValues 
{
	public Map<Integer, String> createSecuritiesHeader()
	{
		Map <Integer, String> receiptSecuritiesMap = new HashMap<Integer, String>();
		receiptSecuritiesMap.put(1, "Issue Type");
		receiptSecuritiesMap.put(2, "Issue Name");
		receiptSecuritiesMap.put(3, "ISIN");
		receiptSecuritiesMap.put(4, "Currency");
		receiptSecuritiesMap.put(5, "Maturity Date");
		receiptSecuritiesMap.put(6, "Current Amount");
		receiptSecuritiesMap.put(7, "Register Type");
		receiptSecuritiesMap.put(8, "Temp /Perm");
		return receiptSecuritiesMap;
	}
	
	public Map<Integer, String> createAllIssueHeader()
	{
		Map <Integer, String> allIssueMap = new HashMap<Integer, String>();
		allIssueMap.put(1, "tra_isin");
		allIssueMap.put(2, "issu_cur");
		allIssueMap.put(3, "Shared");
		allIssueMap.put(4, "d_tra_principle_ccy");
		allIssueMap.put(5, "tra_int_curr");
		allIssueMap.put(6, "d_tra_min_denom");
		allIssueMap.put(7, "min_trade_denomination");
		allIssueMap.put(8, "d_tra_denom_interest_rates");
		allIssueMap.put(9, "claim_denom");
		allIssueMap.put(10, "issr_prog_no");
		allIssueMap.put(11, "in_int_desc");
		allIssueMap.put(12, "prod_identifier");
		allIssueMap.put(13, "tra_value_date");
		allIssueMap.put(14, "record_date");
		allIssueMap.put(15, "tra_last_int_date");
		allIssueMap.put(16, "tra_next_int_date");
		allIssueMap.put(17, "tra_fx_flag");
		allIssueMap.put(18, "tra_int_rate");
		allIssueMap.put(19, "tra_record_date_days_prior");
		allIssueMap.put(20, "tra_coupon_type");
		allIssueMap.put(21, "tra_int_basis");
		allIssueMap.put(22, "tra_bus_day_convention");
		allIssueMap.put(23, "d_adjust_flg");
		allIssueMap.put(24, "tra_mat_date");
		allIssueMap.put(25, "tra_pool_factor");
		allIssueMap.put(26, "tra_frn_fix_date");
		allIssueMap.put(27, "tra_registered");
		allIssueMap.put(28, "Clearstream Holding");
		allIssueMap.put(29, "Euroclear Holding");
		allIssueMap.put(30, "Held With");
		return allIssueMap;
	} 
	
	public Map<String, Integer> createYearMap()
	{
		Map <String, Integer> yearMap = new HashMap<String, Integer>();
		yearMap.put("January", 0);
		yearMap.put("February", 1);
		yearMap.put("March", 2);
		yearMap.put("April", 3);
		yearMap.put("May", 4);
		yearMap.put("June", 5);
		yearMap.put("July", 6);
		yearMap.put("August", 7);
		yearMap.put("September", 8);
		yearMap.put("October", 9);
		yearMap.put("November", 10);
		yearMap.put("December", 11);
		return yearMap;
	}
	
	public Map<Integer, String> createMaturityHeader()
	{
		Map <Integer, String> maturityMap = new HashMap<Integer, String>();
		maturityMap.put(1, "ISIN");
		maturityMap.put(2, "PPA");
		maturityMap.put(3, "Issuer");
		maturityMap.put(4, "Maturity Date");
		maturityMap.put(5, "Issue date");
		maturityMap.put(6, "Currency");
		maturityMap.put(7, "Denomination");
		maturityMap.put(8, "Bond From");
		maturityMap.put(9, "Bond To");
		maturityMap.put(10, "Bonds");
		maturityMap.put(11, "TotalAmount");
		maturityMap.put(12, "Int Rate");
		maturityMap.put(13, "Issue Type");
		return maturityMap;
	}
	
	public Map<Integer, String> createAdhocReportHeader()
	{
		Map <Integer, String> adhocReportMap = new HashMap<Integer, String>();
		adhocReportMap.put(1, "ISIN");
		adhocReportMap.put(2, "TAG35B");
		adhocReportMap.put(3, "DATE SENT");
		adhocReportMap.put(4, "DESTINATION ADDRESS");
		adhocReportMap.put(5, "CORP REFERENCE");
		adhocReportMap.put(6, "SEME REFERENCE");
		adhocReportMap.put(7, "23G_FUNCTION");
		adhocReportMap.put(8, "CAEV_IND IND");
		adhocReportMap.put(9, "T98_PREP_DATE");
		adhocReportMap.put(10, "T93_BALANCE");
		adhocReportMap.put(11, "98A_REDM");
		adhocReportMap.put(12, "92A_RATE");
		adhocReportMap.put(13, "90A_OFFR");
		adhocReportMap.put(14, "98A_PAYD");
		adhocReportMap.put(15, "98A_VALU");
		adhocReportMap.put(16, "98A_RDTE");
		return adhocReportMap;
	}
	
	public Map<Integer, String> createISINProcessedHeader()
	{
		Map <Integer, String> ISINProcessedMap = new HashMap<Integer, String>();
		ISINProcessedMap.put(1, "ISIN");
		ISINProcessedMap.put(2, "ISSUE NAME");
		ISINProcessedMap.put(3, "PROCCESSED BY");
		ISINProcessedMap.put(4, "VERIFIED USER");
		return ISINProcessedMap;
	}
	
	public Map<Integer, String> createISINProcessedHeaderCount()
	{
		Map <Integer, String> ISINProcessedCountMap = new HashMap<Integer, String>();
		ISINProcessedCountMap.put(1, "Processed By");
		ISINProcessedCountMap.put(2, "Verified By");
		ISINProcessedCountMap.put(3, "Processed By");
		ISINProcessedCountMap.put(4, "Verified By");
		return ISINProcessedCountMap;
	}
	
	public Map<Integer, String> createDRCBMT564Header()
	{
		Map <Integer, String> dRCBMT564 = new HashMap<Integer, String>();
		dRCBMT564.put(1, "ISIN");
		dRCBMT564.put(2, "Issue Name");
		dRCBMT564.put(3, "Principal Currency");
		dRCBMT564.put(4, "IPA Issue Description");
		dRCBMT564.put(5, "Maturity Method");
		dRCBMT564.put(6, "Maturity Proceed");
		dRCBMT564.put(7, "PRIN Amount");
		dRCBMT564.put(8, "ENTL Amount");
		dRCBMT564.put(9, "Maturity Date");
		dRCBMT564.put(10, "Clearer");
		dRCBMT564.put(11, "MT 564 TRN Reference");
		dRCBMT564.put(12, "Sent Date and Time");
		return dRCBMT564;
	}
	
	public Map<Integer, String> createLiveIssueHKHeader()
	{
		Map <Integer, String> liveIssueHK = new HashMap<Integer, String>();
		liveIssueHK.put(1, "ISIN");
		liveIssueHK.put(2, "Common Code");
		liveIssueHK.put(3, "Issue Date");
		liveIssueHK.put(4, "Redemption Date");
		liveIssueHK.put(5, "Current Holding(Nominal)");
		liveIssueHK.put(6, "Currency(Issue Currency)");
		liveIssueHK.put(7, "Issuer Name");
		liveIssueHK.put(8, "Issue Name");
		return liveIssueHK;
	}
	
	public Map<Integer, String> createliveIssueNominalExpCurrencyHeader()
	{
		Map <Integer, String> liveIssueNominal = new HashMap<Integer, String>();
		liveIssueNominal.put(1, "ISIN");
		liveIssueNominal.put(2, "Issue Name");
		liveIssueNominal.put(3, "Principal Currency");
		liveIssueNominal.put(4, "IPA Issue Currency");
		liveIssueNominal.put(5, "Redemption Currency");
		liveIssueNominal.put(6, "Interest Currency");
		liveIssueNominal.put(7, "Current Nominal");
		liveIssueNominal.put(8, "Exchange Rate");
		liveIssueNominal.put(9, "Status Code");
		liveIssueNominal.put(10, "Vault Location");
		return liveIssueNominal;
	}
	
	public Map<Integer, String> createDailyEarlyMaturityHeader()
	{
		Map <Integer, String> dailyEarlyMaturity = new HashMap<Integer, String>();
		dailyEarlyMaturity.put(1, "ISIN");
		dailyEarlyMaturity.put(2, "ISSUE NAME");
		dailyEarlyMaturity.put(3, "ISSUE TYPE");
		dailyEarlyMaturity.put(4, "CURRENT STATUS");
		dailyEarlyMaturity.put(5, "CURRENT HOLDING");
		dailyEarlyMaturity.put(6, "MATURITY DATE");
		dailyEarlyMaturity.put(7, "REDEEMED DATE");
		dailyEarlyMaturity.put(8, "GLOBAL NOTES LOCATION");
		dailyEarlyMaturity.put(9, "CGN/NGN");
		dailyEarlyMaturity.put(10, "GLOBAL NOTES LOCATION");
		return dailyEarlyMaturity;
	}
	
	public Map<Integer, String> createRegulatoryHeader()
	{
		Map <Integer, String> regulatoryReportMap = new HashMap<Integer, String>();
		regulatoryReportMap.put(1, "ISIN");
		regulatoryReportMap.put(2, "IPA Status");
		regulatoryReportMap.put(3, "GDO Status");
		regulatoryReportMap.put(4, "IPA Flag");
		regulatoryReportMap.put(5, "Issuance Date");
		regulatoryReportMap.put(6, "Maturity Date");
		regulatoryReportMap.put(7, "Global Note Location");
		return regulatoryReportMap;
	}
	
	public Map<Integer, String> createPaymentVolumeHeader()
	{
		Map <Integer, String> paymentVolume = new HashMap<Integer, String>();
		paymentVolume.put(1, "Issuer Program Number");
		paymentVolume.put(2, "Issuer Name");
		paymentVolume.put(3, "Count");
		return paymentVolume;
	}
}
