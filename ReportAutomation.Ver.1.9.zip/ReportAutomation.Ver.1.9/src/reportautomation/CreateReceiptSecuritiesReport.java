package reportautomation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;


public class CreateReceiptSecuritiesReport 
{
	public static void main(String[] arg)
	{
		new CreateReceiptSecuritiesReport().createReport();
		System.out.println("CreateReceiptSecurities Report is created successfully!");
	}
	
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("Sheet1");
		    
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.receiptSecuritiesQuery);
			System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createSecuritiesHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
		    
		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell((short)icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
	            
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
		    	HSSFCell cell1 = row.createCell(0);
		    	cell1.setCellValue(resultSet.getString(1));
		    	cell1.setCellStyle(style);
		    	
		    	HSSFCell cell2 = row.createCell(1);
		    	cell2.setCellValue(resultSet.getString(2));
		    	cell2.setCellStyle(style);
		    	
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));
		    	cell3.setCellStyle(style);
		    	
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));
		    	cell4.setCellStyle(style);
		    	
		    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
		    	//Date date = dt.parse(resultSet.getDate(5).toString());
		    	if(resultSet.getDate(5) != null)
		    	{
		    		String str = dt.format(resultSet.getDate(5));
			    	HSSFCell cell5 = row.createCell(4);
			    	cell5.setCellValue(str);
			    	cell5.setCellStyle(style);
		    	}
		    	
		    	HSSFCell cell6 = row.createCell(5);
		    	cell6.setCellValue(resultSet.getDouble(6));
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);
		    	cell7.setCellValue(resultSet.getString(7));
		    	cell7.setCellStyle(style);
		    	
		    	HSSFCell cell8 = row.createCell(7);
		    	cell8.setCellValue(resultSet.getString(8));
		    	cell8.setCellStyle(style);
		    }
		    for(int columnIndex = 0; columnIndex < 8; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    
		    String reportDay = getYesterdayDateString();
		    String reportPath = "C:/Data/Report Automation/Reports/DailyReports/Morning/Receipt of New Secutity/Receipt of New Securities Report - " + reportDay + ".xls";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getYesterdayDateString() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	String strVal = strToken.nextToken();
        	//System.out.println(strVal);
        	
        	list.add(strVal);
        }
        Integer intYear = Integer.valueOf(list.get(2));
        Integer intDate = Integer.valueOf(list.get(0));
       
        yearMap = hValues.createYearMap();
        Integer intMonth = yearMap.get(list.get(1));
        //System.out.println(intMonth);
        //
        Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
        String dayValue = new SimpleDateFormat("EEEE").format(date1);
        System.out.println("Day is : " + dayValue);
        if(dayValue != null && dayValue.equals("Monday"))
        {
        	//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
            cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -3);
            
            strDate = dateFormat.format(cal.getTime());
        }
        else
        {
        	//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
            cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -1);
            
            strDate = dateFormat.format(cal.getTime());
        }
        return strDate;
        
	}
}