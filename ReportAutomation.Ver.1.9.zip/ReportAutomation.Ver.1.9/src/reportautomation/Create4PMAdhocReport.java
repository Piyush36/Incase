package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;


public class Create4PMAdhocReport 
{
	public static void main(String[] arg)
	{
		new Create4PMAdhocReport().createReport();
		//System.out.println("Adhoc Request A40203704 Report is created successfully!");
	}
	
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		File directory = null;
		List<String> reportDay = new ArrayList<String>();
		//SendingMailFor4PMAdhocReport mailForAdhoc = new SendingMailFor4PMAdhocReport();
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("Sheet1");

		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.adhocReportQuery);
			System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createAdhocReportHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell((short)icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
	            
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
			
	    	HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
		    	HSSFCell cell1 = row.createCell(0);
		    	cell1.setCellValue(resultSet.getString(1));								//ISIN
		    	cell1.setCellStyle(style);
		    	
		    	HSSFCell cell2 = row.createCell(1);
		    	cell2.setCellValue(resultSet.getString(2));								//TAG35B
		    	cell2.setCellStyle(style);
		    	
		    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
		    	String dateSent = dt.format(resultSet.getDate(3));						//DATE SENT
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(dateSent);
		    	cell3.setCellStyle(style);
		    	
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));								//DESTINATION ADDRESS
		    	cell4.setCellStyle(style);
		    	
		    	HSSFCell cell5 = row.createCell(4);
		    	cell5.setCellValue(resultSet.getString(5));								//CORP REFERENCE
		    	cell5.setCellStyle(style);
		    	
		    	HSSFCell cell6 = row.createCell(5);
		    	cell6.setCellValue(resultSet.getString(6));								//SEME REFERENCE
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);
		    	cell7.setCellValue(resultSet.getString(7));								//23G_FUNCTION
		    	cell7.setCellStyle(style);
		    	
		    	HSSFCell cell8 = row.createCell(7);
		    	cell8.setCellValue(resultSet.getString(8));								//CAEV_IND IND
		    	cell8.setCellStyle(style);
		    	
		    	String t98PrepDate = dt.format(resultSet.getDate(9));					//T98_PREP_DATE
		    	HSSFCell cell9 = row.createCell(8);
		    	cell9.setCellValue(t98PrepDate);
		    	cell9.setCellStyle(style);
		    	
		    	HSSFCell cell10 = row.createCell(9);
		    	cell10.setCellValue(resultSet.getString(10));							//T93_BALANCE
		    	cell10.setCellStyle(style);
		    	
		    	String a98RedmDate = dt.format(resultSet.getDate(11));					//98A_REDM
		    	HSSFCell cell11 = row.createCell(10);
		    	cell11.setCellValue(a98RedmDate);
		    	cell11.setCellStyle(style);

		    	HSSFCell cell12 = row.createCell(11);
		    	cell12.setCellValue(resultSet.getInt(12));								//92A_RATE
		    	cell12.setCellStyle(style);
		    	
		    	HSSFCell cell13 = row.createCell(12);
		    	cell13.setCellValue(resultSet.getString(13));							//90A_OFFR
		    	cell13.setCellStyle(style);
		    	
		    	String a98Payd = dt.format(resultSet.getDate(14));						//98A_PAYD
		    	HSSFCell cell14 = row.createCell(13);
		    	cell14.setCellValue(a98Payd);
		    	cell14.setCellStyle(style);
		    	
		    	String a98Valu = dt.format(resultSet.getDate(15));						//98A_VALU
		    	HSSFCell cell15 = row.createCell(14);
		    	cell15.setCellValue(a98Valu);
		    	cell15.setCellStyle(style);
		    	
		    	String a98RDTE = dt.format(resultSet.getDate(16));						////98A_RDTE 
		    	HSSFCell cell16 = row.createCell(15);
		    	cell16.setCellValue(a98RDTE);
		    	cell16.setCellStyle(style);
		    	
		    	
		    }
		    for(int columnIndex = 0; columnIndex < 16; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    
		    // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Evening/4pm Report_Adhoc request A40203704/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Evening/4pm Report_Adhoc request A40203704/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
		    
		    reportDay = getDateString();
		    String reportPath = directory.toString() + "/Adhoc Request A40203704_" + reportDay.get(0) + ".xls";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		    
		    System.out.println("Adhoc Request A40203704 Report is created successfully!");
		    String strTodayDate = reportDay.get(0);
			String strYesterdayDate = reportDay.get(1);
		    //Sending Mail part
		    String[] strToList = {"its.puts.and.calls@bnymellon.com"};  // its.puts.and.calls@bnymellon.com
		    String[] strCCList = {"ctsd.gdoasis@bnymellon.com"};   //ctsd.gdoasis@bnymellon.com
		    String strEmailSubject = "Adhoc request A40203704";
		    String strEmailBody = "Hi All,<br><br> \n " +
					"Please find the attached report for MCAL notifications sent from " + strYesterdayDate + " (4:00 PM) till " + strTodayDate + " (4:00 PM). \n";
		    new SendingMailWithAttachmentUtility().sendMail(reportPath, strEmailSubject, strEmailBody, strToList, strCCList);
		    // Sending mail for 4 PM Adhoc Report
		    //mailForAdhoc.sendMail(reportPath);		//Obsolete Code
		
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}

	private List<String> getDateString()
	{

		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("MMM dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);

		strDate = dateFormat.format(cal.getTime());

		StringTokenizer strToken = new StringTokenizer(strDate, " ");
		while(strToken.hasMoreTokens())
		{
			String strVal = strToken.nextToken();
			//System.out.println(strVal);

			list.add(strVal);
		}
		Integer intYear = Integer.valueOf(list.get(2));
		Integer intDate = Integer.valueOf(list.get(0));

		yearMap = hValues.createYearMap();
		Integer intMonth = yearMap.get(list.get(1));
		//System.out.println(intMonth);
		//
		Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
		String dayValue = new SimpleDateFormat("EEEE").format(date1);
		System.out.println("Day is : " + dayValue);
		if(dayValue != null && dayValue.equals("Monday"))
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -3);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		else
		{
			//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
			cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 0);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);

			cal.add(Calendar.DATE, -1);

			strDate = dateFormat.format(cal.getTime());
			listofDays.add(strDate);
		}
		return listofDays;
	
	}
}