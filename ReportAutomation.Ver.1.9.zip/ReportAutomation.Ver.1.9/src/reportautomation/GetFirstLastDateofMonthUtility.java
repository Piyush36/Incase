package reportautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class GetFirstLastDateofMonthUtility {
	
	public static void main(String[] args) {
		System.out.println("Last day of the month : " + getLastDayoftheMonth());
		System.out.println("First day of the month : " + getFirstdayofthemonth());
		System.out.println(getFirstdayofthemonth().substring(2, 5));
		System.out.println(getFirstdayofthemonth().substring(6, 10));
	}
	
	public static String getLastDayoftheMonth()
	{
		String strMonth = null;
		String strYear = null;
		DateFormat dateFormatMonth = new SimpleDateFormat("MMM");
		DateFormat dateFormatYear = new SimpleDateFormat("yyyy");

		Calendar cal1 = Calendar.getInstance();
		cal1.add(Calendar.MONTH, -1);
		strMonth = dateFormatMonth.format(cal1.getTime());
		strYear = dateFormatYear.format(cal1.getTime());
		int strDate = cal1.getActualMaximum(Calendar.DATE);
		String lastday = strDate + " " + strMonth + " " + strYear;
		return lastday;
	}

	public static String getFirstdayofthemonth()
	{
		String strMonth = null;
		String strYear = null;
		DateFormat firstdateFormat = new SimpleDateFormat("MMM");
		DateFormat firstdateFormat1 = new SimpleDateFormat("yyyy");

		Calendar cal1 = Calendar.getInstance();
		cal1.add(Calendar.MONTH, -1);
		strMonth = firstdateFormat.format(cal1.getTime());
		strYear = firstdateFormat1.format(cal1.getTime());
		int firstDate = cal1.getActualMinimum(Calendar.DATE);
		String firstday = firstDate + " " + strMonth + " " + strYear;
		return firstday;
	}
}