package reportautomation;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScheduleJobForHCMail implements Job{
 

@Override
public void execute(JobExecutionContext arg0) throws JobExecutionException {
	// TODO Auto-generated method stub
	CreateMailForHC obj_createmailforhc = new CreateMailForHC();
	obj_createmailforhc.createMail();
}
}
