package reportautomation;

import java.io.File;

public class CreateOasisManualAmortizationReport 
{



	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateOasisManualAmortizationReport().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		File destDirectory = null;
		File destArchiveDirectory = null;
		
				// Dates
				String reportDay = new DateList().todaysDate();
				String prevDay = new DateList().lastWorkingDayDate();
				String strMonth = new DateList().lastWorkingDayDate().substring(3, 6);
				String strYear = new DateList().lastWorkingDayDate().substring(7, 11);
				    
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/Morning/Oasis Manual Amortization/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/Morning/Oasis Manual Amortization/ is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
			
			destDirectory = new File("//whexpfseur11/CorpTrustPoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/" +
					"GD Oasis/ProdReports/Daily/");
			if(!destDirectory.exists())
			{
				if(destDirectory.mkdirs())
					System.out.println(destDirectory + "Created");
				else
					System.out.println("Failed to create destination directory!");
			}
			else
				System.out.println("destination directory already exist");
			
			destArchiveDirectory = new File(destDirectory + "/0 Archive/" + strYear + "/" + strMonth + "/");
			if(!destArchiveDirectory.exists())
			{
				if(destArchiveDirectory.mkdirs())
					System.out.println(destArchiveDirectory + "Created");
				else
					System.out.println("Failed to create destination directory!");
			}
			else
				System.out.println("destination directory already exist");
		    
		    String reportSrcPath = directory.toString() + "/Oasis Manual Amortization Report - " + reportDay + ".xls";
		    String reportDestPath = destDirectory.toString() + "/Oasis Manual Amortization Report - " + reportDay + ".xls";
		    
		    //Previous Day's Report
		    String prevDayReportSrcPath = destDirectory.toString() + "/Oasis Manual Amortization Report - " + prevDay + ".xls";
		    //Previous Day's report with full path which needs to be Archived
		    String prevDayReportDestPath = destArchiveDirectory.toString() + "/Oasis Manual Amortization Report - " + prevDay + ".xls";
		    
		    //Creating XLS Report
		    CreateXLSUtility.createXLS(QueriesConstant.dailyOasisManualAmortizationReport, "Sheet1", reportSrcPath);
		    System.out.println("Oasis Manual Amortization Report is created successfully!");
		    
		    // Moving file to the network Location
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		    
		    ReportMovementUtil.copyFiles(prevDayReportSrcPath, prevDayReportDestPath);
		    
		    ReportMovementUtil.deleteFiles(prevDayReportSrcPath);
		    
		    // Below method is responsible to send the mail. Client do not need mail hence commented. 
		    //new SendingMailForDailyBarclaysReport().sendMail(reportSrcPath);
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
}
