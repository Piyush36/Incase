package reportautomation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class CreateNewRegulatoryReport_Old 
{

	public static void main(String[] arg)
	{
		new CreateNewRegulatoryReport_Old().createReport();
		System.out.println("NewRegulatoryReport Report is created successfully!");
	}
	
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("CASS");
		    
		    connection = GetConnectionDev.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstant.regulatoryReportQuery);
			System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createRegulatoryHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
		    
		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell(icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
	            
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
		    	HSSFCell cell1 = row.createCell(0);
		    	cell1.setCellValue(resultSet.getString(1));							//ISIN
		    	cell1.setCellStyle(style);
		    	
		    	HSSFCell cell2 = row.createCell(1);
		    	cell2.setCellValue(resultSet.getString(2));							//IPA Status
		    	cell2.setCellStyle(style);
		    	
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));							//GDO Status
		    	cell3.setCellStyle(style);
		    	
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(resultSet.getString(4));							//IPA Flag
		    	cell4.setCellStyle(style);
		    	
		    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
		    	//Date date = dt.parse(resultSet.getDate(5).toString());
		    	/*if(resultSet.getObject(5) != null)
		    	{
		    	}*/
		    	
		    	System.out.println(resultSet.getObject(5));
	    		//String str = dt.format(resultSet.getObject(5).toString());					//Issuance Date
		    	HSSFCell cell5 = row.createCell(4);
		    	//cell5.setCellValue(str);
		    	if(resultSet.getObject(5) != null)
		    	{
		    		cell5.setCellValue(resultSet.getObject(5).toString());
		    	}
		    	else
		    	{
		    		cell5.setCellValue("");
		    	}
		    	cell5.setCellStyle(style);
		    	
		    	/*if(resultSet.getObject(6) != null)
		    	{
		    	}*/
		    	
		    	System.out.println(resultSet.getObject(6));
	    		//String str = dt.format(resultSet.getObject(6).toString());					//Maturity Date
		    	HSSFCell cell6 = row.createCell(5);
		    	//cell6.setCellValue(str);
		    	if(resultSet.getObject(6) != null)
		    	{
		    		cell6.setCellValue(resultSet.getObject(6).toString());
		    	}
		    	else
		    	{
		    		cell6.setCellValue("");
		    	}
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);
		    	cell7.setCellValue(resultSet.getString(7));							//Global Note Location
		    	cell7.setCellStyle(style);
		    }
		    for(int columnIndex = 0; columnIndex < 7; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    
		    String reportDay = getDateString();
		    String reportPath = "C:/Reports/Weekly Reports/New Regulatory Report/GDO_regulatory_ " + reportDay + ".xls";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		catch (Exception e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private String getDateString() 
	{
		String strDate = null;
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        strDate = dateFormat.format(cal.getTime());
        return strDate;
        
	}
}
