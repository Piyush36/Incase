package reportautomation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class CreateMonthlyPaymentVolMerrylLynch 
{
	public static void main(String[] args)
	{
		new CreateMonthlyPaymentVolMerrylLynch().createReport();
	}
	
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
			String reportMonth = getYesterMonthString();
		    HSSFSheet sheet = workbook.createSheet(reportMonth);
		    
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(QueriesConstantMonthly.paymentVolAmericaMeryllQuery);
		    System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createPaymentVolumeHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();

		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell(icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setIndention((short) 0);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
	            HSSFCell cell1 = row.createCell(0);
	            cell1.setCellValue(resultSet.getString(1));							//Issuer Program Number
	            cell1.setCellStyle(style);
	            
	            HSSFCell cell2 = row.createCell(1);
	            cell2.setCellValue(resultSet.getString(2));							//Issuer Name
	            cell2.setCellStyle(style);
		    	
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));							//Count
		    	cell3.setCellStyle(style);
		    	
		    }
		    
		    for(int columnIndex = 0; columnIndex < 3; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}

		    String reportSrcPath = "C:/Data/Report Automation/Reports/Monthly/Payment Volume Bank of Merril Lynch/Payment_Volume_Bank_of_Merril Lynch - "+ reportMonth +".xls";
		    String reportDestPath = "//whexpfseur11/corptrustpoole/BNY Tech Poole/BNY EMEA Corporate Trust Technology/Application Support/Adhoc Requests/Reports/GD Oasis/ProdReports/Monthly/Payment_Volume_Bank_of_Merril Lynch - "+ reportMonth +".xls";
		    File directory= new File("C:/Data/Report Automation/Reports/Monthly/Payment Volume Bank of Merril Lynch/");
		    if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println(reportSrcPath+ "is created");
				else
					System.out.println("Failed to create source directory!");
			}
			else
				System.out.println("source directory already exist");
		    
		    
		    
		    
		    
		    
		    
		    FileOutputStream fileOut = new FileOutputStream(reportSrcPath);
		    
		    
		    
		    
		    
		    workbook.write(fileOut);
		    fileOut.close();
		    System.out.println("Payment Volume Bank of America Merril Lynch Report is created successfully!");
		    ReportMovementUtil.copyFiles(reportSrcPath, reportDestPath);
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	public static String getYesterMonthString() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}
}
