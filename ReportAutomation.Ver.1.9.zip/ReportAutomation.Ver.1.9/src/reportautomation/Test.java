package reportautomation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Test 
{
	public static void main(String[] args) 
	{
		new Test().getTodayDateArray();
	}
	private List<String> getTodayDateArray() 
	{
		String strDate = null;
		String strDate1 = null;
		List<String> dateArray = new ArrayList<String>();
		//DateFormat dateFormat = new SimpleDateFormat("d MMMMMMMMM yyyy");
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
		DateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        strDate1 = dateFormat1.format(cal.getTime());
       /* StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	strMonth = strToken.
        }*/
        dateArray.add(strDate.substring(3, 6));
        dateArray.add(strDate.substring(7, 11));
        dateArray.add(strDate1);
        System.out.println(dateArray.get(0));
        System.out.println(dateArray.get(1));
        System.out.println(dateArray.get(2));
        return dateArray; 
	}
}
