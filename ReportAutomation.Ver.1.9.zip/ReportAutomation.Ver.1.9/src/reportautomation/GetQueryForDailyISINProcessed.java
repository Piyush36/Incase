package reportautomation;

public class GetQueryForDailyISINProcessed 
{
	public static String getQueryForOASISISINProcessed(String strFrom, String strTo)
	{
		String strOASISQuery = "select p.isin,vt.issue_name,(select user_name from east_users where user_id = p.marked_by_user) as 'PROCCESSED BY', " +
								"(select user_name from east_users where user_id = p.payment_released_user) as 'VERIFIED USER' " +
								"from payment_instruction p ,v_tranche vt " +
								"where vt.isin = p.isin and p.payment_release_date >= '" + strFrom + "' and p.payment_release_date < '" + strTo + "'";
		return strOASISQuery;
	}
	
	public static String getQueryForMANUALISINProcessed(String strFrom, String strTo)
	{
		String strMANUALQuery = "select m.isin,v.issue_name,(select user_name from east_users where user_id = m.last_edit_user) as 'PROCCESSED BY', " +
								"(select user_name from east_users where user_id = m.verified_user) as 'VERIFIED USER' " +
								"from manual_payment m,v_tranche v where v.isin = m.isin " +
								"and m.payment_date >= '" + strFrom + "' and m.payment_date < '" + strTo + "'";
		return strMANUALQuery;
	}
}
