package reportautomation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;


public class CreateDailyMaturityReport 
{
	public static void main(String[] arg)
	{
		CreateDailyMaturityReport createMaturity = new CreateDailyMaturityReport();
		String reportDay = createMaturity.getDayForReport();
		if(reportDay != null && reportDay.equals("Friday"))
		{
			createMaturity.createFridayReport();
			System.out.println("day is : " + reportDay + "  Calling the method createFridayReport");
			System.out.println("Maturity Report is created successfully for Friday !");
		}
		else
		{
			createMaturity.createReport();
			System.out.println("day is : " + reportDay + "  Calling the method createReport");
			System.out.println("Maturity Report is created successfully!");
		}
				
	}
	
	public void createReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		GetQueryForMaturity getQueryForMaturity = null;
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		List<String> reportDay = new ArrayList<String>();
		reportDay = getTomorrowDateString();
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet(reportDay.get(0));
		    
		    getQueryForMaturity = new GetQueryForMaturity();
		    connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(getQueryForMaturity.getQuery(reportDay.get(0)));
			System.out.println("ResultSet is prepared");
		    int key = 1;
		    int icell = 0;
		    hMap = hValues.createMaturityHeader();
		    row = sheet.createRow(rowid);
		    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
		    while(itr.hasNext())
		    {
		    	Entry<Integer, String> entry = itr.next();
		    	
			    HSSFCell cell = row.createCell(icell++);
			    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		        cell.setCellValue(hMap.get(key++));            
		        HSSFCellStyle style = workbook.createCellStyle();
		        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		        HSSFFont arialBoldFont = workbook.createFont();
		        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        arialBoldFont.setFontName("Calibri");
		        arialBoldFont.setFontHeightInPoints((short) 11);
		        style.setFont(arialBoldFont);
		        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
	            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
	            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
	            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		        cell.setCellStyle(style);
		    }
		    System.out.println("Header Created Successfully");
		    
		    HSSFCellStyle style = workbook.createCellStyle();
	    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    while(resultSet.next())
		    {
		    	row = sheet.createRow(++rowid);
		    	
		    	HSSFCell cell1 = row.createCell(0);
		    	cell1.setCellValue(resultSet.getString(1));								//ISIN
		    	cell1.setCellStyle(style);
		    	
		    	HSSFCell cell2 = row.createCell(1);
		    	cell2.setCellValue(resultSet.getString(2));								//PPA
		    	cell2.setCellStyle(style);
		    	
		    	HSSFCell cell3 = row.createCell(2);
		    	cell3.setCellValue(resultSet.getString(3));								//Issuer
		    	cell3.setCellStyle(style);
		    	
		    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
		    	
		    	String maturityDate = dt.format(resultSet.getDate(4));					//Maturity Date
		    	HSSFCell cell4 = row.createCell(3);
		    	cell4.setCellValue(maturityDate);
		    	cell4.setCellStyle(style);
		    	
		    	String issueDate = dt.format(resultSet.getDate(5));						//Issue date
		    	HSSFCell cell5 = row.createCell(4);
		    	cell5.setCellValue(issueDate);
		    	cell5.setCellStyle(style);
		    	
		    	HSSFCell cell6 = row.createCell(5);
		    	cell6.setCellValue(resultSet.getString(6));								//Currency
		    	cell6.setCellStyle(style);
		    	
		    	HSSFCell cell7 = row.createCell(6);
		    	long denomination = resultSet.getLong(7);								//Denomination
		    	if(denomination ==0)
		    		cell7.setCellValue("");	
		    	else
		    		cell7.setCellValue(denomination);
		    	cell7.setCellStyle(style);
		    	
		    	HSSFCell cell8 = row.createCell(7);
		    	int bondFrom = resultSet.getInt(8);										//Bond From
		    	if(bondFrom == 0)
		    		cell8.setCellValue("");	
		    	else
		    		cell8.setCellValue(bondFrom);
		    	cell8.setCellStyle(style);
		    	
		    	HSSFCell cell9 = row.createCell(8); 
		    	int bondTo = resultSet.getInt(9);										//Bond To
		    	if(bondTo == 0)
		    		cell9.setCellValue("");			
		    	else
		    		cell9.setCellValue(bondTo);
		    	cell9.setCellStyle(style);
		    	
		    	HSSFCell cell10 = row.createCell(9);
		    	int bonds = resultSet.getInt(10);										//Bonds
		    	if(bonds == 0)
		    		cell10.setCellValue("");
		    	else
		    		cell10.setCellValue(bonds);
		    	cell10.setCellStyle(style);
		    	
		    	HSSFCell cell11 = row.createCell(10);
		    	long totalAmount = resultSet.getLong(11);								//TotalAmount
		    	if(totalAmount == 0)
		    		cell11.setCellValue("");
		    	else
		    		cell11.setCellValue(totalAmount);
		    	cell11.setCellStyle(style);
		    	
		    	HSSFCell cell12 = row.createCell(11);
		    	float intRate = resultSet.getFloat(12);									//Int Rate
		    	if(intRate == 0)
		    		cell12.setCellValue("");
		    	else
		    		cell12.setCellValue(intRate);
		    	cell12.setCellStyle(style);
		    	
		    	HSSFCell cell13 = row.createCell(12);
		    	cell13.setCellValue(resultSet.getString(13));							//Issue Type
		    	cell13.setCellStyle(style);
		    	
		    }
		    for(int columnIndex = 0; columnIndex < 13; columnIndex++) 
		    {
		    	sheet.autoSizeColumn(columnIndex);
	    	}
		    
		    String reportPath = "C:/Data/Report Automation/Reports/DailyReports/Morning/Maturity Report CD/Maturity List Report _LI_LON_CD_" + reportDay.get(0) + ".xls";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	public void createFridayReport()
	{
		int rowid = 0;
		HSSFRow row = null;
		HeaderValues hValues = new HeaderValues();
		GetQueryForMaturity getQueryForMaturity = null;
		Map<Integer, String> hMap = new HashMap<Integer, String>();
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		List<String> reportDay = new ArrayList<String>();
		reportDay = getTomorrowDateString();
		try
		{
			connection = GetConnection.getConnection();
			HSSFWorkbook workbook = new HSSFWorkbook();
			for(String day : reportDay)
			{
				try
				{

				    HSSFSheet sheet = workbook.createSheet(day);
				    System.out.println("Day for the report is : "  + day);
				    getQueryForMaturity = new GetQueryForMaturity();
				    
				    stmt = connection.createStatement();
					resultSet = stmt.executeQuery(getQueryForMaturity.getQuery(day));
					System.out.println("ResultSet is prepared");
				    int key = 1;
				    int icell = 0;
				    hMap = hValues.createMaturityHeader();
				    row = sheet.createRow(rowid);
				    Iterator<Entry<Integer, String>> itr = hMap.entrySet().iterator();
				    while(itr.hasNext())
				    {
				    	Entry<Integer, String> entry = itr.next();
				    	
					    HSSFCell cell = row.createCell(icell++);
					    cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				        cell.setCellValue(hMap.get(key++));            
				        HSSFCellStyle style = workbook.createCellStyle();
				        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				        HSSFFont arialBoldFont = workbook.createFont();
				        arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				        arialBoldFont.setFontName("Calibri");
				        arialBoldFont.setFontHeightInPoints((short) 11);
				        style.setFont(arialBoldFont);
				        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
			            style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				        cell.setCellStyle(style);
				    }
				    System.out.println("Header Created Successfully");
				    
				    HSSFCellStyle style = workbook.createCellStyle();
			    	style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		            style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		            style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		            style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				    while(resultSet.next())
				    {
				    	row = sheet.createRow(++rowid);
				    	
				    	HSSFCell cell1 = row.createCell(0);
				    	cell1.setCellValue(resultSet.getString(1));								//ISIN
				    	cell1.setCellStyle(style);
				    	
				    	HSSFCell cell2 = row.createCell(1);
				    	cell2.setCellValue(resultSet.getString(2));								//PPA
				    	cell2.setCellStyle(style);
				    	
				    	HSSFCell cell3 = row.createCell(2);
				    	cell3.setCellValue(resultSet.getString(3));								//Issuer
				    	cell3.setCellStyle(style);
				    	
				    	SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
				    	
				    	String maturityDate = dt.format(resultSet.getDate(4));					//Maturity Date
				    	HSSFCell cell4 = row.createCell(3);
				    	cell4.setCellValue(maturityDate);
				    	cell4.setCellStyle(style);
				    	
				    	String issueDate = dt.format(resultSet.getDate(5));						//Issue date
				    	HSSFCell cell5 = row.createCell(4);
				    	cell5.setCellValue(issueDate);
				    	cell5.setCellStyle(style);
				    	
				    	HSSFCell cell6 = row.createCell(5);
				    	cell6.setCellValue(resultSet.getString(6));								//Currency
				    	cell6.setCellStyle(style);
				    	
				    	HSSFCell cell7 = row.createCell(6);
				    	long denomination = resultSet.getLong(7);								//Denomination
				    	if(denomination ==0)
				    		cell7.setCellValue("");	
				    	else
				    		cell7.setCellValue(denomination);
				    	cell7.setCellStyle(style);
				    	
				    	HSSFCell cell8 = row.createCell(7);
				    	int bondFrom = resultSet.getInt(8);										//Bond From
				    	if(bondFrom == 0)
				    		cell8.setCellValue("");	
				    	else
				    		cell8.setCellValue(bondFrom);
				    	cell8.setCellStyle(style);
				    	
				    	HSSFCell cell9 = row.createCell(8); 
				    	int bondTo = resultSet.getInt(9);										//Bond To
				    	if(bondTo == 0)
				    		cell9.setCellValue("");			
				    	else
				    		cell9.setCellValue(bondTo);
				    	cell9.setCellStyle(style);
				    	
				    	HSSFCell cell10 = row.createCell(9);
				    	int bonds = resultSet.getInt(10);										//Bonds
				    	if(bonds == 0)
				    		cell10.setCellValue("");
				    	else
				    		cell10.setCellValue(bonds);
				    	cell10.setCellStyle(style);
				    	
				    	HSSFCell cell11 = row.createCell(10);
				    	long totalAmount = resultSet.getLong(11);								//TotalAmount
				    	if(totalAmount == 0)
				    		cell11.setCellValue("");
				    	else
				    		cell11.setCellValue(totalAmount);
				    	cell11.setCellStyle(style);
				    	
				    	HSSFCell cell12 = row.createCell(11);
				    	float intRate = resultSet.getFloat(12);									//Int Rate
				    	if(intRate == 0)
				    		cell12.setCellValue("");
				    	else
				    		cell12.setCellValue(intRate);
				    	cell12.setCellStyle(style);
				    	
				    	HSSFCell cell13 = row.createCell(12);
				    	cell13.setCellValue(resultSet.getString(13));							//Issue Type
				    	cell13.setCellStyle(style);
				    	
				    }
				    for(int columnIndex = 0; columnIndex < 13; columnIndex++) 
				    {
				    	sheet.autoSizeColumn(columnIndex);
			    	}
				
				}
				finally
				{
					try 
					{
						if(resultSet != null)
							resultSet.close();
					} 
					catch (SQLException e) 
					{
						System.out.println("Exception occured while closing the ResultSet");
						e.printStackTrace();
					}
					try 
					{
						if(stmt != null)
							stmt.close();
					} 
					catch (SQLException e) 
					{
						System.out.println("Exception occured while closing the Statement");
						e.printStackTrace();
					}
				}
			}
		    
		    String reportPath = "C:/Reports/DailyReports/Morning/Maturity Report CD/Maturity List Report _LI_LON_CD_" + reportDay.get(0).substring(0, 2) 
		    						+ "_" + reportDay.get(1).substring(0, 2) + "_" + reportDay.get(2) + ".xls";
		    FileOutputStream fileOut = new FileOutputStream(reportPath);
		    workbook.write(fileOut);
		    fileOut.close();
		}
		catch (SQLException e1) 
		{
	        e1.printStackTrace();
	    } 
		catch (FileNotFoundException e1)
		{
	        e1.printStackTrace();
	    } 
		catch (IOException e1) 
		{
	        e1.printStackTrace();
	    }
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
	}
	
	private List<String> getTomorrowDateString() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		List<String> listofDays = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	String strVal = strToken.nextToken();
        	//System.out.println(strVal);
        	
        	list.add(strVal);
        }
        Integer intYear = Integer.valueOf(list.get(2));
        Integer intDate = Integer.valueOf(list.get(0));
       
        yearMap = hValues.createYearMap();
        Integer intMonth = yearMap.get(list.get(1));
        //System.out.println(intMonth);
        //
        Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
        String dayValue = new SimpleDateFormat("EEEE").format(date1);
        System.out.println("Day is : " + dayValue);
        if(dayValue != null && !dayValue.equals("Friday"))
        {
        	//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
            cal = Calendar.getInstance();
            cal.add(Calendar.DATE, +1);
            
            strDate = dateFormat.format(cal.getTime());
            listofDays.add(strDate);
        }
        else
        {
        	//DateFormat dateFormat1 = new SimpleDateFormat("d MMMMMMMMM yyyy");
            cal = Calendar.getInstance();
            cal.add(Calendar.DATE, +1);
            
            strDate = dateFormat.format(cal.getTime());
            listofDays.add(strDate);
            
            cal.add(Calendar.DATE, +1);
            
            strDate = dateFormat.format(cal.getTime());
            listofDays.add(strDate);
            
            cal.add(Calendar.DATE, +1);
            
            strDate = dateFormat.format(cal.getTime());
            listofDays.add(strDate);
        }
        return listofDays;
        
	}
	private String getDayForReport() 
	{
		String strDate = null;
		List<String> list = new ArrayList<String>();
		Map <String, Integer> yearMap = null;
		HeaderValues hValues = new HeaderValues();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        StringTokenizer strToken = new StringTokenizer(strDate, " ");
        while(strToken.hasMoreTokens())
        {
        	String strVal = strToken.nextToken();
        	//System.out.println(strVal);
        	
        	list.add(strVal);
        }
        Integer intYear = Integer.valueOf(list.get(2));
        Integer intDate = Integer.valueOf(list.get(0));
       
        yearMap = hValues.createYearMap();
        Integer intMonth = yearMap.get(list.get(1));
        //System.out.println(intMonth);
        //
        Date date1 = (new GregorianCalendar(intYear, intMonth, intDate)).getTime();
        String dayValue = new SimpleDateFormat("EEEE").format(date1);
        
        return dayValue;
	}
}