package reportautomation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetConnectionDev
{
	
	public static Connection getConnection()
	{
		// To make a connection first we need driver loaded in, User name password and URL according to the database
		// For Oracle
		//String strDriver = "oracle.jdbc.driver.OracleDriver";
		String strDriver = "com.sybase.jdbc3.jdbc.SybDriver";
		String strUserName = "XBBNHLJ";
		String strPassword = "xbbnhlj3142";
		String strURL = "jdbc:sybase:Tds:xsd00y71:4035/sdjafgdo";
		//For Oracle
		//String strURL = "jdbc:oracle:thin:@localhost:1521:sid";
		Connection connection = null;
		try
		{
			Class.forName(strDriver);
			System.out.println("Driver Loaded");
			connection = DriverManager.getConnection(strURL, "XBBNHLJ", "xbbnhlj3142");
			System.out.println("Connection Established");
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		} 
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return connection;
	}
	public ResultSet getData(String query)
	{
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		try
		{
			connection = getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(query);
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		} 
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally
		{
			try 
			{
				if(stmt != null)
				stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
		return resultSet;
	}
}
