package quartz;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendingMailTest 
{
	public static void main(String[] args) {
		new SendingMailTest().sendMail();
	}
	public  void sendMail()  
	{
		Properties emailProperties;
		Session mailSession;
		MimeMessage emailMessage;
		//MimeMessage emailMessage1;
		String tm;
		try
		{
			String emailPort = "25";//gmail's smtp port
			String emailHost = "SMTPE.BNYMELLON.NET";
			emailProperties = System.getProperties();
			emailProperties.put("mail.smtp.port", emailPort);
			emailProperties.put("mail.smtp.host", emailHost);

			String[] toEmails = {"sobreed@inautix.co.in"};
			String[] ccEmails = {"ltyagi@inautix.co.in"};				//rdubey@inautix.co.in  SSalve@inautix.co.in abhikumar@inautix.co.in
			String from = "ltyagi@inautix.co.in";
			mailSession = Session.getDefaultInstance(emailProperties, null);
			emailMessage = new MimeMessage(mailSession);
			//emailMessage1 = new MimeMessage(mailSession);
			emailMessage.setFrom(new InternetAddress(from));
			MimeBodyPart 	MBP 	=	null;
			MimeBodyPart 	MBP1 	=	null;
			FileDataSource	DFS	=	null;
			Multipart 		MP 		= new MimeMultipart();
			MBP =  new MimeBodyPart();
			MBP1 =  new MimeBodyPart();
			String filename = "C:/Data/Report Automation/Reports/DailyReports/Evening/4pm Report_Adhoc request A40203704/Adhoc Request A40203704_ 17 September 2015.xls";
			//String filename1 = "C:\\IPA\\CTTISGASD-516 - "+s+"_No records"+".xls";
			DFS = new FileDataSource(filename);
			//DFS1 = new FileDataSource(filename1);

			String emailSubject = " Daily Report - Sonali please send report";

			String emailBody = "Hi, \n " +
					"\n" +
					"Please find the attached report for MCAL notifications sent from " + "22 September" + " (4:00 PM) till " + "23 September" + " (4:00 PM). \n" +
					"\n" +
					"\n" +
					"\n" +
					"Kind regards, \n" +
					"Lalit Tyagi \n" +
					"Application Service Delivery \n" +
					"iNautix Technologies India - A BNY Mellon Company";
			
			emailMessage.setSubject(emailSubject);
			emailMessage.setText(emailBody);
			emailMessage.setContent(emailBody, "text/html");
			MBP.setDataHandler(new DataHandler(DFS));
			MBP.setFileName(DFS.getName());
			MBP1.setText(emailBody);
			MP.addBodyPart(MBP);
			MP.addBodyPart(MBP1);
			emailMessage.setContent(MP);



			for (int i = 0; i < toEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
			}
			for (int i = 0; i < ccEmails.length; i++) {
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccEmails[i]));
			}

			System.out.println(DFS.getName());

			Transport.send(emailMessage);

			System.out.println("Email sent successfully.");
		}catch(MessagingException e){
			e.printStackTrace();

		}
	}
}