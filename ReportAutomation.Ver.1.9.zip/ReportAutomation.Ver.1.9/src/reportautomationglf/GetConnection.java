package reportautomationglf;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetConnection 
{
	public static void main(String[] args) 
	{
		getConnection();
	}
	
	public static Connection getConnection()
	{
		Connection connection = null;
		String driver = "oracle.jdbc.driver.OracleDriver";;
		String userName = "AFRA_READ";
		String password = "G1f#readOnly";
		String url = "jdbc:oracle:thin:@xsd0pa27.bankofny.com:1522:ORARRD04";
		try
		{
			Class.forName(driver);
			System.out.println("Driver Loaded");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Connection Established");
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		catch(ClassNotFoundException exp)
		{
			exp.printStackTrace();
		}
		catch(Exception excep)
		{
			excep.printStackTrace();
		}
		return connection;
	}
}
