package reportautomationglf;

public class QueryConstant 
{
	static String strNdayQuery = "select i.trancheid as ISIN,\n" +
										"ii.actualinvoicevaluedate as VALUEDATE,\n" +
										"i.amount,\n" +
										"i.currencycode,\n" +
										"DECODE(ii.actualinvoicevaluedate, ii.disbursementvaluedate, 'N', 'Y') as N_DAY,\n" +
										"(i.AMOUNT / a.rate) as USD_Equivalent,\n" +
										"hmi.name as issuername\n" +
										"from ie_invoice_component i,\n" +
										"ie_invoice ii,\n" +
										"rd_currency a,\n" + 
										"ace_movement am,\n" + 
										"ace_movement_origin amo,\n" + 
										"ace_as_apply_movement_detail aacm,\n" +
										"hm_issuer hmi\n" +
										"where ii.id = i.invoiceid\n" + 
										"and a.code = i.currencycode\n" +
										"and am.movementid = amo.movementid\n" + 
										"and amo.componentid = i.id\n" + 
										"and aacm.id = am.movementid\n" +
										"and am.movementstatus = 20\n" + 
										"and am.isinvoice = 'T'\n" +
										"and ii.issuerid= hmi.issuerid\n" +
										"and trunc(ii.createdate) between to_date('08/01/2015','mm/dd/yyyy') and to_date('08/31/2015','mm/dd/yyyy')\n" +
										"order by ii.createdate asc";
	
	static String strDisbursementQuery = "select distinct dd.reference as DISBURSEMENT_ID,dd.VERSIONNO as VERSION,DDP.SOURCEACCOUNT as DEBITACCOUNT,\n" +
												"(select count(ddc.componentno) from de_disbursement_component c where C.disbursementid=ddc.disbursementid) as COMPONENTNO,\n" +
												"dd.externalreference as EXTERNAL_REFERENCE,\n" +
												"substr(dd.externalreference, 14, 4) as COUPON,\n" +
												"DECODE(DD.STATUSID, '1', 'REJECTED AUTOMATIC', '2', 'REJECTED MANUAL', '3', 'CANCEL REJECTED', '4', 'PENDING VERIFICATION',\n" +
												"'5', 'PENDING PLATINUM VERIFICATION', '6', 'PENDING CANCELLATION', '7', 'VERIFIED', '20', 'CANCELLED', '70', 'CONFIRMED') AS STATUS,\n" +
												"DECODE(DD.SOURCEID, '1', 'CDS', '4', 'MANUALLY', '5', 'GD OASIS') AS SOURCE,\n" +
												"DDC.TRANCHEID AS ISIN,\n" +
												"HI.NAME   AS ISSUER_NAME,\n" +
												"DD.CURRENCYCODE AS CURRENCY,\n" +
												"dd.totalcurrencyamount as AMOUNT,\n" +
												"(dd.totalcurrencyamount/a.rate) as USD_EQUIVALENT,\n" +
												"to_char(dd.createdate, 'DD/MM/YYYY') as CREATE_DATE,\n" +
												"to_char(dd.createdate, 'HH:MM:SS AM') as CREATE_TIME,\n" +
												"dd.appliedvaluedate as APPLIED_VALUE_DATE\n" +
												"from de_disbursement dd,\n" +
												"DE_DISBURSEMENT_COMPONENT DDC,\n" +
												"HM_ISSUER HI,\n" +
												"RD_CURRENCY A,\n" +
												"DE_DISBURSEMENT_PAYMENT DDP\n" +
												"WHERE DD.DISBURSEMENTID = DDC.DISBURSEMENTID\n" +
												"and dd.disbursementid = DDP.disbursementid\n" +
												"and dd.issuerid = hi.issuerid(+)\n" +
												"AND DD.CURRENCYCODE = A.CODE\n" +
												"and  DD.ACTUALPROCESSINGDATE > TO_DATE(TO_CHAR(trunc(trunc(sysdate,'MM')-1,'MM')-1,'mm/dd/yyyy')||' 07:00:00 PM','mm/dd/yyyy HH:MI:SS AM')\n" +
												"and DD.ACTUALPROCESSINGDATE < TO_DATE(TO_CHAR(TRUNC(SYSDATE,'MM')-1,'mm/dd/yyyy')||' 07:00:00 PM','mm/dd/yyyy HH:MI:SS AM')\n" +
												"and dd.versionno = (select max(d2.versionno) from de_disbursement d2 where d2.reference = dd.reference)\n" +
												"and dd.STATUSID = 70\n" +
												"order by dd.reference";
	
	static String strCreditLineReports = "SELECT lineid,linename as Issuer,linevalue as Amount FROM CREDIT_LIMIT_VALUE where STATUS = '7'";
	
	static String strCreditLineUsers = "select userid, firstname, lastname from usertbl where userid in (select userid from entl_user_role where role_id = 20)";
	
	static String strCreditLineUtilized = "SELECT H.PROGRAMMEID, HP.NAME PROGRAMMENAME, H.ISSUERID, HR.NAME ISSUERNAME,H.ISSUEID,HI.NAME ISSUENAME, C.LINENAME,C.LINEVALUE\n" +
											"FROM CREDIT_LIMIT_VALUE c, hierarchy_credit_limit_mapping hm, HM_HIERARCHY h, hm_issue hi, hm_issuer hr, HM_PROGRAMME HP\n" +
											"WHERE C.LINEID = HM.LINEID\n" +
											"AND H.HIERARCHYID = HM.HIERARCHYID\n" +
											"AND H.ISSUEID = HI.ISSUEID(+)\n" + 
											"AND HR.ISSUERID = H.ISSUERID\n" +
											"AND HP.PROGRAMMEID = H.PROGRAMMEID\n" +
											"AND c.status =7";

}
