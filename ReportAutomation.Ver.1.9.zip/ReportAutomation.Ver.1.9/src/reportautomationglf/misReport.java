package reportautomationglf;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;


import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

public class misReport {
	public static void main(String[] args) 
	{

		getConnection();

	}

	public static Connection getConnection()
	{
		Connection connection = null;
		Statement stmt = null;
		//Statement stmt1 = null;
		String driver = "oracle.jdbc.driver.OracleDriver";
		String userName = "XBBLQ52";
		String password = "XBBLQ521";
		String url = "jdbc:oracle:thin:@oorgsp05.bnymellon.net:1524:oorgsp05";
		int i=1,j=1,type;


		try
		{
			System.out.println("Writing to file");
			FileOutputStream fileOut = new FileOutputStream("C:\\Data\\excelFile.xls");
			Class.forName(driver);
			System.out.println("Driver Loaded");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Connection Established");
			stmt = connection.createStatement();

			String sql;
			sql = "SELECT * from rgswkf_prgm.txn where rownum<5";

			ResultSet rs = stmt.executeQuery(sql);


			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("Excel Sheet");
			int rowcount = 0;
			ResultSetMetaData rsmd = rs.getMetaData();	
			int columnCount = rsmd.getColumnCount();	
			System.out.println(columnCount);

			// Create a row for header at 0th index
			HSSFRow rowhead1 = sheet.createRow((short) 0);
			for(int headerColunm = 0; headerColunm <= columnCount - 1; headerColunm++)
			{
				HSSFCell cellHeader = rowhead1.createCell(headerColunm);
				cellHeader.setCellValue(rsmd.getColumnName(headerColunm + 1));
			}


			while(rs.next()){  


				HSSFRow rowhead = sheet.createRow((short) ++rowcount);


				for (i = 1; i < columnCount+1; i++ )
				{

					type = rsmd.getColumnType(i);
					System.out.println(type);
					HSSFCell cell = rowhead.createCell(i-1);
					System.out.println("Entering Switch");

					SimpleDateFormat dt = new SimpleDateFormat("dd MM yyyy");
					switch(type) {
					case 1:  
						cell.setCellValue(rs.getString(i));
						System.out.println("Entering into excel");            	  
						break;
					case 2:  
						cell.setCellValue(rs.getInt(i));
						System.out.println("Entering into excel"); 
						break;
					case 12:  
						cell.setCellValue(rs.getString(i));
						System.out.println("Entering into excel");            	  
						break;
					case 93:

						if(rs.getTimestamp(i)== null)
						{
							System.out.println("Entering NULL Date");
							cell.setCellValue(Cell.CELL_TYPE_BLANK);
						}
						else
						{
							//dt.format(arg0)
							cell.setCellValue(rs.getTimestamp(i));
							System.out.println("Entering date into excel"); 
						}

						break;
					case 92:
						cell.setCellValue(rs.getTimestamp(i));
						System.out.println("Entering into excel");            	  
						break;
					}
				}                  
			}

			wb.write(fileOut);

			System.out.println("Closing Conn");

			fileOut.close();
			rs.close();		
			stmt.close();
			connection.close();     
		}

		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		catch(ClassNotFoundException exp)
		{
			exp.printStackTrace();
		}
		catch(Exception excep)
		{
			excep.printStackTrace();
		}
		return connection;
	}
}


