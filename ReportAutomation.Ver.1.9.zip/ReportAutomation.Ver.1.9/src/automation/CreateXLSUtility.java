package automation;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;

import automation.GetConnection;

public class CreateXLSUtility
{
	public static void main(String[] args) 
	{

	}

	public static Boolean createXLS(String query, String sheetName, String sourcePath)
	{
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		ResultSetMetaData resultSetMetaData = null;
		FileOutputStream fileOut = null;
		int i = 1;
		int type;
		int columnCount;
		int rowcount;
		Boolean isData = false; 
		try
		{
			// get the connection and execute the query
			connection = GetConnection.getConnection();
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(query);

			// Create the instance of Workbook
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet(sheetName);
			
			// Getting the Font Style for the Report
			HSSFFont arialBoldFont = workbook.createFont();
			arialBoldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			arialBoldFont.setFontName("Calibri");
			arialBoldFont.setFontHeightInPoints((short) 11);
			
			//Getting a style for the Header
			HSSFCellStyle headerStyle = workbook.createCellStyle();
			headerStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			headerStyle.setFont(arialBoldFont);
			headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			headerStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
			headerStyle.setIndention((short) 0);
			headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			
			//Getting a style for the sheet
			HSSFCellStyle style = workbook.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN); 
			
			SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
			rowcount = 0;
			resultSetMetaData = resultSet.getMetaData();      
			columnCount = resultSetMetaData.getColumnCount();  
		
			//Create a row for header at 0th index
			HSSFRow headerRow = sheet.createRow(0);
			for(int headerColunm = 0; headerColunm <= columnCount - 1; headerColunm++)
			{
				HSSFCell cellHeader = headerRow.createCell(headerColunm);
				cellHeader.setCellValue(resultSetMetaData.getColumnName(headerColunm + 1));
				cellHeader.setCellStyle(headerStyle);
			}
			while(resultSet.next())
			{  
				isData = true;
				HSSFRow rowhead = sheet.createRow(++rowcount);
				for (i = 1; i <= columnCount; i++ )
				{
					type = resultSetMetaData.getColumnType(i);
					HSSFCell cell = rowhead.createCell(i-1);
					if(type == Types.CHAR || type == Types.VARCHAR)
					{
						String value = resultSet.getString(i);
						if(value != null)
						{
							cell.setCellValue(value);
						}
						/*else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}*/
					}
					else if(type == Types.NCHAR || type == Types.NVARCHAR || type == Types.LONGVARCHAR)
					{
						String value = resultSet.getString(i);
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					else if(type == Types.INTEGER)
					{
						Integer value = resultSet.getInt(i); 
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					else if(type == Types.FLOAT)
					{
						Float value = resultSet.getFloat(i); 
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					else if(type == Types.DOUBLE || type == Types.NUMERIC)
					{
						Double value = resultSet.getDouble(i); 
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					else if(type == Types.DATE)
					{
						String value = dt.format(resultSet.getDate(i));
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					else if(type == Types.TIMESTAMP)
					{
						String value = dt.format(resultSet.getTimestamp(i));
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					else if(type == Types.BOOLEAN)
					{
						Boolean value = resultSet.getBoolean(i); 
						if(value != null)
						{
							cell.setCellValue(value);
						}
						else
						{
							cell.setCellValue(Cell.CELL_TYPE_BLANK);               
						}
					}
					
					cell.setCellStyle(style);
				}                  
			}
			
			for(int columnIndex = 0; columnIndex < columnCount; columnIndex++) 
			{
				sheet.autoSizeColumn(columnIndex);
			}

			fileOut = new FileOutputStream(sourcePath);
		    workbook.write(fileOut);
		    fileOut.close();
		}
		catch (SQLException e1) 
		{
			e1.printStackTrace();
		} 
		catch (FileNotFoundException e1) 
		{
			e1.printStackTrace();
		} 
		catch (IOException e1) 
		{
			e1.printStackTrace();
		}
		catch(Exception e3)
		{
			e3.printStackTrace();
		}
		finally
		{
			try 
			{
				if(resultSet != null)
					resultSet.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the ResultSet");
				e.printStackTrace();
			}
			try 
			{
				if(stmt != null)
					stmt.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Statement");
				e.printStackTrace();
			}
			try 
			{
				if(connection != null)
					connection.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("Exception occured while closing the Connection");
				e.printStackTrace();
			}
		}
		return isData;
	}
}