package automation;


import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Date;

import org.quartz.simpl.SimpleTimeBroker;

import reportautomation.SendingMailUtility;
import shellautomation.SSHManager;


public class MonitorAppServerLogs
{
	Map<String, String> unixResultMap = new HashMap<String, String>();
	String strUserName;
	String strPassword;

	public static void main(String args[]) throws IOException
	{
		new MonitorAppServerLogs().getUnixResult();
	}

	public void executeCommands(String uName, String pword, String connIP, String app_server)
	{
		int iDayOfMonth = 0;
		String strDate = null;
		DateFormat timeNowIST = null;
		DateFormat dateFormat = null;
		String strEmailSubject = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 0);
		iDayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		Date dNow = new Date( );
		
		if(iDayOfMonth < 10)
		{
			dateFormat = new SimpleDateFormat("MMM  d");
			timeNowIST = new SimpleDateFormat ("hh:mm:ss a zzz");
		}
		else
		{
			dateFormat = new SimpleDateFormat("MMM d");
			timeNowIST = new SimpleDateFormat ("hh:mm:ss a zzz");
		}
		
		strDate = dateFormat.format(cal.getTime());
		
		String userName = uName;
		String password = pword;
		String connectionIP = connIP;
		String strServer = null;
		String strpath = null;

		if(app_server.equals("r21mp1v"))
		{	
			strServer = "r21mp1v";
			strpath = "r21mp1v";
		}
		else
		{
			strServer = "r21mp2v";
			strpath = "r21mp2v";
		}
		
		//Commands to be run in Unix
		String commandChckGdoLog = " [ -f /app/gdogdoasis/gdogdoasis-"+strpath+"-na/gdoasis.log ] && echo " + "gdoasis.log File is there" + "|| echo " + "gdoasis.log File is Not there";
		String commandChckSysOutLog = " [ -f /app/gdogdoasis/gdogdoasis-"+strpath+"-na/SystemOut.log ] && echo " + "SystemOut.log File is there" + "|| echo " + "SystemOut.log File is Not there";
		
		String timeNowCommand = "(date +%s)";
		String timeGdoLogCommand = "(date +%s -d\"$( ls -l /app/gdogdoasis/gdogdoasis-"+strpath+"-na/gdoasis.log | awk ' { print $(NF-3)\" \"$(NF-2)\" \"$(NF-1); }')\")";
		
		String command1 = "ls -ltr /app/gdogdoasis/gdogdoasis-" + strpath + "-na";		

		SSHManager instance = new SSHManager(userName, password, connectionIP, "");
		String errorMessage = instance.connect();

		if(errorMessage != null)
		{
			System.out.println(errorMessage);
		}
		
		//Executing Commands in Unix
		String chckGdoLog = instance.sendCommand(commandChckGdoLog);
		String chckSysOutLog = instance.sendCommand(commandChckSysOutLog);
		
		String timeNow = instance.sendCommand(timeNowCommand);
		String timeGdoLog = instance.sendCommand(timeGdoLogCommand);
		
		//System.out.println(timeNow +timeGdoLog);				//Time stamps
		
		double time1 = Double.parseDouble(timeNow);
		double time2 = 0;
		if(timeGdoLog==null || "".equals(timeGdoLog)){						//Handling exception when there is 
			time2=time1 - 200;
			System.out.println("gdoasis.log not present on server - "+strServer);
		}
		else{
			 time2 = Double.parseDouble(timeGdoLog);
		}
		
		double timeDiff=time1-time2;
		
		//Send mail if gdoasis.log or SystemOut.log is not present of not getting generated for past 5 minutes
		if(chckSysOutLog.contains("File is Not there") || chckGdoLog.contains("File is Not there") || timeDiff>300)
		{
			System.out.println("Logs not generating on "+strServer+" as at : " + timeNowIST.format(dNow)); //Printing output on console for logs not generating
			String result1 = instance.sendCommand(command1);
			String[] strToList = {"ctsd.gdoasis@bnymellon.com"};  // its.puts.and.calls@bnymellon.com
		   // String[] strCCList = {"abhikumar@inautix.co.in"};   //ctsd.gdoasis@bnymellon.com
		    if (timeDiff>300)
		    	{strEmailSubject = "URGENT : Gdoasis LOGS NOT GENERATING for more than 5 minutes on - " + strServer;}
		    else if (chckGdoLog.contains("File is Not there"))
		    	{strEmailSubject = "URGENT : Gdoasis LOGS NOT PRESENT on - " + strServer;}
		    else if (chckSysOutLog.contains("File is Not there"))
		    	{strEmailSubject = "URGENT : SystemOut LOGS NOT PRESENT on - " + strServer;}
		    String strEmailBody = "Hi All,<br><br>Please check the logs on server - "+strServer+"<br>" + result1 +
		    "<br><br>and login to <a href='https://r245p10.bnymellon.net:20185/ibm/console/logon.jsp'>Websphere Console</a> and check if JVMs are UP and running";
		    new SendingMailUtility().sendMail(strEmailSubject, strEmailBody, strToList);
		}

		/*String result1 = instance.sendCommand(command1);							//For Printing time of gdoasis.log
		 if(result1.contains(strDate) && result1.contains("gdoasis.log"))				
		{
			if(strServer != null && strServer.equals("r21mp1v"))
			{unixResultMap.put("gdoLogs_r21mp1v", "r21mp1v : " + result1.substring(result1.lastIndexOf(strDate) + 7, result1.lastIndexOf(strDate) + 13) + " AM");}
			else if(strServer != null && strServer.equals("r21mp2v"))
			{unixResultMap.put("gdoLogs_r21mp2v", "r21mp2v : " + result1.substring(result1.lastIndexOf(strDate) + 7, result1.lastIndexOf(strDate) + 13) + " AM");}
		}*/
		// close only after all commands are sent
		instance.close();
	}
	
	
	public Map<String, String> getUnixResult()
	{
		//String wls_gdo_01 = "r21mp1v";
		//String wls_gdo_02 = "r21mp2v";
		
		/*username = "xbblylz";
		password = "Reset543@";*/
		init();
		executeCommands(strUserName, strPassword, "10.59.39.49", "r21mp1v");		//For r21mp1v
		executeCommands(strUserName, strPassword, "10.59.39.50", "r21mp2v");		//For r21mp2v
		
		//System.out.println("GD Oasis application Logs : " + unixResultMap.get("gdoLogs_r21mp1v") + "\n" + unixResultMap.get("gdoLogs_r21mp2v"));
		
		return unixResultMap;
	}
	
	
	private void init()
	{
		Properties prop = new Properties();
		InputStream input = null;
		try{
			input = MonitorAppServerLogs.class.getClassLoader().getResourceAsStream("config.properties");
			prop.load(input);
			
			strUserName = prop.getProperty("UnixUserName");
			strPassword = prop.getProperty("UnixPassword");
			System.out.println("Values are loaded successfully from property file - config.properties");
		}
		catch(IOException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
}