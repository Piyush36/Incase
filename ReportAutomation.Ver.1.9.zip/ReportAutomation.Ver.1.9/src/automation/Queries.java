package automation;

public class Queries {
	static String strQuery = 	"SELECT\n" + 
								"''						Data,\n" + 
								"'GFU Data'					GFUData,\n" + 
								"SORID	=	CASE TRA.note_type\n" +
								"WHEN 'Y' THEN		'N4'\n" +
								"WHEN 'N' THEN		'6B'\n" +
								"END,\n" +
								"ISNULL(M564.t20_corp_reference,convert(varchar(11),getdate(),106)+'N400')		EventID,\n" +
								"''						SEMERef,\n" +
								"''						FunctionOfMsg,\n" +
								"'INTR'						EventType,\n" +
								"'MAND'						MandVoul,\n" +
								"'COMP'						InfoStatus,\n" +
								"TRA.isin					ISIN,\n" +
								"''						Local,\n" + 
								"TRA.common_code					CommonCode,\n" +
								"LEFT(TRA.issue_name,20)				SecurityName,\n" +
								"DayCount =	CASE TRA.basis_for_int_pay\n" +
								"WHEN  1 THEN		'A007'\n" +	
								"WHEN  2 THEN		'OTHR'\n" +
								"WHEN  3 THEN		'A009'\n" +
								"WHEN  4 THEN		'A006'\n" +
								"WHEN  5 THEN		'A011'\n" +
								"WHEN  6 THEN		'A004'\n" +
								"WHEN  7 THEN		'A002'\n" +
								"WHEN  8 THEN		'A008'\n" +
								"WHEN  9 THEN		'A005'\n" +
								"WHEN 11 THEN		'A008'\n" +
										"ELSE			'OTHR'\n" +
										"END,\n" +
										"''						CurNominal,\n" +
										"Convert(Char(8),TRA.int_rate_set_date,112)	NextFixDate,\n" +
										"NewPoolFactor = CASE TRA.jpm_is_ppa_ind\n" +
										"WHEN 'Y' THEN CONVERT(NUMERIC(38,7),ISNULL(ISNULL(TRA.current_pool_factor,TRA.pool_factor),1))\n" +
										"WHEN 'N' THEN CONVERT(NUMERIC(38,7),ISNULL(TRA.pool_factor,1))\n" +
										"END,\n" +
										"CurrentPoolFactor = CASE TRA.jpm_is_ppa_ind\n" +
										"WHEN 'Y' THEN CONVERT(NUMERIC(38,7),ISNULL(ISNULL(TRA.current_pool_factor,TRA.pool_factor),1))\n" +
												"WHEN 'N' THEN CONVERT(NUMERIC(38,7),ISNULL(TRA.pool_factor,1))\n" +
														"END,\n" +
														"''						ExMinQuant,\n" +
														"''						QuantTypeMin,\n" +
														"''						ExMultQuant,\n" +
														"''						QuantTypeMult,\n" +
														"''						SafekeepingAcct,\n" +
														"''						Holding,\n" +
														"''						QuantType,\n" +
														"''						ExDate,\n" +
														"''						InfoDate,\n" +
														"''						LotteryDate,\n" +
														"RecordDate = CASE TRA.issue_reg_type_code\n" +
														"WHEN 'Y' THEN\n" +
														"CASE TRA.jpm_is_ppa_ind\n" +
														"WHEN 'Y' THEN Convert(Char(8),TRA.ipa_record_date,112)\n" +
														"ELSE		Convert(Char(8),TRA.depo_record_date,112)\n" +
														"END\n" +
														"ELSE Convert(char(8),dateadd(dd,-1,TRA.pay_date),112)\n" +
														"END,\n" +
														"Convert(Char(8),TRA.maturity_date,112)		RedemptionDate,\n" +
														"''						AgtDepoDeadline,\n" +
														"''						MktDeadline,\n" +
														"''						ContConv,\n" +
														"''						BlockingDate,\n" +
														"''						UnBlockingDate,\n" + 
														"Convert(Char(8),TRA.intrest_period_from,112)	CouponStartDate,\n" + 
														"Convert(Char(8),TRA.intrest_period_to,112)	CouponEndDate,\n" +
														"''						ExStartDate,\n" +
														"''						ExEndDate,\n" +
														"CASE TRA.jpm_is_ppa_ind\n" +
														"WHEN 'Y' THEN\n" +
														"CASE TRA.security_type_code\n" +
														"WHEN 'WARRANT' THEN ''\n" +
														"ELSE CONVERT(VARCHAR,CONVERT(NUMERIC(38,7),TRA.int_rate_perc))\n" +
														"END\n" +
														"ELSE\n" +
														"CASE TRA.product_id\n" +
														"WHEN 'WAR' THEN ''\n" +
														"ELSE\n" + 
														"CASE\n" + 
														"WHEN TRA.zero_rate_valid = 'N' AND TRA.int_rate_perc = 0 THEN NULL\n" +
														"ELSE CONVERT(VARCHAR,CONVERT(NUMERIC(38,7),TRA.int_rate_perc))\n" +
														"END\n" +
														"END\n" +
														"END\n" +
														"InterestRate,\n" +
														"''						RedemptionRate,\n" +
														"''						DrawPercentage,\n" +
														"''						GrossAmount,\n" +
														"''						EntitlementRatioProc,\n" +
																"''						EntitlementRatioBase,\n" +
																"''						RedemptionAmount,\n" +
																"''						CrrRedemptionAmount,\n" +
																"''						CrrExercisePrice,\n" +
																"''						ExcercisePrice,\n" +
																"''						OtherCert,\n" +
																"''						SuspensionStartDate,\n" +
																"''						SuspensionEndDate,\n" +
																"''						CAOptionNumber,\n" +
																"''						Indicator,\n" +
																"''						Fractions,\n" +
																"ISOCurrencyCashamount = CASE TRA.interest_ccy\n" +
																"WHEN Null THEN	CASE TRA.principle_ccy\n" +
																"WHEN 'ATS' THEN 'EUR'\n" +
																"WHEN 'BEF' THEN 'EUR'\n" +
																"WHEN 'NLG' THEN 'EUR'\n" +
																"WHEN 'FIM' THEN 'EUR'\n" +
																"WHEN 'FRF' THEN 'EUR'\n" +
																"WHEN 'DEM' THEN 'EUR'\n" +
																"WHEN 'IEP' THEN 'EUR'\n" +
																"WHEN 'ITL' THEN 'EUR'\n" +
																"WHEN 'LUF' THEN 'EUR'\n" +
																"WHEN 'PTE' THEN 'EUR'\n" +
																"WHEN 'ESP' THEN 'EUR'\n" +
																"WHEN 'GRD' THEN 'EUR'\n" +
																"WHEN 'SIT' THEN 'EUR'\n" +
																"WHEN 'CYP' THEN 'EUR'\n" +
																"WHEN 'MTL' THEN 'EUR'\n" +
																"WHEN 'SKK' THEN 'EUR'\n" +
																"ELSE TRA.principle_ccy\n" +
																"END\n" +
																"WHEN 'ATS' THEN 'EUR'\n" +
																"WHEN 'BEF' THEN 'EUR'\n" +
																"WHEN 'NLG' THEN 'EUR'\n" +
																"WHEN 'FIM' THEN 'EUR'\n" +
																"WHEN 'FRF' THEN 'EUR'\n" +
																"WHEN 'DEM' THEN 'EUR'\n" +
																"WHEN 'IEP' THEN 'EUR'\n" +
																"WHEN 'ITL' THEN 'EUR'\n" +
																"WHEN 'LUF' THEN 'EUR'\n" +
																"WHEN 'PTE' THEN 'EUR'\n" +
																"WHEN 'ESP' THEN 'EUR'\n" +
																"WHEN 'GRD' THEN 'EUR'\n" +
																"WHEN 'SIT' THEN 'EUR'\n" +
																"WHEN 'CYP' THEN 'EUR'\n" +
																"WHEN 'MTL' THEN 'EUR'\n" +
																"WHEN 'SKK' THEN 'EUR'\n" +
																"ELSE		 	TRA.interest_ccy\n" +
																"END,\n" +
																"''						DualActionFlag,\n" +
																"CASE TRA.jpm_is_ppa_ind\n" +
																"WHEN 'Y' THEN\n" +
																"CASE TRA.security_type_code\n" +
																"WHEN 'WARRANT' THEN ''\n" +
																"ELSE '=PeriodIntRate(ROW())'\n" +
																"END\n" +
																"ELSE\n" +
																"CASE TRA.product_id\n" +
																"WHEN 'WAR' THEN ''\n" +
																"ELSE '=PeriodIntRate(ROW())'\n" +
																"END\n" +
																"END\n" +
																"PeriodInterestRate,\n" +				
																"''						TaxableAmount,\n" +
																"''						NonTaxableAmount,\n" +
																"''						FeesPercentage,\n" +
																"''						FeesAmount,\n" +
																"''						CrDrIndicator,\n" +
																"''						ProcISIN,\n" +
																"''						ProcName,\n" + 	
																"''						DrawingAmt,\n" +
																"''						QuantTypeDrawAmt,\n" +
																"''						SettlementDate,\n" +
																"''						CrDrIndicatorCashMove,\n" +
																"''						AmtExpected,\n" +	
																"Convert(Char(8),TRA.pay_date,112)		DueDate,\n" +
																"Convert(Char(8),TRA.pay_date,112)		ValueDate,\n" + 
																"''						ExchangeRate,\n" +
																"''						FXRateFirst,\n" +
																"''						FXRateSecond,\n" +
																"''						ResultingAmt,\n" +
																"''						IssuAgt,\n" +
																"''						PPA,\n" +
																"''						NarrativeIncExNotice,\n" +
																"''						NarrativeText,\n" +
																"'=DaysInPeriod(ROW())'		NumberOfDaysAccrued,\n" +
																"PaymentFrequency =  CASE TRA.interest_freq\n" +
																"WHEN 'ANN' THEN		'ANNUA'\n" +
																"WHEN 'DAY' THEN		'DAILY'\n" +
																"WHEN 'MAT' THEN		'OIPED'\n" +
																"WHEN 'MON' THEN		'MONTH'\n" +
																"WHEN 'ONE' THEN		'SINGL'\n" +
																"WHEN 'QRT' THEN		'QUART'\n" +
																"WHEN 'REF' THEN		'IRREG'\n" +
																"WHEN 'SEM' THEN		'SMANN'\n" +
																"WHEN 'USR' THEN		'IRREG'\n" +
																"WHEN 'WEK' THEN		'WEEKL'\n" +
																"ELSE			''\n" +		   		
																"END,\n" + 
																"Form	=	Case TRA.issue_reg_type_code\n" +
																"WHEN 'Y' THEN		'R'\n" +
																"WHEN 'N' THEN		'B'\n" +
																"END,\n" +
																"BusinessConventionRule = CASE TRA.biz_day_rules\n" +
																"WHEN 'F' THEN	'FBC'\n" +
																"WHEN 'M' THEN	'MFBC'\n" +
																"WHEN 'P' THEN	'PBC'\n" +
																"ELSE		''\n" +
																"END,\n" +
																"''						TaxableEvent,\n" +
																"AdjustedPeriod = CASE TRA.adjust_flag\n" +
																"WHEN 'Y' THEN 'A'\n" +
																"WHEN 'N' THEN 'U'\n" +
																"ELSE	TRA.adjust_flag\n" +
																"END,\n" +
																"''						NewComment,\n" +
																"''						HistoricComment,\n" +
																"''						UpdatedFlag,\n" +
																		"''						ComparisonStatus,\n" +
																		"''						DiscrepancyIndicator,\n" +
																		"''						OwnershipIndicator,\n" +
																		"TRA.current_nominal				CurrentAmount,\n" +
																		"TRA.maturity_method				MaturityMethod,\n" +
																		"''						AmorAmount,\n" +
																		"TRA.bare_depo_flag		DepoType,\n" +
																		"TRA.zero_rate_valid		ZeroRateValid\n" +
																		"FROM v_tranche TRA noholdlock, swift_mt564 M564 noholdlock\n" +
																		"WHERE TRA.isin *= M564.isin_no\n" +
																		"and TRA.intrest_period_from *= M564.t69_int_period_from\n" +
																		"and TRA.intrest_period_to *= M564.t69_int_period_to\n" +
																		"and TRA.status_code='LI'\n" +
																		"AND TRA.note_type = 'Y'\n" +		
																		"and TRA.branch_code='CD'\n" +
																		"and TRA.discount_ind='I'\n" +
																		"AND TRA.pay_date = convert(varchar(11),dateadd(dd,21,getDate()))\n" +
																		"and M564.contact_id='782969415818120'\n" +
																		"AND M564.swift_variant_type = 'RFIX'\n" +
																		"and M564.swift_seq_no = (select max(M5641.swift_seq_no) from swift_mt564 M5641 where\n" +
																		"M5641.isin_no = M564.isin_no and M5641.swift_variant_type = M564.swift_variant_type\n" +
																		"and M5641.contact_id = M564.contact_id and M5641.t69_int_period_from=M564.t69_int_period_from\n" +
																		"and M5641.t69_int_period_to=M564.t69_int_period_to)\n" +
																		"and ((TRA.jpm_is_ppa_ind='Y' and TRA.security_type_code<>'WARRANT') or (TRA.jpm_is_ppa_ind='N' and TRA.product_id<>'WAR'))\n" +
																		"and TRA.tranche_id not in (select tranche_id from v_tranche_event_schedule TRES where TRES.tranche_id=TRA.tranche_id\n" +
																		"and TRES.fix_sched_pay_to=TRA.pay_date and TRES.tranche_event_type_id = 101 and isNULL(TRES.interest_amount,0) = 0)\n" +
																		"order by EventID";



/*--REDM Data

SELECT
''						Data,     
'GFU Data'					GFUData,			

SORID	=	CASE TRA.note_type

			WHEN 'Y' THEN		'N4'
			WHEN 'N' THEN		'6B'
		END,

ISNULL(M564.t20_corp_reference,convert(varchar(11),getdate(),106)+'N400')		EventID,
''						SEMERef,
''						FunctionOfMsg,

'REDM'						EventType,
'MAND'						MandVoul,
'COMP'						InfoStatus,
TRA.isin					ISIN,
''						Local, 
TRA.common_code					CommonCode,
LEFT(TRA.issue_name,20)				SecurityName,

''						DayCount,

''						CurNominal,
''						NextFixDate,
''						NewPoolFactor,
''						CurrentPoolFactor,
''						ExMinQuant,
''						QuantTypeMin,
''						ExMultQuant,
''						QuantTypeMult,
''						SafekeepingAcct,
''						Holding,
''						QuantType,
''						ExDate,
''						InfoDate,
''						LotteryDate,			 
Convert(Char(8),dateadd(dd,-1,TRA.maturity_date),112)		RecordDate,		
Convert(Char(8),TRA.maturity_date,112)		RedemptionDate,
''						AgtDepoDeadline,
''						MktDeadline,
''						ContConv,
''						BlockingDate,
''						UnBlockingDate, 
''						CouponStartDate, 
''						CouponEndDate,
''						ExStartDate,
''						ExEndDate,
''						InterestRate,
TRA.maturity_proceed				RedemptionRate,
''						DrawPercentage,
''						GrossAmount,
''						EntitlementRatioProc,
''						EntitlementRatioBase,
''						RedemptionAmount,
''						CrrRedemptionAmount,
''						CrrExercisePrice,
''						ExcercisePrice,
''						OtherCert,
''						SuspensionStartDate,
''						SuspensionEndDate,
''						CAOptionNumber,
''						Indicator,
''						Fractions,

ISOCurrencyCashamount = CASE TRA.redemption_ccy

			   WHEN Null THEN	CASE TRA.principle_ccy
							WHEN 'ATS' THEN 'EUR'
							WHEN 'BEF' THEN 'EUR'
							WHEN 'NLG' THEN 'EUR'
							WHEN 'FIM' THEN 'EUR'
							WHEN 'FRF' THEN 'EUR'
							WHEN 'DEM' THEN 'EUR'
							WHEN 'IEP' THEN 'EUR'
							WHEN 'ITL' THEN 'EUR'
							WHEN 'LUF' THEN 'EUR'
							WHEN 'PTE' THEN 'EUR'
							WHEN 'ESP' THEN 'EUR'
							WHEN 'GRD' THEN 'EUR'
							WHEN 'SIT' THEN 'EUR'
							WHEN 'CYP' THEN 'EUR'
							WHEN 'MTL' THEN 'EUR'
							WHEN 'SKK' THEN 'EUR'
							ELSE TRA.principle_ccy
						END
			   WHEN 'ATS' THEN 'EUR'
			   WHEN 'BEF' THEN 'EUR'
			   WHEN 'NLG' THEN 'EUR'
			   WHEN 'FIM' THEN 'EUR'
			   WHEN 'FRF' THEN 'EUR'
			   WHEN 'DEM' THEN 'EUR'
			   WHEN 'IEP' THEN 'EUR'
			   WHEN 'ITL' THEN 'EUR'
			   WHEN 'LUF' THEN 'EUR'
			   WHEN 'PTE' THEN 'EUR'
			   WHEN 'ESP' THEN 'EUR'
			   WHEN 'GRD' THEN 'EUR'
			   WHEN 'SIT' THEN 'EUR'
			   WHEN 'CYP' THEN 'EUR'
			   WHEN 'MTL' THEN 'EUR'
			   WHEN 'SKK' THEN 'EUR'
			   ELSE		 	TRA.redemption_ccy

			END,

''						DualActionFlag,

''						PeriodInterestRate,
			
''						TaxableAmount,
''						NonTaxableAmount,
''						FeesPercentage,
''						FeesAmount,
''						CrDrIndicator,
''						ProcISIN,
''						ProcName,
''						DrawingAmt,
''						QuantTypeDrawAmt,
''						SettlementDate,
''						CrDrIndicatorCashMove,
''						AmtExpected,	
Convert(Char(8),TRA.maturity_date,112)		DueDate, 
Convert(Char(8),TRA.maturity_date,112)		ValueDate, 
''						ExchangeRate,
''						FXRateFirst,
''						FXRateSecond,
''						ResultingAmt,
''						IssuAgt,
''						PPA,
''						NarrativeIncExNotice,
''						NarrativeText,
''						NumberOfDaysAccrued,
''						PaymentFrequency, 

Form	=	Case TRA.issue_reg_type_code

			WHEN 'Y' THEN		'R'
			WHEN 'N' THEN		'B'

		END,

BusinessConventionRule = CASE TRA.biz_day_rules

				WHEN 'F' THEN	'FBC'
				WHEN 'M' THEN	'MFBC'
				WHEN 'P' THEN	'PBC'
				ELSE		''

			 END,

''						TaxableEvent,
AdjustedPeriod = CASE TRA.adjust_flag

				WHEN 'Y' THEN 'A'
				WHEN 'N' THEN 'U'
				ELSE	TRA.adjust_flag

			END,
''						NewComment,
''						HistoricComment,
''						UpdatedFlag,
''						ComparisonStatus,
''						DiscrepancyIndicator,
''						OwnershipIndicator,
''						CurrentNominal,
TRA.maturity_method				MaturityMethod,
''						AmorAmount,
TRA.bare_depo_flag		DepoType,
TRA.zero_rate_valid		ZeroRateValid
			

FROM v_tranche TRA noholdlock, swift_mt564 M564 noholdlock
WHERE TRA.isin *= M564.isin_no 
and TRA.status_code='LI'
AND TRA.note_type = 'Y'	
and TRA.branch_code='CD'
and TRA.maturity_date *= M564.t98_pay_date
AND TRA.maturity_date = convert(varchar(11),dateadd(dd,21,getDate()))
and M564.contact_id='782969415818120'
AND M564.swift_variant_type = 'NFRD'
and M564.swift_seq_no = (select max(M5641.swift_seq_no) from swift_mt564 M5641 where
M5641.isin_no = M564.isin_no and M5641.swift_variant_type = M564.swift_variant_type
and M5641.contact_id = M564.contact_id and M5641.t98_redm_date = M564.t98_pay_date)
and TRA.maturity_method<>'VAR'
and ((TRA.jpm_is_ppa_ind='Y' and TRA.security_type_code<>'WARRANT') or (TRA.jpm_is_ppa_ind='N' and TRA.product_id<>'WAR'))
order by EventID*/



/*--PRED Data

SELECT
''						Data,     
'GFU Data'					GFUData,			

SORID	=	CASE TRA.note_type

			WHEN 'Y' THEN		'N4'
			WHEN 'N' THEN		'6B'
		END,

convert(varchar(11),getdate(),106)+'N400'		EventID,
''						SEMERef,
''						FunctionOfMsg,

'PRED'						EventType,
'MAND'						MandVoul,
'COMP'						InfoStatus,
TRA.isin					ISIN,
''						Local, 
TRA.common_code					CommonCode,
LEFT(TRA.issue_name,20)				SecurityName,

''						DayCount,

''						CurNominal,
''						NextFixDate,
'=calcNewPoolFact(ROW())'			NewPoolFactor,
CurrentPoolFactor = CASE TRA.jpm_is_ppa_ind

	WHEN 'Y' THEN CONVERT(NUMERIC(38,7),ISNULL(ISNULL(TRA.current_pool_factor,TRA.pool_factor),1))
	WHEN 'N' THEN CONVERT(NUMERIC(38,7),ISNULL(TRA.pool_factor,1))

END,
''						ExMinQuant,
''						QuantTypeMin,
''						ExMultQuant,
''						QuantTypeMult,
''						SafekeepingAcct,
''						Holding,
''						QuantType,
''						ExDate,
''						InfoDate,
''						LotteryDate,			 
RecordDate = CASE TRA.jpm_is_ppa_ind

	WHEN 'Y' THEN ISNULL(Convert(Char(8),TRA.ipa_record_date,112),Convert(Char(8),dateadd(dd,-1,TRES.effective_date),112))
	WHEN 'N' THEN ISNULL(Convert(Char(8),TRA.depo_record_date,112),Convert(Char(8),dateadd(dd,-1,TRES.effective_date),112))
	ELSE		ISNULL(Convert(Char(8),TRA.depo_record_date,112),Convert(Char(8),dateadd(dd,-1,TRES.effective_date),112))
END,
Convert(Char(8),TRES.effective_date,112)	RedemptionDate,
''						AgtDepoDeadline,
''						MktDeadline,
''						ContConv,
''						BlockingDate,
''						UnBlockingDate, 
''						CouponStartDate, 
''						CouponEndDate,
''						ExStartDate,
''						ExEndDate,
''						InterestRate,
''						RedemptionRate,
''						DrawPercentage,
''						GrossAmount,
''						EntitlementRatioProc,
''						EntitlementRatioBase,
'=calcRedemAmt(ROW())'				RedemptionAmount,
CrrRedemptionAmount = CASE TRES.currency

			   WHEN Null THEN	CASE TRA.principle_ccy
							WHEN 'ATS' THEN 'EUR'
							WHEN 'BEF' THEN 'EUR'
							WHEN 'NLG' THEN 'EUR'
							WHEN 'FIM' THEN 'EUR'
							WHEN 'FRF' THEN 'EUR'
							WHEN 'DEM' THEN 'EUR'
							WHEN 'IEP' THEN 'EUR'
							WHEN 'ITL' THEN 'EUR'
							WHEN 'LUF' THEN 'EUR'
							WHEN 'PTE' THEN 'EUR'
							WHEN 'ESP' THEN 'EUR'
							WHEN 'GRD' THEN 'EUR'
							WHEN 'SIT' THEN 'EUR'
							WHEN 'CYP' THEN 'EUR'
							WHEN 'MTL' THEN 'EUR'
							WHEN 'SKK' THEN 'EUR'
							ELSE TRA.principle_ccy
						END
			   WHEN 'ATS' THEN 'EUR'
			   WHEN 'BEF' THEN 'EUR'
			   WHEN 'NLG' THEN 'EUR'
			   WHEN 'FIM' THEN 'EUR'
			   WHEN 'FRF' THEN 'EUR'
			   WHEN 'DEM' THEN 'EUR'
			   WHEN 'IEP' THEN 'EUR'
			   WHEN 'ITL' THEN 'EUR'
			   WHEN 'LUF' THEN 'EUR'
			   WHEN 'PTE' THEN 'EUR'
			   WHEN 'ESP' THEN 'EUR'
			   WHEN 'GRD' THEN 'EUR'
			   WHEN 'SIT' THEN 'EUR'
			   WHEN 'CYP' THEN 'EUR'
			   WHEN 'MTL' THEN 'EUR'
			   WHEN 'SKK' THEN 'EUR'
			   ELSE		 	TRES.currency

			END,
''						CrrExercisePrice,
''						ExcercisePrice,
''						OtherCert,
''						SuspensionStartDate,
''						SuspensionEndDate,
''						CAOptionNumber,
''						Indicator,
''						Fractions,

ISOCurrencyCashamount = CASE TRES.currency

			   WHEN Null THEN	CASE TRA.principle_ccy
							WHEN 'ATS' THEN 'EUR'
							WHEN 'BEF' THEN 'EUR'
							WHEN 'NLG' THEN 'EUR'
							WHEN 'FIM' THEN 'EUR'
							WHEN 'FRF' THEN 'EUR'
							WHEN 'DEM' THEN 'EUR'
							WHEN 'IEP' THEN 'EUR'
							WHEN 'ITL' THEN 'EUR'
							WHEN 'LUF' THEN 'EUR'
							WHEN 'PTE' THEN 'EUR'
							WHEN 'ESP' THEN 'EUR'
							WHEN 'GRD' THEN 'EUR'
							WHEN 'SIT' THEN 'EUR'
							WHEN 'CYP' THEN 'EUR'
							WHEN 'MTL' THEN 'EUR'
							WHEN 'SKK' THEN 'EUR'
							ELSE TRA.principle_ccy
						END
			   WHEN 'ATS' THEN 'EUR'
			   WHEN 'BEF' THEN 'EUR'
			   WHEN 'NLG' THEN 'EUR'
			   WHEN 'FIM' THEN 'EUR'
			   WHEN 'FRF' THEN 'EUR'
			   WHEN 'DEM' THEN 'EUR'
			   WHEN 'IEP' THEN 'EUR'
			   WHEN 'ITL' THEN 'EUR'
			   WHEN 'LUF' THEN 'EUR'
			   WHEN 'PTE' THEN 'EUR'
			   WHEN 'ESP' THEN 'EUR'
			   WHEN 'GRD' THEN 'EUR'
			   WHEN 'SIT' THEN 'EUR'
			   WHEN 'CYP' THEN 'EUR'
			   WHEN 'MTL' THEN 'EUR'
			   WHEN 'SKK' THEN 'EUR'
			   ELSE		 	TRES.currency

			END,

''						DualActionFlag,

''						PeriodInterestRate,
			
''						TaxableAmount,
''						NonTaxableAmount,
''						FeesPercentage,
''						FeesAmount,
''						CrDrIndicator,
''						ProcISIN,
''						ProcName,
''						DrawingAmt,
''						QuantTypeDrawAmt,
''						SettlementDate,
''						CrDrIndicatorCashMove,
''						AmtExpected,	
Convert(Char(8),TRES.effective_date,112)	DueDate, 
Convert(Char(8),TRES.effective_date,112)	ValueDate, 
''						ExchangeRate,
''						FXRateFirst,
''						FXRateSecond,
''						ResultingAmt,
''						IssuAgt,
''						PPA,
''						NarrativeIncExNotice,
''						NarrativeText,
''						NumberOfDaysAccrued,

''						PaymentFrequency, 

Form	=	Case TRA.issue_reg_type_code

			WHEN 'Y' THEN		'R'
			WHEN 'N' THEN		'B'

		END,

BusinessConventionRule = CASE TRA.biz_day_rules

				WHEN 'F' THEN	'FBC'
				WHEN 'M' THEN	'MFBC'
				WHEN 'P' THEN	'PBC'
				ELSE		''

			 END,

''						TaxableEvent,
AdjustedPeriod = CASE TRA.adjust_flag

				WHEN 'Y' THEN 'A'
				WHEN 'N' THEN 'U'
				ELSE	TRA.adjust_flag

			END,
''						NewComment,
''						HistoricComment,
''						UpdatedFlag,
''						ComparisonStatus,
''						DiscrepancyIndicator,
''						OwnershipIndicator,
TRA.current_nominal				CurrentNominal,
TRA.maturity_method				MaturityMethod,
isNull(TRES.redemption_amount,0)		AmorAmount,
TRA.bare_depo_flag		DepoType,
TRA.zero_rate_valid		ZeroRateValid
			


FROM v_tranche TRA noholdlock, v_tranche_event_schedule TRES noholdlock
WHERE TRA.tranche_id=TRES.tranche_id
and TRA.status_code='LI'
AND TRA.note_type = 'Y'	
and TRA.branch_code='CD'
AND TRES.effective_date = convert(varchar(11),dateadd(dd,21,getDate()))
and TRES.tranche_event_type_id=	102
and ((TRA.jpm_is_ppa_ind='Y' and TRA.security_type_code<>'WARRANT') or (TRA.jpm_is_ppa_ind='N' and TRA.product_id<>'WAR'))
order by EventID*/
}
