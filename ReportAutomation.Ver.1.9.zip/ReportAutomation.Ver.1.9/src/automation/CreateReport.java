package automation;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CreateReport {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new CreateReport().createReport();
	}
	
	public void createReport()
	{
		File directory = null;
		try
		{
			 // This piece of code will be creating the directory to save the reports
			directory = new File("C:/Data/Report Automation/Reports/DailyReports/");
			if(!directory.exists())
			{
				if(directory.mkdirs())
					System.out.println("C:/Data/Report Automation/Reports/DailyReports/ is created");
				else
					System.out.println("Failed to create directory!");
			}
			else
				System.out.println("directory already exist");
		    
		    String reportDay = getTodayDate();
		    String reportSrcPath = directory.toString() + "/Utility Reports - " + reportDay + ".xls";
		    
		    CreateXLSUtility.createXLS(Queries.strQuery, "Sheet1", reportSrcPath);
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private String getTodayDate() 
	{
		String strDate = null;
		
		DateFormat dateFormat = new SimpleDateFormat("dd MMMMMMMMM yyyy");
		//DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 0);
        
        strDate = dateFormat.format(cal.getTime());
        
        return strDate;
        
	}

}
